// =====================================================================
// CAPA DE DATOS — Sistema de Presupuestos C&V International
//
// Jerarquía: Versión -> Área -> Módulo -> Registros
//
// Hoy persiste en localStorage (funciona sin backend), pero está escrita
// con la MISMA forma que el esquema relacional de referencia
// (ver src/data/schema.sql), para que el día que exista un backend real
// solo haya que reemplazar el cuerpo de estas funciones por llamadas
// fetch/axios — los componentes que las usan (Dashboard, Offcanvas,
// SelectorVersiones) no deberían necesitar cambios.
//
// Antes: cada versión/área compartía el mismo estado en memoria
// (registrosPorCategoria, indexado solo por nombre de módulo), lo que
// mezclaba datos de áreas distintas. Aquí cada registro queda
// físicamente separado por (id_version, area, modulo).
// =====================================================================

const DB_KEY = 'cv_presupuestos_db_v1';

function leerDB() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) return semilla();
    const db = JSON.parse(raw);
    if (!Array.isArray(db.versiones) || !Array.isArray(db.registros)) return semilla();
    return db;
  } catch {
    return semilla();
  }
}

function guardarDB(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

function semilla() {
  const db = {
    versiones: [
      {
        id_version: 'v1',
        nombre: 'Presupuesto Inicial 2026',
        estado: 'Aprobado',
        fecha_creacion: '2026-01-15',
        clonada_de: null,
      },
    ],
    registros: [],
  };
  guardarDB(db);
  return db;
}

function generarId(prefijo = 'REG') {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `${prefijo}-${crypto.randomUUID()}`;
  }
  // Respaldo para entornos sin crypto.randomUUID
  return `${prefijo}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

// ===================== VERSIONES =====================

export function listarVersiones() {
  return leerDB().versiones;
}

export function obtenerVersion(idVersion) {
  return leerDB().versiones.find(v => v.id_version === idVersion) || null;
}

export function crearVersion({ nombre, estado = 'Borrador', clonarDesde = '' }) {
  const db = leerDB();

  // Antes: generarId('v') producía algo como "v-9eeef17d-6f24-415f-...".
  // Ahora usamos un correlativo legible ("v1", "v2", "v3"...), consistente
  // con el formato que ya usa la versión semilla.
  const numerosExistentes = db.versiones
    .map(v => parseInt(String(v.id_version).replace(/^v/i, ''), 10))
    .filter(n => !isNaN(n));
  const siguienteNumero = numerosExistentes.length > 0 ? Math.max(...numerosExistentes) + 1 : 1;
  const idVersion = `v${siguienteNumero}`;

  const nuevaVersion = {
    id_version: idVersion,
    nombre: nombre.trim(),
    estado,
    fecha_creacion: new Date().toISOString().split('T')[0],
    clonada_de: clonarDesde || null,
  };
  db.versiones.push(nuevaVersion);

  if (clonarDesde) {
    const registrosOrigen = db.registros.filter(r => r.id_version === clonarDesde);
    const registrosClonados = registrosOrigen.map(r => ({
      ...r,
      id_registro: generarId((r.modulo || 'REG').slice(0, 3).toUpperCase()),
      id_version: idVersion,
      creado_en: new Date().toISOString(),
      actualizado_en: new Date().toISOString(),
    }));
    db.registros.push(...registrosClonados);
  }

  guardarDB(db);
  return nuevaVersion;
}

export function actualizarVersion(idVersion, cambios) {
  const db = leerDB();
  db.versiones = db.versiones.map(v => (v.id_version === idVersion ? { ...v, ...cambios } : v));
  guardarDB(db);
  return db.versiones.find(v => v.id_version === idVersion) || null;
}

// Agregar en store.js
export function eliminarVersion(idVersion) {
  const db = leerDB();
  db.versiones = db.versiones.filter(v => v.id_version !== idVersion);
  db.registros = db.registros.filter(r => r.id_version !== idVersion);
  guardarDB(db);
}
// ===================== REGISTROS =====================

// Lee los registros de una combinación exacta (versión, área, módulo).
export function listarRegistros({ idVersion, area, modulo }) {
  const db = leerDB();
  return db.registros.filter(
    r => r.id_version === idVersion &&
         r.area === area &&
         (modulo === undefined || r.modulo === modulo)
  );
}

// Inserta o actualiza (upsert) una lista de registros, estampando la
// jerarquía a la que pertenecen. Si el registro ya existía (mismo
// id_registro, caso "editar"), lo reemplaza en su lugar.
export function guardarRegistros(registrosNuevos, { idVersion, area, modulo }) {
  const db = leerDB();
  const ahora = new Date().toISOString();

  registrosNuevos.forEach(reg => {
    const registroCompleto = {
      ...reg,
      id_registro: reg.id_registro || generarId((modulo || 'REG').slice(0, 3).toUpperCase()),
      id_version: idVersion,
      area,
      modulo,
      creado_en: reg.creado_en || ahora,
      actualizado_en: ahora,
    };

    const idx = db.registros.findIndex(r => r.id_registro === registroCompleto.id_registro);
    if (idx >= 0) {
      db.registros[idx] = registroCompleto;
    } else {
      db.registros.push(registroCompleto);
    }
  });

  guardarDB(db);
}

export function eliminarRegistro(idRegistro) {
  const db = leerDB();
  db.registros = db.registros.filter(r => r.id_registro !== idRegistro);
  guardarDB(db);
}

// ===================== AGREGACIONES =====================

export function calcularTotalPresupuestado(registros, categoria = '', mesFiltrado = '') {
  return registros.reduce((sum, reg) => {
    
    if (categoria === 'Forecast de Ventas') {
      // Si el usuario seleccionó un mes específico, multiplicamos la cantidad de ESE mes por el precio
      if (mesFiltrado && reg.detalle_columnas?.cantidades) {
        const cantidadMes = parseFloat(reg.detalle_columnas.cantidades[mesFiltrado]) || 0;
        const precio = parseFloat(reg.detalle_columnas.precio_venta) || 0;
        return sum + (cantidadMes * precio);
      }
      // Si no hay filtro de mes, sumamos todo el año normal
      return sum + (reg.totales?.ingreso_total ?? reg.detalle_columnas?.ingreso_total ?? 0);
    }
    
    // Para módulos estándar (Costos)
    return sum + (reg.totales?.costo_total ?? reg.detalle_columnas?.costo_total ?? 0);
  }, 0);
}

// Suma de todos los registros de una versión, agrupados por área.
// Útil para el "Dashboard Gerencial" mencionado en SelectorVersiones.
export function resumenPorArea(idVersion) {
  const db = leerDB();
  const registrosVersion = db.registros.filter(r => r.id_version === idVersion);
  const resumen = {};
  registrosVersion.forEach(r => {
    const monto = r.totales?.costo_total ?? r.detalle_columnas?.costo_total ?? 0;
    resumen[r.area] = (resumen[r.area] || 0) + monto;
  });
  return resumen;
}

// =====================================================================
// FORECAST DE COMERCIAL — lee todos los registros del módulo "Forecast
// de Ventas" (cualquier área, normalmente 'Comercial') para una versión,
// y los normaliza a la misma forma que usan los formularios de Costeo de
// Crisoles / Costeo de Fundente ({ producto, unidad_negocio, um,
// precio_venta, costo_unitario, cantidades: { Ene: n, Feb: n, ... } }).
// =====================================================================
export function listarForecastComercial(idVersion) {
  const db = leerDB();
  return db.registros
    .filter(r => r.id_version === idVersion && r.modulo === 'Forecast de Ventas')
    .map(r => {
      const dc = r.detalle_columnas || {};
      return {
        id_registro: r.id_registro,
        cliente: dc.cliente || '',
        vendedor: dc.vendedor || '',
        unidad_negocio: dc.unidad_negocio || '',
        producto: dc.producto || '',
        um: dc.um || 'Unidad',
        // Antes se perdían estos dos campos al aplanar el registro, lo que
        // hacía que CosteoCrisolesForm cayera siempre al año actual por
        // defecto al filtrar por año.
        anio_proyeccion: dc.anio_proyeccion || (r.fecha_proyeccion ? r.fecha_proyeccion.split('-')[0] : ''),
        fecha_proyeccion: r.fecha_proyeccion || '',
        precio_venta: dc.precio_venta || 0,
        costo_unitario: dc.costo_unitario || 0,
        cantidades: dc.cantidades || {},
      };
    });
}

// =====================================================================
// AGREGACIÓN POR PROCESO — usada por Costeo de Crisoles y Costeo de
// Fundente para "jalar" a la pantalla de costeo el total ya registrado
// en los módulos regulares (Remuneraciones, Uniforme - EPPs, Servicios,
// Depreciación, Mantenimiento, etc.), agrupado según en qué parte del
// proceso productivo se etiquetó cada registro
// (detalle_columnas.proceso: 'Primer Proceso' | 'Segundo Proceso' | 'CIF'
// para Crisoles, 'Granel' | 'Sachet' para Fundente).
//
// Todo formulario de la app ya guarda `detalle_columnas.proceso` (campo
// "Proceso" en RemuneracionesForm/UniformesForm/BaseRegistroForm), así
// que esta función no necesita tocar nada de esos módulos: solo lee lo
// que ya está persistido.
// =====================================================================
export function obtenerTotalesPorProceso({ idVersion, area, procesos, mes = null }) {
  const db = leerDB();
  const resultado = {};
  procesos.forEach(p => { resultado[p] = 0; });

  db.registros
    .filter(r => r.id_version === idVersion && r.area === area)
    .forEach(r => {
      const proceso = r.detalle_columnas?.proceso;
      if (!proceso || !procesos.includes(proceso)) return;
      if (mes && r.detalle_columnas?.mes_uso && r.detalle_columnas.mes_uso !== mes) return;

      const monto = r.totales?.costo_total ?? r.detalle_columnas?.costo_total ?? 0;
      resultado[proceso] += monto;
    });

  return resultado;
}

// =====================================================================
// PROPAGACIÓN DE COSTEOS — cuando se guarda un registro de "Costeo de
// Crisoles" o "Costeo de Fundente", este además genera automáticamente
// una línea espejo en 'Materias Primas', 'Materiales Auxiliares y
// Suministros' y 'Envases y Embalajes' (misma versión/área), para que
// esos 3 módulos siempre reflejen el desglose que arrojó el costeo, sin
// que el usuario los tenga que llenar dos veces.
//
// `desglose` = { materiasPrimas, maSuministros, envasesEmbalajes } montos
// unitarios x cantidad ya resueltos por el formulario de costeo.
// =====================================================================
export function guardarCosteoDerivado(registroCosteo, desglose, { idVersion, area }) {
  const ahora = new Date().toISOString();
  const idLote = registroCosteo.id_lote;
  const base = {
    fecha_proyeccion: registroCosteo.fecha_proyeccion,
    empleado_dni: '-',
    empleado_nombre: registroCosteo.detalle_columnas?.producto || '-',
  };

  const hijos = [
    {
      modulo: 'Materias Primas',
      monto: desglose.materiasPrimas,
      cuenta: '946252000 - Materiales Auxiliares y Suministros'
    },
    {
      modulo: 'Materiales Auxiliares y Suministros',
      monto: desglose.maSuministros,
      cuenta: '946252000 - Materiales Auxiliares y Suministros'
    },
    {
      modulo: 'Envases y Embalajes',
      monto: desglose.envasesEmbalajes,
      cuenta: '946252000 - Materiales Auxiliares y Suministros'
    },
  ];

  const db = leerDB();

  hijos.forEach(h => {
    if (!h.monto || h.monto <= 0) return;

    const idRegistro = `${idLote}-${h.modulo.slice(0, 3).toUpperCase()}`;
    const registroHijo = {
      ...base,
      id_registro: idRegistro,
      id_lote: idLote,
      id_version: idVersion,
      area,
      modulo: h.modulo,
      detalle_columnas: {
        cuenta_afectada: h.cuenta,
        detalle: `Origen: ${registroCosteo.modulo || 'Costeo'} · ${registroCosteo.detalle_columnas?.producto || ''}`,
        origen_costeo: registroCosteo.id_registro,
        producto: registroCosteo.detalle_columnas?.producto || '',
        proceso: registroCosteo.detalle_columnas?.proceso || '',
        costo_total: h.monto,
      },
      totales: { costo_total: h.monto },
      desglose_contable: [{ id: `cta-${idRegistro}`, cuenta: h.cuenta, monto: h.monto.toFixed(2) }],
      creado_en: ahora,
      actualizado_en: ahora,
    };

    const idx = db.registros.findIndex(r => r.id_registro === idRegistro);
    if (idx >= 0) db.registros[idx] = registroHijo;
    else db.registros.push(registroHijo);
  });

  guardarDB(db);
}

// Cargar maestros iniciales desde data.js si no existen en localStorage
import { maestroEmpleados, maestroCuentas, maestroClientes, maestroProductos, baseDatosUsuarios } from '../config/data';

export function obtenerMaestro(tipo) {
  const guardado = localStorage.getItem(`maestro_${tipo}`);
  if (guardado) return JSON.parse(guardado);
  
  // Si no hay nada guardado, devolvemos el valor original de data.js y lo persistimos
  let inicial = [];
  if (tipo === 'empleados') inicial = maestroEmpleados;
  if (tipo === 'cuentas') inicial = maestroCuentas;
  if (tipo === 'clientes') inicial = maestroClientes;
  if (tipo === 'productos') inicial = maestroProductos;
  if (tipo === 'usuarios') inicial = baseDatosUsuarios;

  localStorage.setItem(`maestro_${tipo}`, JSON.stringify(inicial));
  return inicial;
}

export function guardarEnMaestro(tipo, nuevoItem, esEdicion, idOriginal) {
  let lista = obtenerMaestro(tipo);
  
  // Si es un objeto (como usuarios) o arreglo:
  if (tipo === 'usuarios') {
    // Manejo especial si usuarios es un objeto clave-valor
    lista[nuevoItem.id] = nuevoItem;
  } else {
    if (esEdicion) {
      lista = lista.map(item => (item.dni || item.id || item.ruc) === idOriginal ? nuevoItem : item);
    } else {
      lista.push(nuevoItem);
    }
  }
  
  localStorage.setItem(`maestro_${tipo}`, JSON.stringify(lista));
  return lista;
}

export function eliminarDeMaestro(tipo, idUnico) {
  let lista = obtenerMaestro(tipo);
  if (tipo === 'usuarios') {
    delete lista[idUnico];
  } else {
    lista = lista.filter(item => (item.dni || item.id || item.ruc) !== idUnico);
  }
  localStorage.setItem(`maestro_${tipo}`, JSON.stringify(lista));
  return lista;
}