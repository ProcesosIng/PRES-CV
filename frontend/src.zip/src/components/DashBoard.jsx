import React, { useState, useEffect, useCallback } from 'react';
import { datosAreas, configModulos, maestroEmpleados, maestroCuentas, maestroClientes, maestroProductos, baseDatosUsuarios, MESES, UNIDADES_NEGOCIO} from '../config/data';
import { modulosVisiblesParaArea } from '../config/modulosPorArea';
import { listarRegistros, eliminarRegistro as eliminarRegistroDB, calcularTotalPresupuestado, obtenerMaestro, guardarEnMaestro, eliminarDeMaestro } from '../data/store';
import RemuneracionesFila from './modulos/RemuneracionesTabla';
import UniformesFila from './modulos/UniformesTabla';
import PlanViajeFila from './modulos/PlanViajeTabla';
import PlanDepreciacionFila from './modulos/PlanDepreciacionTabla';
import PlanMantenimientoFila from './modulos/PlanMantenimientoTabla';
import UtilesOficinaFila from './modulos/UtilesOficinaTabla';
import ForecastComercialFila from './modulos/ForecastComercialTabla';
import CosteoCrisolesFila from './modulos/CosteoCrisolesTabla';
import CosteoFundenteFila from './modulos/CosteoFundenteTabla';
import TablaGenerica from './common/TablaGenerica';
import Offcanvas from './Offcanvas';

// Módulos con tabla propia (fila especializada). Cualquier módulo que NO
// esté en este mapa cae al comodín genérico TablaGenerica.


const FILAS_ESPECIFICAS = {
  'Remuneraciones': RemuneracionesFila,
  'Uniforme - EPPs': UniformesFila,
  'Plan de Viaje': PlanViajeFila,
  'Plan de Depreciación': PlanDepreciacionFila,
  'Plan de Mantenimiento': PlanMantenimientoFila,
  'Utiles de Oficina': UtilesOficinaFila,
  'Forecast de Ventas': ForecastComercialFila,
  'Costeo de Crisoles': CosteoCrisolesFila,
  'Costeo de Fundente': CosteoFundenteFila,
};

export default function Dashboard({
  usuario,
  vistaActual,
  setVistaActual,
  areaSeleccionada,
  setAreaSeleccionada,
  categoriaSeleccionada,
  setCategoriaSeleccionada,
  versionActiva,
  onCambiarVersion,
}) {
  const [isOffcanvasOpen, setIsOffcanvasOpen] = useState(false);
  const [registroSeleccionado, setRegistroSeleccionado] = useState(null);
  const [modoAccion, setModoAccion] = useState('nuevo');
  // Registros de la combinación (versión, área, módulo) actualmente abierta.
  // Antes esto vivía en un único useState indexado solo por nombre de
  // módulo (registrosPorCategoria), lo que mezclaba datos de áreas
  // distintas que comparten el mismo módulo. Ahora se lee directamente
  // del store, ya aislado por jerarquía completa.
  const [registros, setRegistros] = useState([]);

  const [filtroEmpleado, setFiltroEmpleado] = useState('');
  const [filtroFechaInicio, setFiltroFechaInicio] = useState('');
  const [filtroFechaFin, setFiltroFechaFin] = useState('');

  const [filtroMes, setFiltroMes] = useState('');
  const [filtroCliente, setFiltroCliente] = useState('');
  const [filtroProducto, setFiltroProducto] = useState('');
  const [filtroUnidadNegocio, setFiltroUnidadNegocio] = useState('');

  const [listaEmpleados, setListaEmpleados] = useState([]);
  const [listaCuentas, setListaCuentas] = useState([]);
  const [listaClientes, setListaClientes] = useState([]);
  const [listaUsuarios, setListaUsuarios] = useState({});
  const [listaProductos, setListaProductos] = useState([]);

  const [tamanoPagina, setTamanoPagina] = useState(25);
  const [paginaActual, setPaginaActual] = useState(1);  

  const [itemMaestroSeleccionado, setItemMaestroSeleccionado] = useState(null);
  const [modoAccionMaestro, setModoAccionMaestro] = useState('nuevo'); // 'ver', 'editar', 'nuevo'
  const [isModalMaestroAbierto, setIsModalMaestroAbierto] = useState(false);

  const recargarRegistros = useCallback(() => {
    if (!versionActiva || !areaSeleccionada || !categoriaSeleccionada) {
      setRegistros([]);
      return;
    }
    setRegistros(
      listarRegistros({
        idVersion: versionActiva,
        area: areaSeleccionada,
        modulo: categoriaSeleccionada,
      })
    );
  }, [versionActiva, areaSeleccionada, categoriaSeleccionada]);

  useEffect(() => {
  setPaginaActual(1);
  }, [categoriaSeleccionada, filtroEmpleado, filtroFechaInicio, filtroFechaFin, filtroMes, filtroCliente, filtroProducto, filtroUnidadNegocio]);  

  useEffect(() => {
    recargarRegistros();
  }, [recargarRegistros]);

  useEffect(() => {
    if (vistaActual === 'maestros_empleados') setListaEmpleados(obtenerMaestro('empleados'));
    if (vistaActual === 'maestros_cuentas') setListaCuentas(obtenerMaestro('cuentas'));
    if (vistaActual === 'maestros_clientes') setListaClientes(obtenerMaestro('clientes'));
    if (vistaActual === 'maestros_usuarios') setListaUsuarios(obtenerMaestro('usuarios'));
    if (vistaActual === 'maestros_productos') setListaProductos(obtenerMaestro('productos'));
  }, [vistaActual]);

  const abrirCategoria = (cat) => {
    setCategoriaSeleccionada(cat);
    setVistaActual('tabla');
  };

  const abrirArea = (area) => {
    setAreaSeleccionada(area);
    setCategoriaSeleccionada('');
    setVistaActual('categorias');
  };

  const eliminarRegistro = (id) => {
    if (window.confirm('¿Estás seguro de eliminar este registro?')) {
      eliminarRegistroDB(id);
      recargarRegistros();
    }
  };

  // LÓGICA DE FILTRADO Y TOTALES (sobre los registros ya aislados por jerarquía)
  const registrosFiltrados = registros.filter(reg => {
    // Si NO estamos en Forecast, usamos los filtros originales
    if (categoriaSeleccionada !== 'Forecast de Ventas') {
      let cumpleEmpleado = true;
      let cumpleInicio = true;
      let cumpleFin = true;

      if (filtroEmpleado) {
        const busqueda = filtroEmpleado.toLowerCase();
        cumpleEmpleado =
          reg.empleado_nombre?.toLowerCase().includes(busqueda) ||
          reg.empleado_dni?.includes(busqueda);
      }
      if (filtroFechaInicio) cumpleInicio = reg.fecha_proyeccion >= filtroFechaInicio;
      if (filtroFechaFin) cumpleFin = reg.fecha_proyeccion <= filtroFechaFin;

      return cumpleEmpleado && cumpleInicio && cumpleFin;
    }
    // SI ESTAMOS EN FORECAST, usamos los filtros comerciales
    if (categoriaSeleccionada === 'Forecast de Ventas') {
      const dc = reg.detalle_columnas || {};
      let cumpleMes = true;
      let cumpleCliente = true;
      let cumpleProducto = true;
      let cumpleUnidad = true;
      let cumpleEmpleado = true;

      // Si elige un mes, solo mostramos las filas donde la cantidad proyectada en ese mes sea mayor a 0
      
      if (filtroMes) {
        cumpleMes = (parseFloat(dc.cantidades?.[filtroMes]) || 0) > 0;
      }
      if (filtroCliente) cumpleCliente = dc.cliente?.toLowerCase().includes(filtroCliente.toLowerCase());
      if (filtroProducto) cumpleProducto = dc.producto?.toLowerCase().includes(filtroProducto.toLowerCase());
      if (filtroUnidadNegocio) cumpleUnidad = dc.unidad_negocio === filtroUnidadNegocio;

      if (filtroEmpleado) {
        const busqueda = filtroEmpleado.toLowerCase();
        cumpleEmpleado =
          reg.empleado_nombre?.toLowerCase().includes(busqueda) ||
          reg.empleado_dni?.includes(busqueda);
      }
      

      return cumpleMes && cumpleCliente && cumpleProducto && cumpleUnidad && cumpleEmpleado;
    }
  });

  const totalPresupuestado = calcularTotalPresupuestado(registrosFiltrados, categoriaSeleccionada, filtroMes);

  const totalPaginas = Math.max(1, Math.ceil(registrosFiltrados.length / tamanoPagina));
  const registrosPagina = registrosFiltrados.slice(
    (paginaActual - 1) * tamanoPagina,
    paginaActual * tamanoPagina
  );

  return (
    <div className="page" style={{ display: 'flex', minHeight: '100vh', position: 'relative' }}>

      {/* VISTA 1: ÁREAS */}
      {vistaActual === 'areas' && (
        <section style={{ width: '100%', maxWidth: '1200px', margin: '0 auto', padding: '10px 20px' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            flexWrap: 'wrap', gap: '20px', marginBottom: '30px',
            borderBottom: '1px solid #e2e8f0', paddingBottom: '20px'
          }}>
            <div>
              <div style={{ fontSize: '12px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '6px' }}>
                Panel general
              </div>
              <h2 style={{ margin: 0, fontSize: '24px', color: '#0f172a' }}>
                Seleccione un área para revisión
              </h2>
            </div>

            <button
              onClick={() => { if (typeof onCambiarVersion === 'function') onCambiarVersion(); }}
              style={{
                background: '#334155', color: 'white', border: 'none', padding: '10px 18px',
                borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600,
                display: 'flex', alignItems: 'center', gap: '8px', whiteSpace: 'nowrap',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}
            >
              <span>📂</span>
              Versión: {versionActiva ? versionActiva.toUpperCase() : 'V1'} (Cambiar)
            </button>
          </div>

          <div className="area-grid">
            {usuario.areasPermitidas.map((area) => {
              const info = datosAreas[area];
              if (!info) return null;
              return (
                <button key={area} onClick={() => abrirArea(area)} className="area-card" style={{ '--accent-c': info.color }}>
                  <div className="bar-top"></div>
                  <span className="ic">{info.ic}</span>
                  <h3>{area}</h3>
                  <div className="amt">Presupuesto asignado · S/ {info.presupuesto}</div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${info.consumido}%` }}></div>
                  </div>
                  <div className="progress-meta">
                    <span>{info.consumido}% ejecutado</span>
                    <span>{100 - info.consumido}% disponible</span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* VISTA 2: CATEGORÍAS */}
      {vistaActual === 'categorias' && (
        <section style={{ width: '100%', maxWidth: '1200px', margin: '0 auto', padding: '10px 20px' }}>
          <button
            onClick={() => { setVistaActual('areas'); setAreaSeleccionada(''); }}
            style={{ background: 'white', border: '1px solid #cbd5e1', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600, marginBottom: '24px', color: '#334155' }}
          >
            ← Volver a áreas
          </button>

          <div style={{ marginBottom: '30px', borderBottom: '1px solid #e2e8f0', paddingBottom: '20px' }}>
            <div style={{ fontSize: '12px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '6px' }}>
              Presupuestos
            </div>
            <h2 style={{ margin: 0, fontSize: '24px', color: '#0f172a' }}>
              Menú de {areaSeleccionada}
            </h2>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(280px, calc(50% - 10px)), 1fr))',
            gap: '10px'
          }}>
            {Object.keys(configModulos)
              .filter(cat => {
                const permitidos = modulosVisiblesParaArea(areaSeleccionada);
                return permitidos ? permitidos.includes(cat) : true;
              })
              .map(cat => (
                <button
                  key={cat}
                  onClick={() => abrirCategoria(cat)}
                  className="cat-tile"
                  style={{ width: '100%', margin: 0 }}
                >
                  <span className="ic">{configModulos[cat].icono || '📂'}</span>
                  <h4>{cat}</h4>
                </button>
              ))}
          </div>
        </section>
      )}

      {/* VISTA 3: TABLA DE PRESUPUESTOS DINÁMICA */}
      {vistaActual === 'tabla' && (
        <section style={{ width: '100%', maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>

          <button onClick={() => { setVistaActual('categorias'); setCategoriaSeleccionada(''); }} className="btn-back">← Volver al menú</button>
          <div className="page-head" style={{ marginTop: '20px' }}>
            <div className="eyebrow">Detalle presupuestal</div>
            <h2>{categoriaSeleccionada} — {areaSeleccionada}</h2>
          </div>

          <div style={{
            display: 'flex', gap: '20px', marginBottom: '24px', marginTop: '16px',
            background: 'white', padding: '16px', borderRadius: '8px',
            border: '1px solid var(--line)', flexWrap: 'wrap'
          }}>
            <div style={{
              background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px',
              minWidth: '240px', flex: '0 1 auto', display: 'flex', flexDirection: 'column', justifyContent: 'center'
            }}>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 700, letterSpacing: '0.5px' }}>TOTAL PRESUPUESTADO</div>
              <div style={{ fontSize: '26px', fontWeight: 800, color: '#0f172a', margin: '4px 0' }}>
                S/ {totalPresupuestado.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div style={{ fontSize: '12px', color: '#166534', fontWeight: 600 }}>
                {registrosFiltrados.length} registro(s) listado(s)
              </div>
            </div>

            {/*Filtros de campos*/}
            <div style={{ display: 'flex', gap: '16px', flex: '3 1 450px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
              
              {categoriaSeleccionada === 'Forecast de Ventas' ? (
                // BARRA DE FILTROS COMERCIALES
                <>
                  
                  <div className="form-group" style={{ margin: 0, flex: '1 1 100%', minWidth: '220px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase' }}>VENDEDOR (Buscar)</label>
                    <input 
                      type="text" 
                      placeholder="Ej. Gerardo..." 
                      value={filtroEmpleado} 
                      onChange={e => setFiltroEmpleado(e.target.value)} 
                      style={{ width: '100%' }} 
                    />
                  </div>

                  <div className="form-group" style={{ margin: 0, flex: '1 1 100px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES</label>
                    <select value={filtroMes} onChange={e => setFiltroMes(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }}>
                      <option value="">Todo el Año</option>
                      {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div className="form-group" style={{ margin: 0, flex: '1 1 140px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>U. NEGOCIO</label>
                    <select value={filtroUnidadNegocio} onChange={e => setFiltroUnidadNegocio(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }}>
                      <option value="">Todas</option>
                      {UNIDADES_NEGOCIO.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                  </div>
                  <div className="form-group" style={{ margin: 0, flex: '1 1 140px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CLIENTE (Buscar)</label>
                    <input type="text" placeholder="Ej. Minera..." value={filtroCliente} onChange={e => setFiltroCliente(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                  </div>
                  <div className="form-group" style={{ margin: 0, flex: '1 1 140px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRODUCTO (Buscar)</label>
                    <input type="text" placeholder="Ej. Crisol..." value={filtroProducto} onChange={e => setFiltroProducto(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                  </div>
                </>
              ) : (
                // BARRA DE FILTROS ESTÁNDAR (RRHH, Viajes, etc)
                <>
                  <div className="form-group" style={{ margin: 0, flex: '1 1 100%', minWidth: '220px' }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase' }}>Buscar Personal (DNI / Nombre)</label>
                    <input type="text" placeholder="Ej. Juana o 0753..." value={filtroEmpleado} onChange={e => setFiltroEmpleado(e.target.value)} style={{ width: '100%' }} />
                  </div>
                  <div style={{ display: 'flex', gap: '12px', flex: '1 1 100%', flexWrap: 'wrap' }}>
                    <div className="form-group" style={{ margin: 0, flex: '1 1 140px' }}>
                      <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase' }}>Fecha Desde</label>
                      <input type="date" value={filtroFechaInicio} onChange={e => setFiltroFechaInicio(e.target.value)} style={{ width: '100%' }} />
                    </div>
                    <div className="form-group" style={{ margin: 0, flex: '1 1 140px' }}>
                      <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase' }}>Fecha Hasta</label>
                      <input type="date" value={filtroFechaFin} onChange={e => setFiltroFechaFin(e.target.value)} style={{ width: '100%' }} />
                    </div>
                  </div>
                </>
              )}

            </div>

          </div>

          <div className="panel" style={{ width: '100%', margin: '0 auto' }}>
            
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--line)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f8fafc', borderRadius: '8px 8px 0 0' }}>
              <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--primary-700)' }}>Registros de {categoriaSeleccionada}</span>
              <button className="btn-add" onClick={() => {
                setRegistroSeleccionado(null);
                setModoAccion('nuevo');
                setIsOffcanvasOpen(true);
              }}>
                + Nuevo
              </button>
            </div>

            <div style={{ overflowX: 'auto' }}>
              <table className="data">
                <thead>
                  <tr>
                    {configModulos[categoriaSeleccionada]?.columnasTabla.map((col, idx) => (
                      <th key={idx} style={{ textAlign: col.alinear }}>{col.nombre}</th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {registrosFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={configModulos[categoriaSeleccionada]?.columnasTabla.length || 5} style={{ textAlign: 'center', padding: '30px', color: 'var(--text-low)' }}>
                        No hay datos registrados aún.
                      </td>
                    </tr>
                  ) : (
                    <>
                      {FILAS_ESPECIFICAS[categoriaSeleccionada] ? (
                        registrosPagina.map(reg => {
                          const FilaEspecifica = FILAS_ESPECIFICAS[categoriaSeleccionada];
                          return (
                            <FilaEspecifica
                              key={reg.id_registro} reg={reg} filtroMes={filtroMes}
                              onVer={(item) => { setRegistroSeleccionado(item); setModoAccion('ver'); setIsOffcanvasOpen(true); }}
                              onEditar={(item) => { setRegistroSeleccionado(item); setModoAccion('editar'); setIsOffcanvasOpen(true); }}
                              onBorrar={eliminarRegistro}
                            />
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={configModulos[categoriaSeleccionada]?.columnasTabla.length || 6} style={{ padding: 0, border: 'none' }}>
                            <TablaGenerica
                              registros={registrosPagina}
                              onVer={(item) => { setRegistroSeleccionado(item); setModoAccion('ver'); setIsOffcanvasOpen(true); }}
                              onEditar={(item) => { setRegistroSeleccionado(item); setModoAccion('editar'); setIsOffcanvasOpen(true); }}
                              onBorrar={eliminarRegistro}
                            />
                          </td>
                        </tr>
                      )}
                    </>
                  )}
                </tbody>
              </table>
            
            {registrosFiltrados.length > 0 && (
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 20px', borderTop: '1px solid var(--line)', background: '#f8fafc',
              borderRadius: '0 0 8px 8px', flexWrap: 'wrap', gap: '10px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#64748b' }}>
                Mostrar
                <select
                  value={tamanoPagina}
                  onChange={e => { setTamanoPagina(parseInt(e.target.value, 10)); setPaginaActual(1); }}
                  style={{ padding: '4px 8px', border: '1px solid #cbd5e1', borderRadius: '4px' }}
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
                registros por página · {registrosFiltrados.length} en total
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <button
                  type="button"
                  disabled={paginaActual === 1}
                  onClick={() => setPaginaActual(p => Math.max(1, p - 1))}
                  style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', background: paginaActual === 1 ? '#f1f5f9' : 'white', cursor: paginaActual === 1 ? 'not-allowed' : 'pointer', fontSize: '13px' }}
                >
                  ← Anterior
                </button>
                <span style={{ fontSize: '13px', color: '#334155', fontWeight: 600 }}>
                  Página {paginaActual} de {totalPaginas}
                </span>
                <button
                  type="button"
                  disabled={paginaActual === totalPaginas}
                  onClick={() => setPaginaActual(p => Math.min(totalPaginas, p + 1))}
                  style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', background: paginaActual === totalPaginas ? '#f1f5f9' : 'white', cursor: paginaActual === totalPaginas ? 'not-allowed' : 'pointer', fontSize: '13px' }}
                >
                  Siguiente →
                </button>
              </div>
            </div>
          )}


            </div>
          </div>

          {isOffcanvasOpen && (
            <Offcanvas
              isOpen={isOffcanvasOpen}
              onClose={() => {
                setIsOffcanvasOpen(false);
                setRegistroSeleccionado(null);
              }}
              categoria={categoriaSeleccionada}
              idVersion={versionActiva}
              area={areaSeleccionada}
              registroParaVer={registroSeleccionado}
              modo={modoAccion}
              onGuardado={recargarRegistros}
            />
          )}
        </section>
      )}

      {/* VISTA MAESTROS */}
      {vistaActual.startsWith('maestros_') && (
        <section style={{ flex: 1, padding: '24px', overflowX: 'auto', boxSizing: 'border-box' }}>
          <button onClick={() => { setVistaActual('areas'); setAreaSeleccionada(''); setCategoriaSeleccionada(''); }} className="btn-back">← Volver al inicio</button>
          <div className="page-head" style={{ marginTop: '20px' }}>
            <div className="eyebrow">Datos maestros</div>
            <h2>
              Maestro de {
                vistaActual === 'maestros_empleados' ? 'Empleados' :
                vistaActual === 'maestros_cuentas' ? 'Cuentas' :
                vistaActual === 'maestros_clientes' ? 'Clientes' :
                vistaActual === 'maestros_usuarios' ? 'Usuarios' : 'Productos'
              }
            </h2>
          </div>

          <div className="panel" style={{ width: '100%', background: 'white', borderRadius: '8px', border: '1px solid #e2e8f0', marginTop: '16px', overflowX: 'auto' }}>
            <table className="table-custom" style={{ width: '100%', borderCollapse: 'collapse', minWidth: '900px' }}>

              {/* Encabezados*/}
              <thead>
                <tr style={{ borderBottom: '1px solid #e2e8f0', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>
                  {vistaActual === 'maestros_empleados' ? (
                    <>
                      <th style={{ padding: '12px' }}>DNI / ID</th>
                      <th style={{ padding: '12px' }}>Nombre</th>
                      <th style={{ padding: '12px' }}>Cargo</th>
                      <th style={{ padding: '12px' }}>Sueldo</th>
                      <th style={{ padding: '12px' }}>Asignación Familiar</th>
                      <th style={{ padding: '12px' }}>Distribución</th>
                      <th style={{ padding: '12px' }}>Proceso</th>
                      <th style={{ padding: '12px' }}>Área encargada</th>
                      
                    </>
                  ) : vistaActual === 'maestros_cuentas' ? (
                    <>
                      <th style={{ padding: '12px' }}>Código Cuenta</th>
                      <th style={{ padding: '12px' }}>Nombre de Cuenta</th>
                      <th style={{ padding: '12px' }}>Categoría</th>
                      <th style={{ padding: '12px' }}>Subcategoría</th>
                      
                    </>
                  ) : vistaActual === 'maestros_clientes' ? (
                    <>
                      <th style={{ padding: '12px' }}>RUC / ID</th>
                      <th style={{ padding: '12px' }}>Razón Social / Cliente</th>
                      <th style={{ padding: '12px' }}>Zona</th>
                      <th style={{ padding: '12px' }}>Vendedor</th>
                      <th style={{ padding: '12px' }}>País</th>
                      <th style={{ padding: '12px' }}>Tipo de cliente</th>
                      <th style={{ padding: '12px' }}>Zona</th>
                      
                    </>
                  ) : vistaActual === 'maestros_usuarios' ? (
                    <>
                      <th style={{ padding: '12px' }}>ID Usuario</th>
                      <th style={{ padding: '12px' }}>Nombre de Usuario</th>
                      <th style={{ padding: '12px' }}>Iniciales</th>
                      <th style={{ padding: '12px' }}>Rol / Permiso</th>
                      
                    </>
                  ) : (
                    <>
                      <th style={{ padding: '12px' }}>Código / SKU</th>
                      <th style={{ padding: '12px' }}>Descripción de Producto</th>
                      <th style={{ padding: '12px' }}>Unidad de Medida</th>
                      <th style={{ padding: '12px' }}>Precio de Venta</th>
                      <th style={{ padding: '12px' }}>Costo</th>
                      <th style={{ padding: '12px' }}>Categoría</th>
                      
                    </>
                  )}
                  <th style={{ padding: '12px', textAlign: 'center' }}>Acciones</th>
                </tr>
              </thead>

              {/* Filas de tabla, datos*/}
              <tbody>
                {vistaActual === 'maestros_empleados' ? (
                  listaEmpleados.map((emp) => (
                    <tr key={emp.dni || emp.id} style={{ borderBottom: '1px solid #f1f5f9', fontSize: '13px', textAlign: 'center' }}>
                      <td style={{ padding: '12px' }}>{emp.dni || emp.id}</td>
                      <td style={{ padding: '12px' }}>{emp.nombre}</td>
                      <td style={{ padding: '12px' }}>{emp.cargo || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{emp.sueldo || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{emp.asigFam || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{emp.distribucion || '100%'}</td>
                      <td style={{ padding: '12px' }}>{emp.proceso || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{emp.area || 'Sin asignar'}</td>
                      {/* botones de accion*/}                    
                      <td style={{ padding: '12px', textAlign: 'center', display: 'flex', gap: '8px', justifyContent: 'center' }}>
                    
                          {/* Botón Ver */}
                          <button 
                            onClick={() => {
                              setItemMaestroSeleccionado(emp);
                              setModoAccionMaestro('ver');
                              setIsModalMaestroAbierto(true);
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                            title="Ver"
                          >
                            👁️
                          </button>

                          {/* Botón Editar */}
                          <button 
                            onClick={() => {
                              setItemMaestroSeleccionado(emp);
                              setModoAccionMaestro('editar');
                              setIsModalMaestroAbierto(true);
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                            title="Editar"
                          >
                            ✏️
                          </button>

                          {/* Botón Eliminar */}
                          <button 
                            onClick={() => {
                              if (window.confirm('¿Desea eliminar este registro?')) {
                                const actualizada = eliminarDeMaestro('empleados', emp.dni || emp.id);
                                setListaEmpleados([...actualizada]);
                              }
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: '#ef4444' }}
                            title="Eliminar"
                          >
                            🗑️
                          </button>
                      </td>
                    
                    </tr>
                  ))
                ) : vistaActual === 'maestros_cuentas' ? (
                  listaCuentas.map((cta) => (
                    <tr key={cta.id} style={{ borderBottom: '1px solid #f1f5f9', fontSize: '13px' }}>
                      <td style={{ padding: '12px' }}>{cta.id}</td>
                      <td style={{ padding: '12px' }}>{cta.nombre}</td>
                      <td style={{ padding: '12px' }}>{cta.categoria}</td>
                      <td style={{ padding: '12px' }}>{cta.subcategoria}</td>
                      {/*botones*/}
                      <td style={{ padding: '12px', textAlign: 'center', display: 'flex', gap: '8px', justifyContent: 'center' }}>
                        {/* Botón Ver */}
                        <button 
                            onClick={() => {
                              setItemMaestroSeleccionado(cta);
                              setModoAccionMaestro('ver');
                              setIsModalMaestroAbierto(true);
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                            title="Ver"
                          >
                            👁️
                        </button>

                        {/* Botón Editar */}
                        <button 
                            onClick={() => {
                              setItemMaestroSeleccionado(cta);
                              setModoAccionMaestro('editar');
                              setIsModalMaestroAbierto(true);
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                            title="Editar"
                          >
                            ✏️
                        </button>

                        {/* Botón Eliminar */}
                        <button 
                            onClick={() => {
                              if (window.confirm('¿Desea eliminar este registro?')) {
                                const actualizada = eliminarDeMaestro('cuenta', cta.nombre || cta.id);
                                setListaCuentas([...actualizada]);
                              }
                            }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: '#ef4444' }}
                            title="Eliminar"
                          >
                            🗑️
                        </button>
                      </td>                  
                    
                    </tr>
                  ))
                ) : vistaActual === 'maestros_clientes' ? (
                  listaClientes.map((cli) => (
                    <tr key={cli.ruc || cli.id} style={{ borderBottom: '1px solid #f1f5f9', fontSize: '13px' }}>
                      <td style={{ padding: '12px' }}>{cli.ruc || cli.id}</td>
                      <td style={{ padding: '12px' }}>{cli.nombre}</td>
                      <td style={{ padding: '12px' }}>{cli.zona || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{cli.vendedor || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{cli.pais || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{cli.tipo || 'Sin asignar'}</td>
                      <td style={{ padding: '12px' }}>{cli.zona || 'Sin asignar'}</td>
                      {/*botones*/}
                      <td style={{ padding: '12px', textAlign: 'center', display: 'flex', gap: '8px', justifyContent: 'center' }}>
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(cli);
                            setModoAccionMaestro('ver');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Ver"
                        >
                          👁️
                        </button>

                        {/* Botón Editar */}
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(cli);
                            setModoAccionMaestro('editar');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Editar"
                        >
                          ✏️
                        </button>

                        {/* Botón Eliminar */}
                        <button 
                          onClick={() => {
                            if (window.confirm('¿Desea eliminar este registro?')) {
                              const actualizada = eliminarDeMaestro('clientes', cli.ruc || cli.nombre);
                              setListaClientes([...actualizada]);
                            }
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: '#ef4444' }}
                          title="Eliminar"
                        >
                          🗑️
                        </button>
                      </td>
                    
                    </tr>
                  ))
                ) : vistaActual === 'maestros_usuarios' ? (
                  Object.values(listaUsuarios || []).map((usr, idx) => (
                    <tr key={idx} style={{ borderBottom: '1px solid #f1f5f9', fontSize: '13px' }}>
                      <td style={{ padding: '12px' }}>{usr.id || Object.keys(baseDatosUsuarios)[idx]}</td>
                      <td style={{ padding: '12px' }}>{usr.nombre}</td>
                      <td style={{ padding: '12px' }}>{usr.iniciales}</td>
                      <td style={{ padding: '12px' }}>{usr.rol || 'Usuario'}</td>
                      {/*botones*/}
                      <td style={{ padding: '12px', textAlign: 'center', display: 'flex', gap: '8px', justifyContent: 'center' }}>
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(usr);
                            setModoAccionMaestro('ver');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Ver"
                        >
                          👁️
                        </button>

                        {/* Botón Editar */}
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(usr);
                            setModoAccionMaestro('editar');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Editar"
                        >
                          ✏️
                        </button>

                        {/* Botón Eliminar */}
                        <button 
                          onClick={() => {
                            if (window.confirm('¿Desea eliminar este registro?')) {
                              const actualizada = eliminarDeMaestro('usuarios', usr.nombre || usr.id);
                              setListaUsuarios([...actualizada]);
                            }
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: '#ef4444' }}
                          title="Eliminar"
                        >
                          🗑️
                        </button>
                      </td>
                    
                    </tr>
                  ))
                ) : (
                  listaProductos.map((prod) => (
                    <tr key={prod.id || prod.codigo} style={{ borderBottom: '1px solid #f1f5f9', fontSize: '13px' }}>
                      <td style={{ padding: '12px' }}>{prod.id || prod.codigo}</td>
                      <td style={{ padding: '12px' }}>{prod.nombre || prod.descripcion}</td>
                      <td style={{ padding: '12px' }}>{prod.unidad || 'Unid'}</td>
                      <td style={{ padding: '12px' }}>{prod.pv || 'Unid'}</td>
                      <td style={{ padding: '12px' }}>{prod.costo || 'Unid'}</td>
                      <td style={{ padding: '12px' }}>{prod.categoria || 'Unid'}</td>
                      {/*botones*/}
                      <td style={{ padding: '12px', textAlign: 'center', display: 'flex', gap: '8px', justifyContent: 'center' }}>
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(prod);
                            setModoAccionMaestro('ver');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Ver"
                        >
                          👁️
                        </button>

                        {/* Botón Editar */}
                        <button 
                          onClick={() => {
                            setItemMaestroSeleccionado(prod);
                            setModoAccionMaestro('editar');
                            setIsModalMaestroAbierto(true);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}
                          title="Editar"
                        >
                          ✏️
                        </button>

                        {/* Botón Eliminar */}
                        <button 
                          onClick={() => {
                            if (window.confirm('¿Desea eliminar este registro?')) {
                              const actualizada = eliminarDeMaestro('producto', prod.nombre || prod.codigo);
                              setListaProductos([...actualizada]);
                            }
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: '#ef4444' }}
                          title="Eliminar"
                        >
                          🗑️
                        </button>
                      </td>
                    
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* ── MODAL FLOTANTE PARA VER / EDITAR / CREAR MAESTROS ── */}
          {isModalMaestroAbierto && (
            <div style={{
              position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
              background: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000
            }}>
              <div style={{ background: 'white', padding: '24px', borderRadius: '8px', width: '450px', maxWidth: '90%', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
                
                <h3 style={{ marginBottom: '16px', textTransform: 'capitalize', fontSize: '18px', color: '#0f172a' }}>
                  {modoAccionMaestro === 'ver' ? 'Ver' : modoAccionMaestro === 'editar' ? 'Editar' : 'Nuevo'} Registro
                </h3>

                <form onSubmit={(e) => {
                  e.preventDefault();
                  if (modoAccionMaestro === 'ver') {
                    setIsModalMaestroAbierto(false);
                    return;
                  }

                  let tipo = 'empleados';
                  if (vistaActual === 'maestros_cuentas') tipo = 'cuentas';
                  if (vistaActual === 'maestros_clientes') tipo = 'clientes';
                  if (vistaActual === 'maestros_usuarios') tipo = 'usuarios';
                  if (vistaActual === 'maestros_productos') tipo = 'productos';

                  const formData = new FormData(e.target);
                  const datosNuevos = Object.fromEntries(formData.entries());
                  
                  const idOriginal = itemMaestroSeleccionado?.dni || itemMaestroSeleccionado?.id || itemMaestroSeleccionado?.ruc || itemMaestroSeleccionado?.nombre;

                  const listaActualizada = guardarEnMaestro(tipo, datosNuevos, modoAccionMaestro === 'editar', idOriginal);

                  if (tipo === 'empleados') setListaEmpleados([...listaActualizada]);
                  if (tipo === 'cuentas') setListaCuentas([...listaActualizada]);
                  if (tipo === 'clientes') setListaClientes([...listaActualizada]);
                  if (tipo === 'usuarios') setListaUsuarios({ ...listaActualizada });
                  if (tipo === 'productos') setListaProductos([...listaActualizada]);

                  setIsModalMaestroAbierto(false);
                }}>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '60vh', overflowY: 'auto', paddingRight: '4px' }}>
                    
                    {/* Campos dinámicos según el tipo de maestro */}
                    {vistaActual === 'maestros_empleados' && (
                      <>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DNI / ID:</label>
                          <input name="id" defaultValue={itemMaestroSeleccionado?.dni || itemMaestroSeleccionado?.id || ''} disabled={modoAccionMaestro === 'ver' || modoAccionMaestro === 'editar'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Nombre:</label>
                          <input name="nombre" defaultValue={itemMaestroSeleccionado?.nombre || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Cargo:</label>
                          <input name="cargo" defaultValue={itemMaestroSeleccionado?.cargo || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Sueldo:</label>
                          <input name="sueldo" type="number" defaultValue={itemMaestroSeleccionado?.sueldo || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Asignación Familiar:</label>
                          <input name="asigFam" type="number" defaultValue={itemMaestroSeleccionado?.asigFam || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                      </>
                    )}

                    {vistaActual === 'maestros_cuentas' && (
                      <>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Código Cuenta:</label>
                          <input name="id" defaultValue={itemMaestroSeleccionado?.id || ''} disabled={modoAccionMaestro === 'ver' || modoAccionMaestro === 'editar'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Nombre de Cuenta:</label>
                          <input name="nombre" defaultValue={itemMaestroSeleccionado?.nombre || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Categoría:</label>
                          <input name="categoria" defaultValue={itemMaestroSeleccionado?.categoria || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Subcategoría:</label>
                          <input name="subcategoria" defaultValue={itemMaestroSeleccionado?.subcategoria || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                      </>
                    )}

                    {vistaActual === 'maestros_productos' && (
                      <>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Código / SKU:</label>
                          <input name="id" defaultValue={itemMaestroSeleccionado?.id || itemMaestroSeleccionado?.codigo || ''} disabled={modoAccionMaestro === 'ver' || modoAccionMaestro === 'editar'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Descripción:</label>
                          <input name="nombre" defaultValue={itemMaestroSeleccionado?.nombre || itemMaestroSeleccionado?.descripcion || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Unidad de medida:</label>
                          <input name="unidad" defaultValue={itemMaestroSeleccionado?.unidad || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Precio de Venta:</label>
                          <input name="pv" type="number" defaultValue={itemMaestroSeleccionado?.pv || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Costo:</label>
                          <input name="costo" type="number" defaultValue={itemMaestroSeleccionado?.costo || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Categoria:</label>
                          <input name="categoria" defaultValue={itemMaestroSeleccionado?.categoria || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                      </>
                    )}

                    {vistaActual === 'maestros_clientes' && (
                      <>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>RUC:</label>
                          <input name="id" defaultValue={itemMaestroSeleccionado?.id || itemMaestroSeleccionado?.codigo || ''} disabled={modoAccionMaestro === 'ver' || modoAccionMaestro === 'editar'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Nombre de empresa:</label>
                          <input name="nombre" defaultValue={itemMaestroSeleccionado?.nombre || itemMaestroSeleccionado?.descripcion || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Zona:</label>
                          <input name="zona" defaultValue={itemMaestroSeleccionado?.zona || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Vendedor:</label>
                          <input name="vendedor" defaultValue={itemMaestroSeleccionado?.vendedor || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>País:</label>
                          <input name="pais" defaultValue={itemMaestroSeleccionado?.pais || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Tipo de Negocio:</label>
                          <input name="tipo" defaultValue={itemMaestroSeleccionado?.tipo || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} />
                        </div>
                      </>
                    )}

                    {vistaActual === 'maestros_usuarios' && (
                      <>
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Usuario:</label>
                          <input name="id" defaultValue={itemMaestroSeleccionado?.id || itemMaestroSeleccionado?.codigo || ''} disabled={modoAccionMaestro === 'ver' || modoAccionMaestro === 'editar'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>

                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Función:</label>
                          <input name="nombre" defaultValue={itemMaestroSeleccionado?.nombre || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>

                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Iniciales</label>
                          <input name="iniciales" defaultValue={itemMaestroSeleccionado?.iniciales || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                        
                        <div>
                          <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Rol</label>
                          <input name="rol" defaultValue={itemMaestroSeleccionado?.rol || ''} disabled={modoAccionMaestro === 'ver'} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px' }} required />
                        </div>
                       
                      </>
                    )}
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '20px' }}>
                    <button 
                      type="button" 
                      onClick={() => setIsModalMaestroAbierto(false)}
                      style={{ padding: '8px 16px', background: '#e2e8f0', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 600, color: '#334155' }}
                    >
                      {modoAccionMaestro === 'ver' ? 'Cerrar' : 'Cancelar'}
                    </button>
                    
                    {modoAccionMaestro !== 'ver' && (
                      <button 
                        type="submit"
                        style={{ padding: '8px 16px', background: '#2563eb', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 600 }}
                      >
                        Guardar Cambios
                      </button>
                    )}
                  </div>
                </form>

              </div>
            </div>
          )}

          
        </section>
      )}
      
    </div>
  );
}
