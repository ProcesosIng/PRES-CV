import React, { useState, useMemo, useEffect } from 'react';
// Import: agrega PROCESOS_PRODUCTIVOS
import { maestroEmpleados, maestroCuentas, PROCESOS_PRODUCTIVOS, MESES } from '../../config/data';

export default function BaseRegistroForm({ registro, onGuardar, onCancelar, modo, config }) {
  const isSoloLectura = modo === 'ver';

  // ==========================================
  // 1. ESTADOS
  // ==========================================
  const ANIO_ACTUAL = new Date().getFullYear();
  const ANIOS_DISPONIBLES = [ANIO_ACTUAL - 1, ANIO_ACTUAL, ANIO_ACTUAL + 1, ANIO_ACTUAL + 2].map(String);
  const [anioActivo, setAnioActivo] = useState(ANIO_ACTUAL.toString())
  const [fechasSeleccionadas, setFechasSeleccionadas] = useState([]);

  const [valorBuscador, setValorBuscador] = useState('');
  const [datosAuto, setDatosAuto] = useState({});
  
  // Filas dinámicas de cuentas/ítems
  const [detalles, setDetalles] = useState([
    { id: Date.now(), cuenta: '', detalle: '', monto: '' }
  ]);

  // ==========================================
  // 2. CARGA INICIAL (MODO EDICIÓN)
  // ==========================================
  useEffect(() => {
    if (registro) {
      const emp = maestroEmpleados.find(e => (e.dni || e.id) === registro.empleado_dni);

      setDatosAuto({
        dni: registro.empleado_dni || '',
        dist: registro.detalle_columnas?.distribucion?.toString() || '100',
        area: registro.detalle_columnas?.area || '',
        proceso: registro.detalle_columnas?.proceso || '',
        cargo: emp ? (emp.cargo || 'Sin asignar') : 'Sin asignar'
      });

      setValorBuscador(`${registro.empleado_dni || ''} - ${registro.empleado_nombre || ''}`);
      
      // Recuperamos las variables si existen en el registro
      const cuentaUnitaria = registro.detalle_columnas?.cuenta_afectada || '';
      const detalleUnitario = registro.detalle_columnas?.detalle || '';
      const montoUnitario = registro.totales?.costo_total ?? '';

      setDetalles([
        {
          id: registro.id_registro,
          cuenta: cuentaUnitaria,
          detalle: detalleUnitario,
          monto: montoUnitario
        }
      ]);

      setFechasSeleccionadas([registro.fecha_proyeccion].filter(Boolean));
    } else {
      setDetalles([{ id: Date.now(), cuenta: '', detalle: '', monto: '' }]);
      setFechasSeleccionadas([]);
      setFechaInput('');
      setValorBuscador('');
      setDatosAuto({ dni: '', dist: '100', area: '', proceso: '', cargo: '' });
    }
  }, [registro]);

  // ==========================================
  // 3. FUNCIONES DE INTERFAZ
  // ==========================================
  const construirFecha = (anio, mesIndex) => `${anio}-${(mesIndex + 1).toString().padStart(2, '0')}-01`;
  const estaSeleccionado = (anio, mesIndex) => fechasSeleccionadas.includes(construirFecha(anio, mesIndex));

  const toggleMes = (anio, mesIndex) => {
    const fecha = construirFecha(anio, mesIndex);
    setFechasSeleccionadas(prev =>
      prev.includes(fecha) ? prev.filter(f => f !== fecha) : [...prev, fecha].sort()
    );
  };

  const seleccionarAnioCompleto = (anio) => {
    const fechasDelAnio = MESES.map((_, i) => construirFecha(anio, i));
    setFechasSeleccionadas(prev => Array.from(new Set([...prev, ...fechasDelAnio])).sort());
  };

  const limpiarAnio = (anio) => {
    setFechasSeleccionadas(prev => prev.filter(f => !f.startsWith(`${anio}-`)));
  };

  const formatearEtiqueta = (fechaStr) => {
    const [anio, mes] = fechaStr.split('-');
    const nombreMes = MESES[parseInt(mes, 10) - 1] || mes;
    return `${nombreMes} ${anio}`;
  };

  const handleAutocomplete = (e) => {
    const text = e.target.value;
    setValorBuscador(text);
    const idSeleccionado = text.split(' - ')[0];
    const emp = maestroEmpleados.find(emp => (emp.dni || emp.id) === idSeleccionado);
    
    if (emp) {
      // BUG CORREGIDO: antes se leía `registro.detalle_columnas` sin
      // verificar que `registro` existiera. Al crear un registro nuevo
      // (registro === null) esto lanzaba un TypeError apenas el usuario
      // escribía en el buscador de empleado. Ahora usamos `datosAuto`
      // (el estado actual del formulario) como fuente para area/proceso,
      // que sí existe tanto en modo "nuevo" como en modo "editar".
      setDatosAuto({
        dni: emp.dni || emp.id,
        dist: emp.distribucion?.toString().replace('%', '') || '100',
        area: emp.area || '',
        proceso: emp.proceso || '',
        cargo: emp.cargo || 'Sin asignar'
      });
    } else {
      setDatosAuto({ dni: '', dist: '100', 'auto-area': '', 'auto-proceso': '', cargo: '' });
    }
  };

  // Motor de cálculo proporcional
  const impactoContable = useMemo(() => {
    let totalLineas = 0;
    const cuentas = {};
    const porcentaje = parseFloat(datosAuto['auto-dist'] || datosAuto.dist) || 100;
    const factorDistribucion = porcentaje / 100;

    detalles.forEach(d => {
      const montoIngresado = parseFloat(d.monto) || 0;
      const montoProporcional = montoIngresado * factorDistribucion;

      if (montoProporcional > 0) {
        totalLineas += montoProporcional;
        if (d.cuenta) {
          cuentas[d.cuenta] = (cuentas[d.cuenta] || 0) + montoProporcional;
        }
      }
    });

    const dias = fechasSeleccionadas.length || 1;
    const totalProyectado = totalLineas * dias;
    return { totalProyectado, cuentas, dias, totalLineas };
  }, [detalles, fechasSeleccionadas, datosAuto]);

  // Guardado Aplanado (Doble bucle Fecha x Fila)
  const handleGuardar = () => {
    const fechasFinales = [...fechasSeleccionadas];
    
    // 2. Validaciones
    if (fechasFinales.length === 0) return alert('Por favor, ingrese al menos una fecha.');
    if (!valorBuscador) return alert('Por favor, seleccione un empleado.');
    if (!detalles || detalles.length === 0 || !detalles[0].cuenta) {
      return alert(config?.mensajeValidacionCuenta || 'Agregue al menos una cuenta contable.');
    }

    const idLoteActual = registro?.id_lote || `LOTE-${config?.prefijo || 'MOD'}-${Date.now()}`;
    const dniEmp = datosAuto.dni || valorBuscador.split(' - ')[0] || '-';
    const empInfo = maestroEmpleados.find(e => (e.dni || e.id) === dniEmp);
    const nombreEmpleado = empInfo ? empInfo.nombre : (valorBuscador.split(' - ')[1] || 'Desconocido');
    const distVal = parseFloat(datosAuto['auto-dist'] || datosAuto.dist) || 100;
    
    let nuevosRegistros = [];

    fechasFinales.forEach((fecha, fechaIndex) => {
      detalles.forEach((fila, filaIndex) => {
        if (!fila.cuenta || fila.monto === '') return;

        const montoItem = parseFloat(fila.monto) || 0;
        const idFinalRegistro = registro ? registro.id_registro : `${config?.prefijo || 'MOD'}-${Date.now()}-${fechaIndex}-${filaIndex}`;

        const nuevoItem = {
          id_registro: idFinalRegistro,
          id_lote: idLoteActual,
          fecha_proyeccion: fecha,
          fecha_registro: fecha,
          empleado_dni: dniEmp,
          empleado_nombre: nombreEmpleado,
          detalle_columnas: {
            cuenta_afectada: fila.cuenta,
            detalle: fila.detalle || '',
            distribucion: distVal,
            area: datosAuto.area || '',
            proceso: datosAuto.proceso || '',
            costo_total: montoItem,
            extras: fila.extras || {}
          },
          totales: { costo_total: montoItem },
          desglose_contable: [{ id: `cta-${fechaIndex}-${filaIndex}`, cuenta: fila.cuenta, monto: montoItem.toFixed(2) }],
          variables_registro: detalles
        };

        nuevosRegistros.push(nuevoItem);
      });
    });

    onGuardar(nuevosRegistros);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px' }}>
        
        {/* 0. FECHAS */}
        <div className="form-section">
          <div className="form-section-title">0. Fechas de Aplicación</div>

          <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
            {ANIOS_DISPONIBLES.map(anio => (
              <button key={anio} type="button" onClick={() => setAnioActivo(anio)}
                style={{
                  padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600,
                  border: anio === anioActivo ? '1px solid var(--primary-600, #2563eb)' : '1px solid var(--line, #cbd5e1)',
                  background: anio === anioActivo ? 'var(--primary-600, #2563eb)' : 'white',
                  color: anio === anioActivo ? 'white' : '#475569',
                }}>
                {anio}
              </button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px', marginBottom: '10px' }}>
            {MESES.map((mes, i) => {
              const activo = estaSeleccionado(anioActivo, i);
              return (
                <button key={mes} type="button" onClick={() => toggleMes(anioActivo, i)}
                  style={{
                    padding: '8px 4px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px', fontWeight: 600,
                    border: activo ? '1px solid #166534' : '1px solid var(--line, #cbd5e1)',
                    background: activo ? '#f0fdf4' : 'white',
                    color: activo ? '#166534' : '#475569',
                  }}>
                  {mes}
                </button>
              );
            })}
          </div>

          <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <button type="button" onClick={() => seleccionarAnioCompleto(anioActivo)} className="btn-ghost" style={{ background: 'white', fontSize: '12px', padding: '6px 10px' }}>
              + Seleccionar {anioActivo} completo
            </button>
            <button type="button" onClick={() => limpiarAnio(anioActivo)} className="btn-ghost" style={{ background: 'white', fontSize: '12px', padding: '6px 10px', color: '#ef4444' }}>
              Limpiar {anioActivo}
            </button>
          </div>

          {fechasSeleccionadas.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {fechasSeleccionadas.map(f => (
                <div key={f} style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', padding: '4px 10px', borderRadius: '99px', fontSize: '12px' }}>
                  {formatearEtiqueta(f)}
                  <span onClick={() => setFechasSeleccionadas(fechasSeleccionadas.filter(x => x !== f))} style={{ cursor: 'pointer', fontWeight: 'bold', marginLeft: '6px' }}>&times;</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 1. INFORMACIÓN GENERAL */}
        <div className="form-section">
          <div className="form-section-title">1. Información General</div>
          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label style={{ color: 'var(--primary-600, #2563eb)' }}>BUSCAR EMPLEADO (DNI O NOMBRE)</label>
            <input list="lista-emp-base" value={valorBuscador} onChange={handleAutocomplete} placeholder="Escriba para buscar..." autoComplete="off" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
            <datalist id="lista-emp-base">
              {maestroEmpleados.map((e, i) => <option key={i} value={`${e.dni || e.id} - ${e.nombre}`} />)}
            </datalist>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>

            <div className="form-group" style={{ margin: 0 }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DISTRIBUCIÓN (%)</label>
              <input type="number" value={datosAuto.dist || ''} onChange={(e) => setDatosAuto({ ...datosAuto, dist: e.target.value })} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }} />
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ÁREA</label>
              <input type="text" placeholder="Ej. Logística" value={datosAuto.area || ''} onChange={(e) => setDatosAuto({ ...datosAuto, area: e.target.value })} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }} />
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
              <select value={datosAuto.proceso || ''} onChange={(e) => setDatosAuto({ ...datosAuto, proceso: e.target.value })} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }}>
                <option value="">-- Seleccione --</option>
                {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            
          </div>
        </div>

        {/* 2. VARIABLES DE REGISTRO (LÍNEAS DINÁMICAS) */}
        <div className="form-section">

          <div className="form-section-title">{config?.tituloSeccion2 || '2. Variables de Registro'}</div>
          
          <datalist id="lista-cuentas-base">
            {maestroCuentas.map((cta, i) => <option key={`cta-${i}`} value={`${cta.id} - ${cta.nombre}`} />)}
          </datalist>

          {detalles.map((d, index) => (
            <div key={d.id} style={{ display: 'flex', gap: '8px', marginBottom: '8px', alignItems: 'center' }}>
              
              {/* Fila superior estándar (Cuenta y Subtotal general) */}
              <div className="form-group" style={{ flex: 1, margin: 0 }}>
                {index === 0 && <label>Nº CUENTA</label>}
                <input type="text" 
                    list="lista-cuentas-base" 
                    placeholder="Ej. 6311" 
                    value={d.cuenta || ''} 
                    onChange={e => setDetalles(detalles.map(x => x.id === d.id ? { ...x, cuenta: e.target.value } : x))} 
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ flex: 2, margin: 0 }}>
                {index === 0 && <label>{config?.labelDetalle || 'DETALLE'}</label>}
                <input type="text" 
                    placeholder="Concepto" 
                    value={d.detalle || ''} 
                    onChange={e => setDetalles(detalles.map(x => x.id === d.id ? { ...x, detalle: e.target.value } : x))} 
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ flex: 1, margin: 0 }}>
                {index === 0 && <label>SUBTOTAL</label>}
                <input type="number" 
                    step="0.01" 
                    placeholder="0.00" 
                    value={d.monto ?? ''} 
                    onChange={e => setDetalles(detalles.map(x => x.id === d.id ? { ...x, monto: e.target.value } : x))} 
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', textAlign: 'right' }} />
              </div>
              <div style={{ paddingTop: index === 0 ? '22px' : '0' }}>
                {detalles.length > 1 && (
                  <button type="button" onClick={() => setDetalles(detalles.filter(x => x.id !== d.id))} style={{ background: 'transparent', border: 'none', color: 'var(--danger, #ef4444)', fontSize: '20px', cursor: 'pointer' }}>&times;</button>
                )}
              </div>
            </div>
          ))}

          {/* RENDERIZADO DINÁMICO DE LOS CAMPOS EXTRAS CONFIGURADOS EN data.js */}
            {config?.variablesRegistro && config.variablesRegistro.length > 0 && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '8px', marginTop: '4px' }}>
                {config.variablesRegistro.map((campo) => (
                    <div className="form-group" key={campo.id} style={{ margin: 0 }}>
                    <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>{campo.label}</label>
                    <input 
                        type={campo.tipo || 'text'} 
                        placeholder={campo.label}
                        value={d.extras?.[campo.id] ?? campo.valorDefault ?? ''} 
                        onChange={e => {
                        const valor = e.target.value;
                        setDetalles(detalles.map(x => {
                            if (x.id === d.id) {
                            return {
                                ...x,
                                extras: { ...(x.extras || {}), [campo.id]: valor }
                            };
                            }
                            return x;
                        }));
                        }}
                        style={{ width: '100%', padding: '6px 8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }}
                    />
                    </div>
                ))}
                </div>
            )}

          <button type="button" onClick={() => setDetalles([...detalles, { id: Date.now(), cuenta: '', detalle: '', monto: '' }])} className="btn-ghost" style={{ width: '100%', marginTop: '8px', borderStyle: 'dashed', background: 'white' }}>
            + Agregar Línea
          </button>
        </div>

        {/* 3. IMPACTO CONTABLE UNIFICADO */}
        <div className="form-section" style={{ marginTop: 'auto' }}>
          <div className="form-section-title">3. Impacto Contable</div>
          {Object.keys(impactoContable.cuentas).length > 0 && (
            <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px', marginBottom: '12px' }}>
              {Object.entries(impactoContable.cuentas).map(([cuenta, total]) => (
                <div key={cuenta} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', borderBottom: '1px dashed #e2e8f0', paddingBottom: '6px', marginBottom: '6px' }}>
                  <span>{cuenta}</span>
                  <span style={{ fontWeight: 600 }}>S/ {total.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
              ))}
            </div>
          )}
          <div className="calc-total" style={{ marginTop: '16px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
              <div>
                <span>Total Proyectado</span>
                {impactoContable.dias > 1 && <div style={{ fontSize: '11px', color: '#15803d', fontWeight: 'normal' }}>({impactoContable.totalLineas.toFixed(2)} × {impactoContable.dias} fechas)</div>}
              </div>
              <span>S/ {impactoContable.totalProyectado.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

      </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
    </div>
  );
}