import React, { useState, useEffect, useMemo } from 'react';
import { maestroCuentas, MESES, PROCESOS_PRODUCTIVOS } from '../../config/data';

// Campos según el formato "PLAN MANTENIMIENTO": cuenta, descripción de
// activo, área, frecuencia, uso, año de presupuesto, costo de
// mantenimiento, tiempo de prorrateo de gasto, mes de ejecución de
// gasto, gasto de adquisición, mes de adquisición y detalle del
// mantenimiento. El monto prorrateado = costo de mantenimiento / tiempo
// de prorrateo (meses).
const FRECUENCIAS = ['Mensual', 'Trimestral', 'Semestral', 'Anual'];

export default function PlanMantenimientoForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';

  const [cuenta, setCuenta] = useState('');
  const [descripcionActivo, setDescripcionActivo] = useState('');
  const [area, setArea] = useState('');
  const [proceso, setProceso] = useState('');
  const [frecuencia, setFrecuencia] = useState('Mensual');
  const [uso, setUso] = useState('');
  const [anioPresupuesto, setAnioPresupuesto] = useState('2026');
  const [costoMantenimiento, setCostoMantenimiento] = useState('');
  const [tiempoProrrateo, setTiempoProrrateo] = useState('1');
  const [mesEjecucion, setMesEjecucion] = useState('Ene');
  const [gastoAdq, setGastoAdq] = useState('');
  const [mesAdquisicion, setMesAdquisicion] = useState('Ene');
  const [detalleMantenimiento, setDetalleMantenimiento] = useState('');

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setCuenta(dc.cuenta || '');
      setDescripcionActivo(dc.descripcion_activo || '');
      setArea(dc.area || '');
      setProceso(dc.proceso || '');
      setFrecuencia(dc.frecuencia || 'Mensual');
      setUso(dc.uso || '');
      setAnioPresupuesto(dc.anio_presupuesto?.toString() || '2026');
      setCostoMantenimiento(dc.costo_mantenimiento?.toString() || '');
      setTiempoProrrateo(dc.tiempo_prorrateo_gasto?.toString() || '1');
      setMesEjecucion(dc.mes_ejecucion_gasto || 'Ene');
      setGastoAdq(dc.gasto_adq?.toString() || '');
      setMesAdquisicion(dc.mes_adquisicion || 'Ene');
      setDetalleMantenimiento(dc.detalle_mantenimiento || '');
    }
  }, [registro]);

  const montoProrrateado = useMemo(() => {
    const costo = parseFloat(costoMantenimiento) || 0;
    const tiempo = parseFloat(tiempoProrrateo) || 1;
    return costo / tiempo;
  }, [costoMantenimiento, tiempoProrrateo]);

  const handleGuardar = () => {
    if (!cuenta) return alert('Por favor, ingrese la cuenta contable.');
    if (!descripcionActivo) return alert('Por favor, describa el activo.');

    const idRegistro = registro ? registro.id_registro : `MNT-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistro) : `LOTE-MNT-${Date.now()}`;
    const cuentaInfo = maestroCuentas.find(c => c.id === cuenta);

    const nuevoRegistro = {
      id_registro: idRegistro,
      id_lote: idLote,
      fecha_proyeccion: `${anioPresupuesto}-${(MESES.indexOf(mesEjecucion) + 1).toString().padStart(2, '0')}-01`,
      empleado_dni: '-',
      empleado_nombre: descripcionActivo,
      detalle_columnas: {
        cuenta, area, proceso,
        descripcion_activo: descripcionActivo,
        frecuencia, uso,
        anio_presupuesto: parseFloat(anioPresupuesto) || 2026,
        costo_mantenimiento: parseFloat(costoMantenimiento) || 0,
        tiempo_prorrateo_gasto: parseFloat(tiempoProrrateo) || 1,
        mes_ejecucion_gasto: mesEjecucion,
        gasto_adq: parseFloat(gastoAdq) || 0,
        mes_adquisicion: mesAdquisicion,
        detalle_mantenimiento: detalleMantenimiento,
        costo_total: montoProrrateado,
      },
      totales: { costo_total: montoProrrateado },
      desglose_contable: [{
        id: 'cta-1',
        cuenta: `${cuenta}${cuentaInfo ? ' - ' + cuentaInfo.nombre : ' - Mantenimiento'}`,
        monto: montoProrrateado.toFixed(2)
      }],
    };

    onGuardar([nuevoRegistro]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Activo y Cuenta</div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label style={{ color: 'var(--primary-600, #2563eb)' }}>CUENTA</label>
              <input list="lista-cuentas-mnt" value={cuenta} onChange={e => setCuenta(e.target.value)}
                placeholder="Ej. 946261000" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              <datalist id="lista-cuentas-mnt">
                {maestroCuentas.map((c, i) => <option key={i} value={c.id}>{c.nombre}</option>)}
              </datalist>
            </div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label>DESCRIPCIÓN DE ACTIVO</label>
              <input type="text" value={descripcionActivo} onChange={e => setDescripcionActivo(e.target.value)}
                placeholder="Ej. Horno de calcinación N°1" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ÁREA</label>
                <input type="text" value={area} onChange={e => setArea(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
                <select value={proceso} onChange={e => setProceso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>USO</label>
                <input type="text" value={uso} onChange={e => setUso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">2. Programación y Costos</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>FRECUENCIA</label>
                <select value={frecuencia} onChange={e => setFrecuencia(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {FRECUENCIAS.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>AÑO DE PRESUPUESTO</label>
                <input type="number" value={anioPresupuesto} onChange={e => setAnioPresupuesto(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>COSTO MANTENIMIENTO (S/)</label>
                <input type="number" step="0.01" value={costoMantenimiento} onChange={e => setCostoMantenimiento(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>TIEMPO PRORRATEO (MESES)</label>
                <input type="number" value={tiempoProrrateo} onChange={e => setTiempoProrrateo(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES EJECUCIÓN GASTO</label>
                <select value={mesEjecucion} onChange={e => setMesEjecucion(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>GASTO ADQUISICIÓN (S/)</label>
                <input type="number" step="0.01" value={gastoAdq} onChange={e => setGastoAdq(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES DE ADQUISICIÓN</label>
                <select value={mesAdquisicion} onChange={e => setMesAdquisicion(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0, gridColumn: 'span 2' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DETALLE DEL MANTENIMIENTO</label>
                <input type="text" value={detalleMantenimiento} onChange={e => setDetalleMantenimiento(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            <div className="form-section-title">3. Impacto Contable</div>
            <div className="calc-total" style={{ marginTop: '8px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <div>
                  <span>Monto Prorrateado / Mes</span>
                  <div style={{ fontSize: '11px', color: '#15803d', fontWeight: 'normal' }}>
                    (S/ {(parseFloat(costoMantenimiento) || 0).toFixed(2)} ÷ {tiempoProrrateo || 1} meses)
                  </div>
                </div>
                <span>S/ {montoProrrateado.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
    </div>
  );
}
