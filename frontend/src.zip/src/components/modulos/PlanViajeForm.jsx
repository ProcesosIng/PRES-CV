import React, { useState, useEffect, useMemo } from 'react';
import { maestroEmpleados, MESES } from '../../config/data';

// Campos según el formato "PLAN DE VIAJE" del Excel de origen: viaje,
// asignado a, inicio, duración (días), planeado/ejecutado, y los rubros
// de gasto (alimentación, movilidad, otros movilidad, alojamiento,
// combustible, peajes, otros adicionales int/ext), más monto unitario,
// cantidad de personas, unidad de medida, precio unitario y cantidad
// total. El "impacto contable" se arma sumando todos los rubros.
export default function PlanViajeForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';

  const [viaje, setViaje] = useState('');
  const [valorBuscador, setValorBuscador] = useState('');
  const [datosAuto, setDatosAuto] = useState({ dni: '', area: '', proceso: '' });
  const [mesInicio, setMesInicio] = useState('Ene');
  const [duracionDias, setDuracionDias] = useState('');
  const [estado, setEstado] = useState('Planeado');
  const [cantPersonas, setCantPersonas] = useState('1');
  const [unidMed, setUnidMed] = useState('Viaje');

  const [rubros, setRubros] = useState({
    alimentacion: '0', movilidad: '0', otros_movilidad: '0', alojamiento: '0',
    combustible: '0', peajes: '0', otros_adicionales_int: '0', otros_adicionales_ext: '0'
  });

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setViaje(dc.viaje || '');
      setValorBuscador(`${registro.empleado_dni || ''} - ${registro.empleado_nombre || ''}`);
      setDatosAuto({ dni: registro.empleado_dni || '', area: dc.area || '', proceso: dc.proceso || '' });
      setMesInicio(dc.mes_inicio || 'Ene');
      setDuracionDias(dc.duracion_dias?.toString() || '');
      setEstado(dc.estado || 'Planeado');
      setCantPersonas(dc.cant_personas?.toString() || '1');
      setUnidMed(dc.unid_med || 'Viaje');
      setRubros(dc.rubros || rubros);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registro]);

  const handleAutocomplete = (e) => {
    const text = e.target.value;
    setValorBuscador(text);
    const idSeleccionado = text.split(' - ')[0];
    const emp = maestroEmpleados.find(emp => (emp.dni || emp.id) === idSeleccionado);
    if (emp) setDatosAuto(prev => ({ ...prev, dni: emp.dni || emp.id }));
  };

  // Motor de cálculo: monto unitario = suma de rubros, cantidad total =
  // monto unitario x cantidad de personas.
  const calculo = useMemo(() => {
    const montoUnit = Object.values(rubros).reduce((s, v) => s + (parseFloat(v) || 0), 0);
    const personas = parseFloat(cantPersonas) || 1;
    const cantidadTotal = montoUnit * personas;
    return { montoUnit, cantidadTotal };
  }, [rubros, cantPersonas]);

  const handleGuardar = () => {
    if (!viaje) return alert('Por favor, ingrese el nombre/motivo del viaje.');
    if (!valorBuscador) return alert('Por favor, seleccione a quién se asigna el viaje.');

    const nombre = valorBuscador.split(' - ')[1] || valorBuscador;
    const idRegistro = registro ? registro.id_registro : `VIA-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistro) : `LOTE-VIA-${Date.now()}`;

    const cuentas = Object.entries(rubros)
      .filter(([, v]) => (parseFloat(v) || 0) > 0)
      .map(([k, v]) => ({ id: `cta-${k}`, cuenta: `946261000 - Viaje (${k.replaceAll('_', ' ')})`, monto: (parseFloat(v) || 0).toFixed(2) }));

    const nuevoRegistro = {
      id_registro: idRegistro,
      id_lote: idLote,
      fecha_proyeccion: `2026-${(MESES.indexOf(mesInicio) + 1).toString().padStart(2, '0')}-01`,
      empleado_dni: datosAuto.dni || '-',
      empleado_nombre: nombre,
      detalle_columnas: {
        viaje,
        area: datosAuto.area,
        proceso: datosAuto.proceso,
        mes_inicio: mesInicio,
        duracion_dias: parseFloat(duracionDias) || 0,
        estado,
        cant_personas: parseFloat(cantPersonas) || 1,
        unid_med: unidMed,
        rubros,
        monto_unit: calculo.montoUnit,
        costo_total: calculo.cantidadTotal,
      },
      totales: { costo_total: calculo.cantidadTotal },
      desglose_contable: cuentas,
      variables_registro: { rubros },
    };

    onGuardar([nuevoRegistro]);
  };

  const campoRubro = (id, label) => (
    <div className="form-group" style={{ margin: 0 }}>
      <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>{label}</label>
      <input type="number" step="0.01" value={rubros[id]}
        onChange={e => setRubros({ ...rubros, [id]: e.target.value })}
        style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Datos del Viaje</div>
            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label>VIAJE (MOTIVO)</label>
              <input type="text" value={viaje} onChange={e => setViaje(e.target.value)} placeholder="Ej. Visita técnica cliente Ares"
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
            </div>
            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label style={{ color: 'var(--primary-600, #2563eb)' }}>ASIGNADO A</label>
              <input list="lista-emp-viaje" value={valorBuscador} onChange={handleAutocomplete}
                placeholder="Escriba para buscar..." autoComplete="off"
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              <datalist id="lista-emp-viaje">
                {maestroEmpleados.map((e, i) => <option key={i} value={`${e.dni || e.id} - ${e.nombre}`} />)}
              </datalist>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', marginBottom: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>INICIO (MES)</label>
                <select value={mesInicio} onChange={e => setMesInicio(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DURACIÓN (DÍAS)</label>
                <input type="number" value={duracionDias} onChange={e => setDuracionDias(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PLANEADO / EJECUTADO</label>
                <select value={estado} onChange={e => setEstado(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="Planeado">Planeado</option>
                  <option value="Ejecutado">Ejecutado</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ÁREA</label>
                <input type="text" value={datosAuto.area} onChange={e => setDatosAuto({ ...datosAuto, area: e.target.value })}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
                <select value={datosAuto.proceso} onChange={e => setDatosAuto({ ...datosAuto, proceso: e.target.value })}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CANT. PERSONAS</label>
                <input type="number" min="1" value={cantPersonas} onChange={e => setCantPersonas(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">2. Rubros de Gasto (por persona)</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
              {campoRubro('alimentacion', 'ALIMENTACIÓN (S/)')}
              {campoRubro('movilidad', 'MOVILIDAD (S/)')}
              {campoRubro('otros_movilidad', 'OTROS MOVILIDAD (S/)')}
              {campoRubro('alojamiento', 'ALOJAMIENTO (S/)')}
              {campoRubro('combustible', 'COMBUSTIBLE (S/)')}
              {campoRubro('peajes', 'PEAJES (S/)')}
              {campoRubro('otros_adicionales_int', 'OTROS ADICIONALES INT. (S/)')}
              {campoRubro('otros_adicionales_ext', 'OTROS ADICIONALES EXT. (S/)')}
            </div>
            <div className="form-group" style={{ marginTop: '8px' }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>UNIDAD DE MEDIDA</label>
              <input type="text" value={unidMed} onChange={e => setUnidMed(e.target.value)} placeholder="Viaje, Día, etc."
                style={{ width: '220px', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
            </div>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            <div className="form-section-title">3. Impacto Contable</div>
            <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', paddingBottom: '6px' }}>
                <span>Monto unitario (por persona)</span>
                <span style={{ fontWeight: 600 }}>S/ {calculo.montoUnit.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
            <div className="calc-total" style={{ marginTop: '16px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <span>Cantidad Total (S/)</span>
                <span>S/ {calculo.cantidadTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
    </div>
  );
}
