import React, { useState, useEffect, useMemo } from 'react';
import { maestroForecastComercial, MESES, PRESENTACIONES_FUNDENTE, PROCESOS_FUNDENTE } from '../../config/data';
import { obtenerTotalesPorProceso, guardarCosteoDerivado, listarForecastComercial } from '../../data/store';

// Mismo mecanismo que CosteoCrisolesForm, pero Fundente solo tiene 2
// líneas de proceso (Granel / Sachet) en vez de 3, y el forecast se
// filtra por unidad_negocio = 'Fundente'.
export default function CosteoFundenteForm({ registro, onGuardar, onCancelar, modo, idVersion, area }) {
  const isSoloLectura = modo === 'ver';

  const forecastFundente = useMemo(() => {
    const real = listarForecastComercial(idVersion).filter(f => f.unidad_negocio === 'Fundente');
    if (real.length > 0) return real;
    return maestroForecastComercial.filter(f => f.unidad_negocio === 'Fundente');
  }, [idVersion]);
  const usandoSemilla = useMemo(
    () => listarForecastComercial(idVersion).filter(f => f.unidad_negocio === 'Fundente').length === 0,
    [idVersion]
  );

  const [mes, setMes] = useState('Ene');
  const [productoSel, setProductoSel] = useState('');
  const [presentacion, setPresentacion] = useState(PRESENTACIONES_FUNDENTE[0]);
  const [cantidadProyectada, setCantidadProyectada] = useState('0');
  const [precioVentaUnit, setPrecioVentaUnit] = useState('0');
  const [costoPromedioUnit, setCostoPromedioUnit] = useState('0');

  const [materiaPrimaUnit, setMateriaPrimaUnit] = useState('0');
  const [maSuministrosUnit, setMaSuministrosUnit] = useState('0');
  const [envasesUnit, setEnvasesUnit] = useState('0');

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setMes(dc.mes || 'Ene');
      setProductoSel(dc.producto || '');
      setPresentacion(dc.presentacion || PRESENTACIONES_FUNDENTE[0]);
      setCantidadProyectada(dc.cantidad_proyectada?.toString() || '0');
      setPrecioVentaUnit(dc.precio_venta_unit?.toString() || '0');
      setCostoPromedioUnit(dc.costo_promedio_unit?.toString() || '0');
      setMateriaPrimaUnit(dc.materia_prima_unit?.toString() || '0');
      setMaSuministrosUnit(dc.ma_suministros_unit?.toString() || '0');
      setEnvasesUnit(dc.envases_unit?.toString() || '0');
    }
  }, [registro]);

  const handleProducto = (nombreProducto) => {
    setProductoSel(nombreProducto);
    const item = forecastFundente.find(p => p.producto === nombreProducto);
    if (item) {
      setPrecioVentaUnit(item.precio_venta.toString());
      setCostoPromedioUnit(item.costo_unitario.toString());
      setCantidadProyectada((item.cantidades?.[mes] ?? 0).toString());
      // Autodetecta la presentación según el nombre del producto del forecast.
      if (item.producto.toUpperCase().includes('SACHET')) setPresentacion('Sachet');
      else if (item.producto.toUpperCase().includes('GRANEL')) setPresentacion('Granel');
    }
  };

  useEffect(() => {
    if (!productoSel) return;
    const item = forecastFundente.find(p => p.producto === productoSel);
    if (item) setCantidadProyectada((item.cantidades?.[mes] ?? 0).toString());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mes]);

  const totalesProceso = useMemo(() => {
    if (!idVersion || !area) return { Granel: 0, Sachet: 0 };
    return obtenerTotalesPorProceso({ idVersion, area, procesos: PROCESOS_FUNDENTE, mes });
  }, [idVersion, area, mes]);

  const cantidad = parseFloat(cantidadProyectada) || 0;
  const costoUnitLinea = cantidad > 0 ? (totalesProceso[presentacion] || 0) / cantidad : 0;

  const costoUnitarioTotal =
    (parseFloat(materiaPrimaUnit) || 0) +
    (parseFloat(maSuministrosUnit) || 0) +
    (parseFloat(envasesUnit) || 0) +
    costoUnitLinea;

  const costoTotalMes = costoUnitarioTotal * cantidad;
  const margenUnit = (parseFloat(precioVentaUnit) || 0) - costoUnitarioTotal;

  const handleGuardar = () => {
    if (!productoSel) return alert('Por favor, seleccione un producto del forecast de Comercial.');
    if (cantidad <= 0) return alert('La cantidad proyectada debe ser mayor a 0 para ese mes.');

    const idRegistro = registro ? registro.id_registro : `FUN-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistro) : `LOTE-FUN-${Date.now()}`;

    const nuevoRegistro = {
      id_registro: idRegistro,
      id_lote: idLote,
      modulo: 'Costeo de Fundente',
      fecha_proyeccion: `2026-${(MESES.indexOf(mes) + 1).toString().padStart(2, '0')}-01`,
      empleado_dni: '-',
      empleado_nombre: productoSel,
      detalle_columnas: {
        mes, producto: productoSel, presentacion,
        cantidad_proyectada: cantidad,
        precio_venta_unit: parseFloat(precioVentaUnit) || 0,
        costo_promedio_unit: parseFloat(costoPromedioUnit) || 0,
        materia_prima_unit: parseFloat(materiaPrimaUnit) || 0,
        ma_suministros_unit: parseFloat(maSuministrosUnit) || 0,
        envases_unit: parseFloat(envasesUnit) || 0,
        costo_unit_linea: costoUnitLinea,
        proceso: 'Costeo',
        costo_unitario_total: costoUnitarioTotal,
        costo_total: costoTotalMes,
      },
      totales: { costo_total: costoTotalMes, costo_unitario: costoUnitarioTotal, margen_unit: margenUnit },
      desglose_contable: [
        { id: 'c1', cuenta: '946252000 - Materia Prima', monto: ((parseFloat(materiaPrimaUnit) || 0) * cantidad).toFixed(2) },
        { id: 'c2', cuenta: '946252000 - MA y Suministros', monto: ((parseFloat(maSuministrosUnit) || 0) * cantidad).toFixed(2) },
        { id: 'c3', cuenta: '946252000 - Envases y Embalajes', monto: ((parseFloat(envasesUnit) || 0) * cantidad).toFixed(2) },
        { id: 'c4', cuenta: `946261000 - ${presentacion} (prorrateado)`, monto: (totalesProceso[presentacion] || 0).toFixed(2) },
      ],
    };

    guardarCosteoDerivado(nuevoRegistro, {
      materiasPrimas: (parseFloat(materiaPrimaUnit) || 0) * cantidad,
      maSuministros: (parseFloat(maSuministrosUnit) || 0) * cantidad,
      envasesEmbalajes: (parseFloat(envasesUnit) || 0) * cantidad,
    }, { idVersion, area });

    onGuardar([nuevoRegistro]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Producto (Forecast de Comercial)</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '12px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES</label>
                <select value={mes} onChange={e => setMes(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRESENTACIÓN</label>
                <select value={presentacion} onChange={e => setPresentacion(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {PRESENTACIONES_FUNDENTE.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label style={{ color: 'var(--primary-600, #2563eb)' }}>PRODUCTO (UNIDAD DE NEGOCIO: FUNDENTE)</label>
              <select value={productoSel} onChange={e => handleProducto(e.target.value)}
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                <option value="">-- Seleccione producto del forecast --</option>
                {forecastFundente.map(p => <option key={p.producto} value={p.producto}>{p.producto}</option>)}
              </select>
            </div>
            {usandoSemilla && (
              <div style={{ fontSize: '11px', color: '#b45309', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '4px', padding: '6px 8px', marginBottom: '8px' }}>
                Comercial aún no ha cargado el forecast de esta versión en "Forecast de Ventas" — mostrando datos de ejemplo.
              </div>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CANT. PROYECTADA (MES)</label>
                <input type="number" value={cantidadProyectada} onChange={e => setCantidadProyectada(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: '#f8fafc' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PV UNITARIO (S/)</label>
                <input type="number" value={precioVentaUnit} onChange={e => setPrecioVentaUnit(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: '#f8fafc' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>COSTO PROMEDIO COMERCIAL (S/)</label>
                <input type="number" value={costoPromedioUnit} onChange={e => setCostoPromedioUnit(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: '#f8fafc' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">2. Costo Unitario — Materiales</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MATERIA PRIMA (S/ / unid.)</label>
                <input type="number" step="0.0001" value={materiaPrimaUnit} onChange={e => setMateriaPrimaUnit(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MA Y SUMINISTROS (S/ / unid.)</label>
                <input type="number" step="0.0001" value={maSuministrosUnit} onChange={e => setMaSuministrosUnit(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ENVASES Y EMBALAJES (S/ / unid.)</label>
                <input type="number" step="0.0001" value={envasesUnit} onChange={e => setEnvasesUnit(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
            <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '6px' }}>
              Al guardar, cada uno de estos 3 costos genera automáticamente su línea correspondiente en los módulos "Materias Primas", "Materiales Auxiliares y Suministros" y "Envases y Embalajes".
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">3. Costo por Línea (jalado de módulos de {area || 'esta área'})</div>
            <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px' }}>
              {PROCESOS_FUNDENTE.map(p => (
                <div key={p} style={{
                  display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: p === presentacion ? '#0f172a' : '#94a3b8',
                  fontWeight: p === presentacion ? 600 : 400, borderBottom: '1px dashed #e2e8f0', padding: '6px 0'
                }}>
                  <span>{p} — Total registrado en {mes} {p === presentacion ? '(línea activa)' : ''}</span>
                  <span>S/ {(totalesProceso[p] || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
              ))}
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '8px' }}>
                Costo unitario de línea = total de "{presentacion}" ÷ cantidad proyectada ({cantidad || 0} unid.)
              </div>
            </div>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            <div className="form-section-title">4. Costo Unitario Total</div>
            <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', padding: '4px 0' }}><span>Materia Prima</span><span>S/ {(parseFloat(materiaPrimaUnit) || 0).toFixed(4)}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', padding: '4px 0' }}><span>MA y Suministros</span><span>S/ {(parseFloat(maSuministrosUnit) || 0).toFixed(4)}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', padding: '4px 0' }}><span>Envases y Embalajes</span><span>S/ {(parseFloat(envasesUnit) || 0).toFixed(4)}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#475569', padding: '4px 0' }}><span>{presentacion}</span><span>S/ {costoUnitLinea.toFixed(4)}</span></div>
            </div>
            <div className="calc-total" style={{ marginTop: '12px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <span>Costo Unitario Total</span>
                <span>S/ {costoUnitarioTotal.toLocaleString('en-US', { minimumFractionDigits: 4 })}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#15803d', marginTop: '6px' }}>
                <span>Margen unitario vs. PV</span>
                <span>S/ {margenUnit.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px', marginTop: '10px', borderTop: '1px dashed #bbf7d0', paddingTop: '10px' }}>
                <span>Costo Total del Mes</span>
                <span>S/ {costoTotalMes.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Costeo
          </button>
        )}
      </div>
    </div>
  );
}
