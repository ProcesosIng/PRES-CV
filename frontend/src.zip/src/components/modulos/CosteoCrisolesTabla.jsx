import React from 'react';

export default function CosteoCrisolesFila({ reg, onVer, onEditar, onBorrar }) {
  const dc = reg.detalle_columnas || {};
  
  return (
    <tr key={reg.id_registro}>
      <td style={{ color: '#64748b', fontWeight: 600 }}>Anual</td>
      <td style={{ fontWeight: 500 }}>{dc.producto || '-'}</td>
      <td style={{ textAlign: 'center' }}>{dc.tamano || '-'}</td>
      <td style={{ textAlign: 'right' }}>{(dc.cantidad_total_anio || 0).toLocaleString('en-US')}</td>
      <td style={{ textAlign: 'right' }} className="font-mono">
        S/ {(dc.precio_venta_unit || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'right' }} className="font-mono">
        S/ {(dc.costo_unitario_promedio || 0).toLocaleString('en-US', { minimumFractionDigits: 4 })}
      </td>
      <td style={{ textAlign: 'right', fontWeight: 600, color: '#166534' }} className="font-mono">
        S/ {(dc.costo_total_anual || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'center' }}>
        <button onClick={() => onVer(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Ver">👁️</button>
        <button onClick={() => onEditar(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Editar">✏️</button>
        <button onClick={() => onBorrar(reg.id_registro)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }} title="Eliminar">🗑️</button>
      </td>
    </tr>
  );
}