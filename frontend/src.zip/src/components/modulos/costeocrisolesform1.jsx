import React, { useState, useEffect, useMemo } from 'react';
import { maestroForecastComercial, MESES } from '../../config/data';
import { listarForecastComercial, listarRegistros } from '../../data/store';

const ANIO_ACTUAL = new Date().getFullYear();
const ANIOS_DISPONIBLES = Array.from({ length: 5 }, (_, i) => (ANIO_ACTUAL - 1 + i).toString());

export default function CosteoCrisolesForm({ registro, onGuardar, onCancelar, modo, idVersion, area }) {
  const isSoloLectura = modo === 'ver';

  // 1. Obtener forecast
  const forecastCrisoles = useMemo(() => {
    const real = listarForecastComercial(idVersion);
    return real.length > 0 ? real : maestroForecastComercial;
  }, [idVersion]);

  // 2. Estados Generales
  const [anioSel, setAnioSel] = useState(ANIO_ACTUAL.toString());
  const [productoSel, setProductoSel] = useState('');
  const [itemForecast, setItemForecast] = useState(null);
  const [margenProduccion, setMargenProduccion] = useState('0');
  const [cantidadesMeses, setCantidadesMeses] = useState(MESES.reduce((acc, m) => ({ ...acc, [m]: '0' }), {}));

  // 3. Estados de Listas (Materiales y Suministros)
  const [materiales, setMateriales] = useState([{ id: 'm1', insumo: '', udm: 'kg', tipoCalculo: 'ratio', valor: '0', porcentajeUso: '100', costoUnitario: '0', usarParticipacion: false }]);
  const [suministros, setSuministros] = useState([{ id: 's1', insumo: '', udm: 'kg', tipoCalculo: 'ratio', valor: '0', porcentajeUso: '100', costoUnitario: '0', usarParticipacion: false }]);

  // 4. Estados: Asignación dinámica de Módulos (MOD, Depreciación, etc.) por Proceso
  const [modulosP1, setModulosP1] = useState([]);
  const [modulosP2, setModulosP2] = useState([]);
  const [modulosCIF, setModulosCIF] = useState([]);

  // Estado para guardar los productos seleccionados para la suma total (Base de Distribución)
  const [productosBase, setProductosBase] = useState([]);

  function _crearItemVacio(id, tipo = 'insumo') {
    if (tipo === 'modulo') {
      return { id, moduloNombre: '', porcentajesMes: MESES.reduce((acc, m) => ({ ...acc, [m]: '100' }), {}), usarParticipacion: false };
    }
    return { id, insumo: '', udm: 'kg', tipoCalculo: 'ratio', valor: '0', porcentajeUso: '100', costoUnitario: '0', usarParticipacion: false };
  }

  const adaptarModulosLegacy = (lista) => (lista || []).map(item => ({
    ...item,
    porcentajesMes: item.porcentajesMes || MESES.reduce((acc, m) => ({ ...acc, [m]: item.porcentaje ?? '100' }), {}),
    usarParticipacion: item.usarParticipacion || false
  }));

  // 5. Carga de datos iniciales
  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setProductoSel(dc.producto || '');
      setAnioSel(dc.anio_proyeccion?.toString() || ANIO_ACTUAL.toString());
      setMargenProduccion(dc.margen_produccion?.toString() || '0');
      
      if (dc.productos_base) setProductosBase(dc.productos_base);

      if (dc.cantidades_comercial || dc.cantidades) {
        const baseCantidades = dc.cantidades_comercial || dc.cantidades;
        const cants = {};
        MESES.forEach(m => cants[m] = (baseCantidades[m] ?? 0).toString());
        setCantidadesMeses(cants);
      }

      const adaptarLegacy = (lista) => lista.map(item => ({
        ...item,
        tipoCalculo: item.tipoCalculo || (item.ratio ? 'ratio' : 'porcentaje'),
        valor: item.valor || item.ratio || item.porcentaje || '0',
        porcentajeUso: item.porcentajeUso || '100',
        usarParticipacion: item.usarParticipacion || false
      }));

      if (dc.materiales && Array.isArray(dc.materiales)) setMateriales(adaptarLegacy(dc.materiales));
      if (dc.suministros && Array.isArray(dc.suministros)) setSuministros(adaptarLegacy(dc.suministros));

      if (dc.modulosP1) setModulosP1(adaptarModulosLegacy(dc.modulosP1));
      if (dc.modulosP2) setModulosP2(adaptarModulosLegacy(dc.modulosP2));
      if (dc.modulosCIF) setModulosCIF(adaptarModulosLegacy(dc.modulosCIF));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registro]);

  // 1. AGRUPADOR DE PRODUCTOS
  const productosAgrupados = useMemo(() => {
    const mapa = new Map();
    forecastCrisoles.forEach(reg => {
      const dc = reg.detalle_columnas || reg;
      if (dc.producto && !mapa.has(dc.producto)) {
        mapa.set(dc.producto, { producto: dc.producto });
      }
    });
    return Array.from(mapa.values());
  }, [forecastCrisoles]);

  // =================================================================
  // FUNCIÓN CENTRALIZADA PARA CALCULAR CANTIDADES
  // =================================================================
  const actualizarCantidades = (nombreProd, anioStr) => {
    if (!nombreProd) {
      setItemForecast(null);
      setCantidadesMeses(MESES.reduce((acc, m) => ({ ...acc, [m]: '0' }), {}));
      return;
    }

    const anioTarget = String(anioStr || new Date().getFullYear()).trim();
    const prodTarget = String(nombreProd).trim().toLowerCase();

    const registrosDelProducto = forecastCrisoles.filter(r => {
      const dc = r.detalle_columnas || r;
      const rawDate = String(dc.anio_proyeccion || r.fecha_proyeccion || r.fecha || new Date().getFullYear());
      const matchYear = rawDate.match(/\b(20\d{2})\b/);
      const anioReg = matchYear ? matchYear[1] : new Date().getFullYear().toString();
      const prodReg = String(dc.producto || '').trim().toLowerCase();
      
      return prodReg === prodTarget && anioReg === anioTarget;
    });

    if (registrosDelProducto.length > 0) {
      const sumas = MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
      let precioRef = 0;
      
      registrosDelProducto.forEach(reg => {
        const dc = reg.detalle_columnas || reg;
        precioRef = parseFloat(dc.precio_venta_unit || dc.precio_venta) || precioRef;
        
        let cants = dc.cantidades;
        if (typeof cants === 'string') {
          try { cants = JSON.parse(cants); } catch(e) {}
        }
        if (cants && typeof cants === 'object') {
          MESES.forEach(m => sumas[m] += (parseFloat(cants[m]) || 0));
        }
      });
      
      const nuevasCants = {};
      MESES.forEach(m => nuevasCants[m] = sumas[m].toString());
      setItemForecast({ producto: nombreProd, precio_venta: precioRef });
      setCantidadesMeses(nuevasCants);
    } else {
      setItemForecast(null);
      setCantidadesMeses(MESES.reduce((acc, m) => ({ ...acc, [m]: '0' }), {}));
    }
  };

  const handleSeleccionarProducto = (nombreProd) => {
    setProductoSel(nombreProd);
    actualizarCantidades(nombreProd, anioSel);
  };

  useEffect(() => {
    if (productoSel) {
      actualizarCantidades(productoSel, anioSel);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [anioSel]);

  // =================================================================
  // CÁLCULOS DE CANTIDADES (COMERCIAL VS PRODUCCIÓN)
  // =================================================================
  const cantidadTotalAnio = useMemo(() => MESES.reduce((acc, m) => acc + (parseFloat(cantidadesMeses[m]) || 0), 0), [cantidadesMeses]);

  const cantidadesProduccion = useMemo(() => {
    const margen = parseFloat(margenProduccion) || 0;
    return MESES.reduce((acc, m) => {
      const cantComercial = parseFloat(cantidadesMeses[m]) || 0;
      acc[m] = Math.ceil(cantComercial * (1 + (margen / 100)));
      return acc;
    }, {});
  }, [cantidadesMeses, margenProduccion]);

  const cantidadTotalProduccionAnio = useMemo(() => MESES.reduce((acc, m) => acc + cantidadesProduccion[m], 0), [cantidadesProduccion]);

  // =================================================================
  // CÁLCULO DE PARTICIPACIÓN (% DEL PRODUCTO SOBRE EL TOTAL)
  // =================================================================
  const calculoBase = useMemo(() => {
    const totalesBase = MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
    
    productosBase.forEach(prodNombre => {
      const registrosProd = forecastCrisoles.filter(r => {
        const dc = r.detalle_columnas || r;
        const rawDate = String(dc.anio_proyeccion || r.fecha_proyeccion || r.fecha || new Date().getFullYear());
        const matchYear = rawDate.match(/\b(20\d{2})\b/);
        const anioReg = matchYear ? matchYear[1] : new Date().getFullYear().toString();
        return dc.producto === prodNombre && anioReg === anioSel;
      });
      
      registrosProd.forEach(reg => {
         const dc = reg.detalle_columnas || reg;
         let cants = dc.cantidades;
         if (typeof cants === 'string') { try { cants = JSON.parse(cants); } catch(e) {} }
         
         if (cants && typeof cants === 'object') {
           MESES.forEach(m => { totalesBase[m] += (parseFloat(cants[m]) || 0); });
         }
      });
    });

    const porcentajes = MESES.reduce((acc, m) => {
      const cantActual = parseFloat(cantidadesMeses[m]) || 0;
      const baseMes = totalesBase[m];
      acc[m] = baseMes > 0 ? ((cantActual / baseMes) * 100).toFixed(2) : '0.00';
      return acc;
    }, {});

    return { totalesBase, porcentajes };
  }, [productosBase, forecastCrisoles, anioSel, cantidadesMeses]);

  // =================================================================
  // MOTOR DE ESCANEO DE MÓDULOS DE ÁREA
  // =================================================================
  const agrupadosBD = useMemo(() => {
    const estructura = { 'Primer Proceso': {}, 'Segundo Proceso': {}, 'CIF': {} };

    if (idVersion && area) {
      const registrosArea = listarRegistros({ idVersion, area });

      registrosArea.forEach(reg => {
        const dc = reg.detalle_columnas || {};
        const nombreModulo = reg.modulo || dc.modulo || 'Otros';

        if (nombreModulo === 'Costeo de Crisoles') return;

        const anioReg = reg.fecha_proyeccion ? reg.fecha_proyeccion.split('-')[0] : null;
        if (anioReg && anioSel && anioReg !== anioSel) return;

        const procStr = String(dc.proceso || dc.categoria || dc.centro_costo || dc.etapa || reg.categoria || '').toLowerCase();
        let procKey = null;
        if (procStr === '1' || procStr.includes('1') || procStr.includes('primer')) procKey = 'Primer Proceso';
        else if (procStr === '2' || procStr.includes('2') || procStr.includes('segundo')) procKey = 'Segundo Proceso';
        else if (procStr.includes('cif') || procStr.includes('indirecto')) procKey = 'CIF';

        if (procKey) {
          if (!estructura[procKey][nombreModulo]) {
            estructura[procKey][nombreModulo] = MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
          }

          const baseMeses = dc.costos_mensuales || dc.totales_mes || (typeof dc.cantidades === 'object' ? dc.cantidades : null);

          if (baseMeses) {
            MESES.forEach(m => {
              estructura[procKey][nombreModulo][m] += (parseFloat(baseMeses[m]) || 0);
            });
          } else if (dc.mes && MESES.includes(dc.mes)) {
            const costo = parseFloat(reg.totales?.costo_total || dc.costo_total || dc.total || dc.monto || dc.sueldo_mensual || dc.costo || 0);
            estructura[procKey][nombreModulo][dc.mes] += costo;
          } else if (reg.fecha_proyeccion) {
            const mesIndex = parseInt(reg.fecha_proyeccion.split('-')[1], 10) - 1;
            if (mesIndex >= 0 && mesIndex < 12) {
              const costo = parseFloat(reg.totales?.costo_total || dc.costo_total || dc.total || dc.monto || dc.sueldo_mensual || dc.costo || 0);
              estructura[procKey][nombreModulo][MESES[mesIndex]] += costo;
            }
          }
        }
      });
    }
    return estructura;
  }, [idVersion, area, anioSel]);

  // =================================================================
  // CÁLCULO DE LISTAS DE INSUMOS (COMBINA % USO Y % DISTRIBUCIÓN)
  // =================================================================
  const procesarListaInsumos = (lista) => {
    let totalAnual = 0;
    const calculados = lista.map(item => {
      const factor = item.tipoCalculo === 'porcentaje' ? (parseFloat(item.valor) / 100 || 0) : (parseFloat(item.valor) || 0);
      let consumoAnio = 0;
      let costoTotal = 0;

      MESES.forEach(m => {
        const cantMes = cantidadesProduccion[m] || 0;
        
        // % de Uso Manual (Siempre aplica)
        const pctUsoManual = parseFloat(item.porcentajeUso) || 0;
        
        // % de Distribución Automático (Si el botón 🔗 está activo)
        const pctDistribucion = item.usarParticipacion ? (parseFloat(calculoBase.porcentajes[m]) || 0) : 100;
        
        // Fórmula combinada: Producción * Factor/Ratio * (% Uso Fijo) * (% Distribución Mensual)
        const consumoMes = (cantMes * factor) * (pctUsoManual / 100) * (pctDistribucion / 100);
        const costoMes = consumoMes * (parseFloat(item.costoUnitario) || 0);
        
        consumoAnio += consumoMes;
        costoTotal += costoMes;
      });

      totalAnual += costoTotal;
      return { ...item, consumoAnio, costoTotal };
    });
    return { calculados, totalAnual };
  };

  const matCalc = procesarListaInsumos(materiales);
  const sumCalc = procesarListaInsumos(suministros);

  // =================================================================
  // CÁLCULO DE MÓDULOS ASIGNADOS (APLICA % DISTRIBUCIÓN)
  // =================================================================
  const calcularModulos = (listaAsignaciones, procKey) => {
    let totalAsignadoAnual = 0;
    const calculados = listaAsignaciones.map(item => {
      const dbMeses = agrupadosBD[procKey][item.moduloNombre] || MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
      const pctMeses = item.porcentajesMes || MESES.reduce((acc, m) => ({ ...acc, [m]: item.porcentaje ?? '0' }), {});
      let costoAsignadoAnual = 0;
      const mesesAsignados = {};

      MESES.forEach(m => {
        // Si está vinculado 🔗, toma el % calculado. Si no, toma lo escrito por el usuario en cada mes.
        const pctMes = item.usarParticipacion 
          ? (parseFloat(calculoBase.porcentajes[m]) || 0)
          : (parseFloat(pctMeses[m]) || 0);
        
        const asig = dbMeses[m] * (pctMes / 100);
        mesesAsignados[m] = asig;
        costoAsignadoAnual += asig;
      });

      totalAsignadoAnual += costoAsignadoAnual;
      return { ...item, dbMeses, mesesAsignados, costoAsignadoAnual };
    });
    return { calculados, totalAsignadoAnual };
  };

  const calcP1 = calcularModulos(modulosP1, 'Primer Proceso');
  const calcP2 = calcularModulos(modulosP2, 'Segundo Proceso');
  const calcCIF = calcularModulos(modulosCIF, 'CIF');

  // =================================================================
  // TOTALES FINALES Y RESUMEN
  // =================================================================
  const totalProceso1 = matCalc.totalAnual + calcP1.totalAsignadoAnual + (calcCIF.totalAsignadoAnual * 0.5);
  const totalProceso2 = sumCalc.totalAnual + calcP2.totalAsignadoAnual + (calcCIF.totalAsignadoAnual * 0.5);
  const costoTotalAnual = totalProceso1 + totalProceso2;
  const costoUnitarioPromedio = cantidadTotalProduccionAnio > 0 ? (costoTotalAnual / cantidadTotalProduccionAnio) : 0;
  const precioVenta = itemForecast?.precio_venta || 0;

  const actMat = (id, c, v) => setMateriales(materiales.map(m => m.id === id ? { ...m, [c]: v } : m));
  const actSum = (id, c, v) => setSuministros(suministros.map(s => s.id === id ? { ...s, [c]: v } : s));

  const actModP1 = (id, c, v) => setModulosP1(modulosP1.map(m => m.id === id ? { ...m, [c]: v } : m));
  const actModP2 = (id, c, v) => setModulosP2(modulosP2.map(m => m.id === id ? { ...m, [c]: v } : m));
  const actModCIF = (id, c, v) => setModulosCIF(modulosCIF.map(m => m.id === id ? { ...m, [c]: v } : m));

  const renderAsignacionProceso = (titulo, procKey, lista, setter, actor, calculosReales) => {
    const modulosDisponibles = Object.keys(agrupadosBD[procKey]);

    const actualizarPct = (id, mes, valor) => {
      setter(lista.map(m => m.id === id
        ? { ...m, porcentajesMes: { ...(m.porcentajesMes || {}), [mes]: valor } }
        : m
      ));
    };

    return (
      <div style={{ marginBottom: '16px', border: '1px solid #cbd5e1', borderRadius: '8px', overflow: 'hidden' }}>
        <div style={{ background: '#f8fafc', padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #cbd5e1' }}>
          <span style={{ fontWeight: 700, color: '#1e293b' }}>{titulo}</span>
          <button type="button" onClick={() => setter([...lista, _crearItemVacio(String(Date.now()), 'modulo')])} style={{ background: 'white', color: '#2563eb', border: '1px solid #2563eb', padding: '4px 10px', borderRadius: '4px', cursor: 'pointer', fontSize: '11px', fontWeight: 600 }}>+ Agregar Módulo</button>
        </div>

        <div style={{ padding: '12px', background: 'white' }}>
          {lista.length === 0 && <div style={{ fontSize: '12px', color: '#64748b', fontStyle: 'italic', textAlign: 'center' }}>No hay módulos asignados a esta etapa. Haga clic en "+ Agregar Módulo".</div>}

          {lista.map((item, idx) => {
            const dataCalc = calculosReales.calculados.find(c => c.id === item.id);
            const dbMeses = dataCalc?.dbMeses || MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
            const mesesAsig = dataCalc?.mesesAsignados || MESES.reduce((acc, m) => ({ ...acc, [m]: 0 }), {});
            const pctMeses = item.porcentajesMes || MESES.reduce((acc, m) => ({ ...acc, [m]: '100' }), {});

            return (
              <div key={item.id} style={{ marginBottom: '16px', paddingBottom: '12px', borderBottom: idx < lista.length - 1 ? '1px dashed #e2e8f0' : 'none' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-end', marginBottom: '8px' }}>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>SELECCIONAR MÓDULO ORIGEN ({procKey})</label>
                    <select value={item.moduloNombre} onChange={e => actor(item.id, 'moduloNombre', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '13px' }}>
                      <option value="">-- Elija un Módulo con costos en {procKey} --</option>
                      {modulosDisponibles.map(mod => <option key={mod} value={mod}>{mod}</option>)}
                    </select>
                  </div>
                  <button type="button" onClick={() => setter(lista.filter(i => i.id !== item.id))} style={{ padding: '6px', color: '#ef4444', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '4px', cursor: 'pointer' }}>🗑️</button>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '8px' }}>
                  <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>% asignado a producto por mes (editable) · debajo, monto asignado resultante:</div>
                  <button 
                    type="button" 
                    onClick={() => actor(item.id, 'usarParticipacion', !item.usarParticipacion)} 
                    style={{ background: item.usarParticipacion ? '#2563eb' : '#f1f5f9', color: item.usarParticipacion ? 'white' : '#64748b', border: '1px solid #cbd5e1', borderRadius: '4px', padding: '4px 8px', cursor: 'pointer', fontSize: '10px', fontWeight: 'bold' }}
                  >
                    {item.usarParticipacion ? "🔗 Vinculado a Distribución" : "🔗 Vincular a Distribución"}
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '4px' }}>
                  {MESES.map(m => (
                    <div key={m} style={{ background: '#f0fdf4', padding: '4px', borderRadius: '4px', border: '1px solid #bbf7d0', textAlign: 'center' }}>
                      <span style={{ fontSize: '9px', display: 'block', color: '#166534', fontWeight: 'bold' }}>{m}</span>
                      <span style={{ fontSize: '9px', display: 'block', color: '#94a3b8', textDecoration: 'line-through' }} title="Total Proyectado en Módulo">S/{dbMeses[m].toFixed(0)}</span>
                      <input
                        type="number"
                        step="0.1"
                        value={item.usarParticipacion ? (calculoBase.porcentajes[m] || '0') : (pctMeses[m] ?? '100')}
                        disabled={item.usarParticipacion}
                        onChange={e => actualizarPct(item.id, m, e.target.value)}
                        title="% asignado a producto en este mes"
                        style={{ 
                          width: '100%', padding: '2px', margin: '2px 0', border: '1px solid #2563eb', borderRadius: '3px', fontSize: '10px', fontWeight: 'bold', textAlign: 'center',
                          background: item.usarParticipacion ? '#eff6ff' : 'white', color: item.usarParticipacion ? '#2563eb' : '#0f172a'
                        }}
                      />
                      <span style={{ fontSize: '10px', display: 'block', color: '#15803d', fontWeight: 600 }} title="Asignado a este Producto">S/{mesesAsig[m].toFixed(1)}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // =================================================================
  // GUARDAR Y GENERAR CUENTAS
  // =================================================================
  // =================================================================
  // GUARDAR Y GENERAR REGISTROS DERIVADOS EN OTROS MÓDULOS
  // =================================================================
  const handleGuardar = () => {
    if (!productoSel) return alert('Por favor, seleccione un producto.');
    if (cantidadTotalProduccionAnio <= 0) return alert('La cantidad de producción debe ser mayor a 0.');

    const idRegistroMaestro = registro ? registro.id_registro : `CRI-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistroMaestro) : `LOTE-CRI-${Date.now()}`;
    
    const cantidadesComercialNum = MESES.reduce((acc, m) => ({ ...acc, [m]: parseFloat(cantidadesMeses[m]) || 0 }), {});
    const cantidadesProduccionNum = MESES.reduce((acc, m) => ({ ...acc, [m]: cantidadesProduccion[m] }), {});

    const registrosAGuardar = [];
    const cuentas = [];

    // ---------------------------------------------------------------
    // 1. GENERAR EL REGISTRO MAESTRO (Para poder editarlo después)
    // ---------------------------------------------------------------
    const registroMaestro = {
      id_registro: idRegistroMaestro,
      id_lote: idLote,
      modulo: 'Costeo de Crisoles',
      fecha_proyeccion: `${anioSel}-01-01`,
      empleado_dni: '-',
      empleado_nombre: productoSel,
      detalle_columnas: {
        producto: productoSel,
        anio_proyeccion: anioSel,
        margen_produccion: parseFloat(margenProduccion) || 0,
        productos_base: productosBase,
        cantidades_comercial: cantidadesComercialNum,
        cantidad_total_comercial: cantidadTotalAnio,
        cantidades_produccion: cantidadesProduccionNum,
        cantidad_total_produccion: cantidadTotalProduccionAnio,
        precio_venta_unit: precioVenta,
        materiales, suministros, modulosP1, modulosP2, modulosCIF,
        costo_total_anual: costoTotalAnual, costo_unitario_promedio: costoUnitarioPromedio
      },
      // TRUCO CLAVE: El maestro reporta 0 al total general para no duplicar el presupuesto.
      // El valor real vivirá en los registros de Materia Prima y Suministros.
      totales: { cantidad_total: cantidadTotalProduccionAnio, costo_total: 0 },
    };

    // Función auxiliar para inyectar en otros módulos mes a mes
    const crearDerivado = (item, idx, moduloDestino, prefijo) => {
      const mesCostos = {};
      const factor = item.tipoCalculo === 'porcentaje' ? (parseFloat(item.valor) / 100 || 0) : (parseFloat(item.valor) || 0);
      
      MESES.forEach(mes => {
        const cantMes = cantidadesProduccion[mes] || 0;
        const pctUsoManual = parseFloat(item.porcentajeUso) || 0;
        const pctDistribucion = item.usarParticipacion ? (parseFloat(calculoBase.porcentajes[mes]) || 0) : 100;
        const consumoMes = (cantMes * factor) * (pctUsoManual / 100) * (pctDistribucion / 100);
        mesCostos[mes] = consumoMes * (parseFloat(item.costoUnitario) || 0);
      });

      return {
        id_registro: `DERIV-${prefijo}-${Date.now()}-${idx}`,
        id_lote: idLote, // Comparten el mismo lote para que se editen/borren juntos
        modulo: moduloDestino, 
        fecha_proyeccion: `${anioSel}-01-01`,
        empleado_dni: '-',
        empleado_nombre: `${item.insumo} (Para ${productoSel})`,
        categoria: 'Costeo de Producción',
        detalle_columnas: {
          insumo: item.insumo,
          producto_origen: productoSel,
          unidad_medida: item.udm,
          costo_unitario: item.costoUnitario,
          costos_mensuales: mesCostos,
          es_derivado: true
        },
        totales: { costo_total: item.costoTotal }
      };
    };

    // ---------------------------------------------------------------
    // 2. INYECTAR MATERIAS PRIMAS
    // ---------------------------------------------------------------
    matCalc.calculados.forEach((m, idx) => {
      if (m.insumo && m.costoTotal > 0) {
        registrosAGuardar.push(crearDerivado(m, idx, 'Materias Primas', 'MAT'));
        cuentas.push({ id: `mat-${idx}`, cuenta: `946252000 - Materia Prima (${m.insumo})`, monto: m.costoTotal.toFixed(2) });
      }
    });

    // ---------------------------------------------------------------
    // 3. INYECTAR SUMINISTROS
    // ---------------------------------------------------------------
    sumCalc.calculados.forEach((s, idx) => {
      if (s.insumo && s.costoTotal > 0) {
        // Aquí se inyectan a la tabla de Auxiliares y Suministros
        registrosAGuardar.push(crearDerivado(s, idx, 'Materiales Auxiliares y Suministros', 'SUM'));
        cuentas.push({ id: `sum-${idx}`, cuenta: `946252000 - Suministros P2 (${s.insumo})`, monto: s.costoTotal.toFixed(2) });
      }
    });

    // Anotamos las cuentas de los módulos asignados (Estos NO generan derivados porque
    // el presupuesto real ya vive en "Remuneraciones", "Depreciación", etc. Solo se referencian)
    calcP1.calculados.forEach((m, idx) => {
      if (m.moduloNombre) cuentas.push({ id: `p1-${idx}`, cuenta: `946261000 - ${m.moduloNombre} (Proceso 1)`, monto: m.costoAsignadoAnual.toFixed(2) });
    });
    calcP2.calculados.forEach((m, idx) => {
      if (m.moduloNombre) cuentas.push({ id: `p2-${idx}`, cuenta: `946261000 - ${m.moduloNombre} (Proceso 2)`, monto: m.costoAsignadoAnual.toFixed(2) });
    });
    calcCIF.calculados.forEach((m, idx) => {
      if (m.moduloNombre) cuentas.push({ id: `cif-${idx}`, cuenta: `946261000 - ${m.moduloNombre} (CIF Asignado)`, monto: m.costoAsignadoAnual.toFixed(2) });
    });

    // Añadimos las cuentas contables al maestro y lo ponemos al inicio del array
    registroMaestro.desglose_contable = cuentas;
    registrosAGuardar.unshift(registroMaestro);

    // Guardamos todos los registros simultáneamente
    onGuardar(registrosAGuardar);
  };

  const renderListaInsumos = (titulo, lista, setter, actor) => (
    <div className="form-section" style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <div className="form-section-title" style={{ fontWeight: 700, color: '#1e293b' }}>{titulo}</div>
        <button type="button" onClick={() => setter([...lista, _crearItemVacio(String(Date.now()), 'insumo')])} style={{ background: '#2563eb', color: 'white', border: 'none', padding: '4px 10px', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}>+ Agregar Insumo</button>
      </div>
      {lista.map((item) => {
        const factor = item.tipoCalculo === 'porcentaje' ? (parseFloat(item.valor) / 100 || 0) : (parseFloat(item.valor) || 0);

        return (
          <div key={item.id} style={{ marginBottom: '12px', background: 'white', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 70px 100px 1fr 1fr 1fr auto', gap: '8px', alignItems: 'center', marginBottom: '8px' }}>
              <div><label style={{ fontSize: '10px', color: '#64748b' }}>Insumo</label><input type="text" value={item.insumo} onChange={e => actor(item.id, 'insumo', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }} /></div>
              <div><label style={{ fontSize: '10px', color: '#64748b' }}>UdM</label><select value={item.udm} onChange={e => actor(item.id, 'udm', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }}><option value="kg">kg</option><option value="gr">gr</option><option value="lt">lt</option><option value="und">und</option></select></div>
              <div><label style={{ fontSize: '10px', color: '#64748b' }}>Método</label><select value={item.tipoCalculo} onChange={e => actor(item.id, 'tipoCalculo', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }}><option value="ratio">Ratio unit.</option><option value="porcentaje">Porcentaje</option></select></div>
              <div><label style={{ fontSize: '10px', color: '#64748b', whiteSpace: 'nowrap' }}>{item.tipoCalculo === 'porcentaje' ? 'Valor (%)' : 'Valor (Ratio)'}</label><input type="number" step="0.0001" value={item.valor} onChange={e => actor(item.id, 'valor', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }} /></div>
              
              {/* MODIFICADO: Input manual siempre visible + botón de vínculo auto */}
              <div>
                <label style={{ fontSize: '10px', color: '#64748b', whiteSpace: 'nowrap' }}>% de Uso</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <input type="number" step="0.01" value={item.porcentajeUso} onChange={e => actor(item.id, 'porcentajeUso', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }} />
                  <button 
                    type="button" 
                    onClick={() => actor(item.id, 'usarParticipacion', !item.usarParticipacion)} 
                    title={item.usarParticipacion ? "Desvincular de Base de Distribución" : "Vincular a Base de Distribución"}
                    style={{ background: item.usarParticipacion ? '#2563eb' : '#e2e8f0', color: item.usarParticipacion ? 'white' : '#64748b', border: 'none', borderRadius: '4px', padding: '6px', cursor: 'pointer', fontSize: '10px' }}
                  >
                    🔗
                  </button>
                </div>
              </div>

              <div><label style={{ fontSize: '10px', color: '#64748b' }}>Costo U. (S/)</label><input type="number" step="0.01" value={item.costoUnitario} onChange={e => actor(item.id, 'costoUnitario', e.target.value)} style={{ width: '100%', padding: '6px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '12px' }} /></div>
              {lista.length > 1 && <button type="button" onClick={() => setter(lista.filter(i => i.id !== item.id))} style={{ color: '#ef4444', cursor: 'pointer', fontSize: '16px', background: 'none', border: 'none', marginTop: '14px' }}>🗑️</button>}
            </div>
            
            <div style={{ fontSize: '11px', color: '#64748b', marginBottom: '4px', fontWeight: 600 }}>Consumo mensual ({item.udm || 'u'} / S/):</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '4px' }}>
              {MESES.map(m => {
                const cantMes = cantidadesProduccion[m] || 0;
                
                // Muestra el % si el vínculo está activo
                const pctDistribucion = item.usarParticipacion ? (parseFloat(calculoBase.porcentajes[m]) || 0) : 100;
                const pctUsoManual = parseFloat(item.porcentajeUso) || 0;
                
                const consumoU = (cantMes * factor) * (pctUsoManual / 100) * (pctDistribucion / 100);
                const costoM = consumoU * (parseFloat(item.costoUnitario) || 0);
                
                return (
                  <div key={m} style={{ background: '#f8fafc', padding: '4px', borderRadius: '4px', border: '1px solid #e2e8f0', textAlign: 'center', position: 'relative' }}>
                    <span style={{ fontSize: '9px', display: 'block', color: '#64748b', fontWeight: 'bold' }}>{m}</span>
                    <span style={{ fontSize: '10px', display: 'block', color: '#166534' }}>{consumoU.toFixed(1)} {item.udm}</span>
                    <span style={{ fontSize: '9px', display: 'block', color: '#334155' }}>S/ {costoM.toFixed(1)}</span>
                    {/* Indicador visual de que se está multiplicando por la base de distribución */}
                    {item.usarParticipacion && (
                      <span style={{ fontSize: '8px', color: '#2563eb', fontWeight: 700, display: 'block', marginTop: '2px' }}>({pctDistribucion}%)</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minWidth: '750px' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: '0' }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto', padding: '16px' }}>

          <div className="form-section" style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
            <div className="form-section-title" style={{ fontWeight: 700, color: '#1e293b', marginBottom: '10px' }}>1. Producto y Proyección (Comercial vs Producción)</div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '10px', marginBottom: '16px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRODUCTO PROYECTADO</label>
                <select value={productoSel} onChange={e => handleSeleccionarProducto(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px', background: 'white' }}>
                  <option value="">-- Seleccione --</option>{productosAgrupados.map(p => <option key={p.producto} value={p.producto}>{p.producto}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#2563eb' }}>AÑO</label>
                <select value={anioSel} onChange={e => setAnioSel(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #cbd5e1', borderRadius: '4px', background: 'white', fontWeight: 600 }}>
                  {ANIOS_DISPONIBLES.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#059669' }}>MARGEN PROD. (%)</label>
                <input type="number" step="0.1" value={margenProduccion} onChange={e => setMargenProduccion(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #10b981', borderRadius: '4px', background: '#ecfdf5', fontWeight: 600, color: '#047857' }} />
              </div>
            </div>

            <div style={{ fontSize: '10px', color: '#64748b', marginBottom: '4px', fontWeight: 600 }}>CANTIDADES COMERCIALES (Base - Editable temporalmente)</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px', marginBottom: '12px' }}>
              {MESES.map(m => (
                <div key={`com-${m}`} style={{ margin: 0 }}>
                  <label style={{ fontSize: '9px', fontWeight: 600, color: '#64748b', display: 'block', textAlign: 'center' }}>{m}</label>
                  <input type="number" value={cantidadesMeses[m]} onChange={e => setCantidadesMeses({ ...cantidadesMeses, [m]: e.target.value })} style={{ width: '100%', padding: '4px', border: '1px solid #cbd5e1', borderRadius: '4px', textAlign: 'center' }} />
                </div>
              ))}
            </div>

            <div style={{ fontSize: '10px', color: '#059669', marginBottom: '4px', fontWeight: 600 }}>CANTIDADES A PRODUCIR (Con Holgura del {margenProduccion}%)</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px' }}>
              {MESES.map(m => (
                <div key={`prod-${m}`} style={{ background: '#d1fae5', padding: '6px', borderRadius: '4px', border: '1px solid #6ee7b7', textAlign: 'center' }}>
                  <span style={{ fontSize: '9px', display: 'block', color: '#047857', fontWeight: 'bold' }}>{m}</span>
                  <span style={{ fontSize: '13px', display: 'block', color: '#065f46', fontWeight: 700 }}>{cantidadesProduccion[m]}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="form-section" style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0', marginTop: '-10px', marginBottom: '20px' }}>
            <div style={{ fontWeight: 700, color: '#1e293b', marginBottom: '10px', fontSize: '12px' }}>1.1. Base de Distribución (% de Participación)</div>
            <div style={{ fontSize: '10px', color: '#64748b', marginBottom: '10px' }}>Seleccione la familia de productos para sumar el volumen total y obtener el ratio de participación de <strong>{productoSel || 'este producto'}</strong>.</div>
            
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginBottom: '14px', background: 'white', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
              {productosAgrupados.map(p => (
                <label key={p.producto} style={{ fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', color: '#334155' }}>
                  <input 
                    type="checkbox" 
                    checked={productosBase.includes(p.producto)} 
                    onChange={(e) => {
                      if (e.target.checked) setProductosBase([...productosBase, p.producto]);
                      else setProductosBase(productosBase.filter(prod => prod !== p.producto));
                    }} 
                  />
                  {p.producto}
                </label>
              ))}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px' }}>
              {MESES.map(m => (
                <div key={m} style={{ background: 'white', padding: '6px', borderRadius: '4px', border: '1px solid #cbd5e1', textAlign: 'center' }}>
                  <span style={{ fontSize: '9px', display: 'block', color: '#64748b', fontWeight: 'bold' }}>{m}</span>
                  <span style={{ fontSize: '9px', display: 'block', color: '#475569' }}>Total Vol: {calculoBase.totalesBase[m]}</span>
                  <span style={{ fontSize: '12px', display: 'block', color: '#2563eb', fontWeight: 700, marginTop: '2px' }}>{calculoBase.porcentajes[m]}%</span>
                </div>
              ))}
            </div>
          </div>

          {renderListaInsumos("2. Lista de Materiales (Impacta al Proceso 1)", materiales, setMateriales, actMat)}
          {renderListaInsumos("3. Suministros (Impacta al Proceso 2)", suministros, setSuministros, actSum)}

          <div className="form-section">
            <div className="form-section-title" style={{ fontWeight: 700, color: '#1e293b', marginBottom: '16px' }}>4. Asignación Dinámica de Costos por Proceso (MOD y Otros)</div>
            {renderAsignacionProceso('Etapa: Primer Proceso', 'Primer Proceso', modulosP1, setModulosP1, actModP1, calcP1)}
            {renderAsignacionProceso('Etapa: Segundo Proceso', 'Segundo Proceso', modulosP2, setModulosP2, actModP2, calcP2)}
            {renderAsignacionProceso('Etapa: Costos Indirectos de Fabricación (CIF)', 'CIF', modulosCIF, setModulosCIF, actModCIF, calcCIF)}
          </div>

          <div className="form-section" style={{ marginTop: 'auto', display: 'flex', gap: '12px' }}>
            <div style={{ flex: 1, background: '#fffbeb', padding: '14px', borderRadius: '8px', border: '1px solid #fde68a' }}>
              <div style={{ fontWeight: 700, color: '#92400e', marginBottom: '8px' }}>Resumen Costeo Proceso 1</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#b45309' }}><span>Materiales</span><span>S/ {matCalc.totalAnual.toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#b45309' }}><span>Módulos Primer Proceso</span><span>S/ {calcP1.totalAsignadoAnual.toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#b45309' }}><span>Módulos CIF (50%)</span><span>S/ {(calcCIF.totalAsignadoAnual * 0.5).toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#92400e', fontSize: '14px', borderTop: '1px solid #fcd34d', marginTop: '6px', paddingTop: '6px' }}>
                <span>Subtotal P1</span><span>S/ {totalProceso1.toLocaleString('en-US', {minimumFractionDigits:2})}</span>
              </div>
            </div>

            <div style={{ flex: 1, background: '#eff6ff', padding: '14px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
              <div style={{ fontWeight: 700, color: '#1e40af', marginBottom: '8px' }}>Resumen Costeo Proceso 2</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#2563eb' }}><span>Suministros (GNV, Cajas..)</span><span>S/ {sumCalc.totalAnual.toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#2563eb' }}><span>Módulos Segundo Proceso</span><span>S/ {calcP2.totalAsignadoAnual.toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#2563eb' }}><span>Módulos CIF (50%)</span><span>S/ {(calcCIF.totalAsignadoAnual * 0.5).toLocaleString('en-US', {minimumFractionDigits:2})}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#1e40af', fontSize: '14px', borderTop: '1px solid #93c5fd', marginTop: '6px', paddingTop: '6px' }}>
                <span>Subtotal P2</span><span>S/ {totalProceso2.toLocaleString('en-US', {minimumFractionDigits:2})}</span>
              </div>
            </div>
          </div>

          <div style={{ background: '#f0fdf4', padding: '16px', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#15803d', fontSize: '16px' }}>
              <span>COSTO UNITARIO PROMEDIO (Sobre Producción):</span><span>S/ {costoUnitarioPromedio.toFixed(4)} / unid.</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '18px', marginTop: '4px' }}>
              <span>COSTO TOTAL ANUAL (P1 + P2):</span><span>S/ {costoTotalAnual.toLocaleString('en-US', {minimumFractionDigits:2})}</span>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid #cbd5e1', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>{isSoloLectura ? 'Cerrar' : 'Cancelar'}</button>
        {!isSoloLectura && <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: '#2563eb', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>Guardar Costeo</button>}
      </div>
    </div>
  );
}