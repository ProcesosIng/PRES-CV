import React from 'react';

export default function PlanDepreciacionFila({ reg, onVer, onEditar, onBorrar }) {
  const dc = reg.detalle_columnas || {};
  return (
    <tr key={reg.id_registro}>
      <td className="mono-id">{dc.numero_cuenta || '-'}</td>
      <td style={{ fontWeight: 500 }}>{dc.descripcion_cuenta || '-'}</td>
      <td>{dc.area || '-'}</td>
      <td style={{ textAlign: 'right' }} className="font-mono">
        S/ {(dc.gasto_adq || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'center' }}>{dc.mes_adq || '-'}</td>
      <td style={{ textAlign: 'center' }}>{dc.vida_util || 0}</td>
      <td style={{ textAlign: 'center' }}>{dc.pct_depr_anual || 0}%</td>
      <td style={{ textAlign: 'right', fontWeight: 600, color: '#166534' }} className="font-mono">
        S/ {(dc.deprec_mensual || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'center' }}>
        <button onClick={() => onVer(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Ver">👁️</button>
        <button onClick={() => onEditar(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Editar">✏️</button>
        <button onClick={() => onBorrar(reg.id_registro)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }} title="Eliminar">🗑️</button>
      </td>
    </tr>
  );
}
