import React, { useState, useEffect, useMemo } from 'react';
import { maestroCuentas, MESES, PROCESOS_PRODUCTIVOS } from '../../config/data';

// Campos según el formato "PLAN DEPRECIACION": número de cuenta, área,
// descripción de cuenta, uso, detalle, gasto de adquisición, mes de
// adquisición, vida útil, % de depreciación anual y % depreciación
// política CV. La depreciación mensual se calcula automáticamente.
export default function PlanDepreciacionForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';

  const [numeroCuenta, setNumeroCuenta] = useState('');
  const [area, setArea] = useState('');
  const [descripcionCuenta, setDescripcionCuenta] = useState('');
  const [uso, setUso] = useState('');
  const [detalle, setDetalle] = useState('');
  const [gastoAdq, setGastoAdq] = useState('');
  const [mesAdq, setMesAdq] = useState('Ene');
  const [vidaUtil, setVidaUtil] = useState('');
  const [pctDeprAnual, setPctDeprAnual] = useState('');
  const [pctDeprPoliticaCv, setPctDeprPoliticaCv] = useState('');
  const [proceso, setProceso] = useState('');

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setNumeroCuenta(dc.numero_cuenta || '');
      setArea(dc.area || '');
      setDescripcionCuenta(dc.descripcion_cuenta || '');
      setUso(dc.uso || '');
      setDetalle(dc.detalle || '');
      setGastoAdq(dc.gasto_adq?.toString() || '');
      setMesAdq(dc.mes_adq || 'Ene');
      setVidaUtil(dc.vida_util?.toString() || '');
      setPctDeprAnual(dc.pct_depr_anual?.toString() || '');
      setPctDeprPoliticaCv(dc.pct_depr_politica_cv?.toString() || '');
      setProceso(dc.proceso || '');
    }
  }, [registro]);

  // Depreciación mensual = gasto de adquisición / vida útil (meses).
  // Si no hay vida útil pero sí % anual, se usa gasto x %anual / 12.
  const deprMensual = useMemo(() => {
    const gasto = parseFloat(gastoAdq) || 0;
    const vida = parseFloat(vidaUtil) || 0;
    if (vida > 0) return gasto / vida;
    const pct = parseFloat(pctDeprAnual) || 0;
    return (gasto * pct / 100) / 12;
  }, [gastoAdq, vidaUtil, pctDeprAnual]);

  const handleGuardar = () => {
    if (!numeroCuenta) return alert('Por favor, ingrese el número de cuenta.');
    if (!gastoAdq) return alert('Por favor, ingrese el gasto de adquisición.');

    const idRegistro = registro ? registro.id_registro : `DEP-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistro) : `LOTE-DEP-${Date.now()}`;
    const cuentaInfo = maestroCuentas.find(c => c.id === numeroCuenta);

    const nuevoRegistro = {
      id_registro: idRegistro,
      id_lote: idLote,
      fecha_proyeccion: `2026-${(MESES.indexOf(mesAdq) + 1).toString().padStart(2, '0')}-01`,
      empleado_dni: '-',
      empleado_nombre: descripcionCuenta || 'Activo',
      detalle_columnas: {
        numero_cuenta: numeroCuenta,
        area, proceso,
        descripcion_cuenta: descripcionCuenta,
        uso, detalle,
        gasto_adq: parseFloat(gastoAdq) || 0,
        mes_adq: mesAdq,
        vida_util: parseFloat(vidaUtil) || 0,
        pct_depr_anual: parseFloat(pctDeprAnual) || 0,
        pct_depr_politica_cv: parseFloat(pctDeprPoliticaCv) || 0,
        deprec_mensual: deprMensual,
        costo_total: deprMensual,
      },
      totales: { costo_total: deprMensual },
      desglose_contable: [{
        id: 'cta-1',
        cuenta: `${numeroCuenta}${cuentaInfo ? ' - ' + cuentaInfo.nombre : ' - Depreciación'}`,
        monto: deprMensual.toFixed(2)
      }],
    };

    onGuardar([nuevoRegistro]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Cuenta y Activo</div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label style={{ color: 'var(--primary-600, #2563eb)' }}>Nº CUENTA</label>
              <input list="lista-cuentas-dep" value={numeroCuenta} onChange={e => setNumeroCuenta(e.target.value)}
                placeholder="Ej. 946271000" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              <datalist id="lista-cuentas-dep">
                {maestroCuentas.map((c, i) => <option key={i} value={c.id}>{c.nombre}</option>)}
              </datalist>
            </div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label>DESCRIPCIÓN DE CUENTA</label>
              <input type="text" value={descripcionCuenta} onChange={e => setDescripcionCuenta(e.target.value)}
                placeholder="Ej. Horno de calcinación N°2" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ÁREA</label>
                <input type="text" value={area} onChange={e => setArea(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
                <select value={proceso} onChange={e => setProceso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>USO</label>
                <input type="text" value={uso} onChange={e => setUso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0, gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DETALLE</label>
                <input type="text" value={detalle} onChange={e => setDetalle(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">2. Adquisición y Depreciación</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>GASTO ADQUISICIÓN (S/)</label>
                <input type="number" step="0.01" value={gastoAdq} onChange={e => setGastoAdq(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES DE ADQ.</label>
                <select value={mesAdq} onChange={e => setMesAdq(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>VIDA ÚTIL (MESES)</label>
                <input type="number" value={vidaUtil} onChange={e => setVidaUtil(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>% DEPR. ANUAL</label>
                <input type="number" step="0.01" value={pctDeprAnual} onChange={e => setPctDeprAnual(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0, gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>% DEPR. POLÍTICA CV</label>
                <input type="number" step="0.01" value={pctDeprPoliticaCv} onChange={e => setPctDeprPoliticaCv(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            <div className="form-section-title">3. Impacto Contable</div>
            <div className="calc-total" style={{ marginTop: '8px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <span>Depreciación Mensual</span>
                <span>S/ {deprMensual.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
    </div>
  );
}
