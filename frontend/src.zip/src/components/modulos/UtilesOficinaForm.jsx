import React, { useState, useEffect } from 'react';
import { maestroEmpleados, maestroCuentas, MESES, PROCESOS_PRODUCTIVOS } from '../../config/data';

// Campos según el formato "UTILES ESCOLARES/OFICINA": descripción del
// material, cuenta, mes de uso, cantidad, precio unitario, unidad de
// medida y "fines de uso". Sigue el mismo patrón de líneas independientes
// que UniformesForm (varios materiales por registro).
export default function UtilesOficinaForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';

  const [valorBuscador, setValorBuscador] = useState('');
  const [datosAuto, setDatosAuto] = useState({ dni: '', dist: '100' });
  const [proceso, setProceso] = useState('');
  const [mesUso, setMesUso] = useState('Ene');
  const [finesDeUso, setFinesDeUso] = useState('');

  const [filasItems, setFilasItems] = useState([
    { id: Date.now(), descripcion: '', cuenta: '', cantidad: 1, precioUnit: '', unidMed: 'Unidad' }
  ]);

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setValorBuscador(`${registro.empleado_dni || ''} - ${registro.empleado_nombre || ''}`);
      setDatosAuto({ dni: registro.empleado_dni || '', dist: dc.distribucion?.toString() || '100' });
      setProceso(dc.proceso || '');
      setMesUso(dc.mes_uso || 'Ene');
      setFinesDeUso(dc.fines_de_uso || '');
      setFilasItems([{
        id: registro.id_registro,
        descripcion: dc.descripcion_material || '',
        cuenta: dc.cuenta || '',
        cantidad: dc.cantidad || 1,
        precioUnit: dc.precio_unit?.toString() || '',
        unidMed: dc.unid_med || 'Unidad'
      }]);
    }
  }, [registro]);

  const handleAutocomplete = (e) => {
    const text = e.target.value;
    setValorBuscador(text);
    const idSeleccionado = text.split(' - ')[0];
    const emp = maestroEmpleados.find(emp => (emp.dni || emp.id) === idSeleccionado);
    if (emp) setDatosAuto({ dni: emp.dni || emp.id, dist: emp.distribucion?.toString().replace('%', '') || '100' });
  };

  const actualizarFila = (id, campo, valor) => {
    setFilasItems(filasItems.map(f => f.id === id ? { ...f, [campo]: valor } : f));
  };

  const totalGeneral = filasItems.reduce((s, f) => s + ((parseFloat(f.precioUnit) || 0) * (parseFloat(f.cantidad) || 0)), 0);

  const handleGuardar = () => {
    if (!valorBuscador) return alert('Por favor, seleccione un empleado o área responsable.');
    if (!filasItems[0].descripcion) return alert('Agregue al menos un material.');

    const empInfo = maestroEmpleados.find(e => (e.dni || e.id) === datosAuto.dni);
    const nombreEmpleado = empInfo ? empInfo.nombre : (valorBuscador.split(' - ')[1] || 'Desconocido');
    const idLote = registro ? (registro.id_lote || registro.id_registro) : `LOTE-UTI-${Date.now()}`;
    const fecha = `2026-${(MESES.indexOf(mesUso) + 1).toString().padStart(2, '0')}-01`;

    const nuevosRegistros = filasItems
      .filter(f => f.descripcion)
      .map((fila, idx) => {
        const costoTotal = (parseFloat(fila.precioUnit) || 0) * (parseFloat(fila.cantidad) || 0);
        const cuentaInfo = maestroCuentas.find(c => c.id === fila.cuenta);
        const idRegistro = (registro && idx === 0) ? registro.id_registro : `UTI-${Date.now()}-${idx}`;

        return {
          id_registro: idRegistro,
          id_lote: idLote,
          fecha_proyeccion: fecha,
          empleado_dni: datosAuto.dni || '-',
          empleado_nombre: nombreEmpleado,
          detalle_columnas: {
            descripcion_material: fila.descripcion,
            cuenta: fila.cuenta,
            mes_uso: mesUso,
            fines_de_uso: finesDeUso,
            proceso,
            cantidad: parseFloat(fila.cantidad) || 0,
            precio_unit: parseFloat(fila.precioUnit) || 0,
            unid_med: fila.unidMed,
            distribucion: parseFloat(datosAuto.dist) || 100,
            costo_total: costoTotal,
          },
          totales: { costo_total: costoTotal },
          desglose_contable: [{
            id: `cta-${idx}`,
            cuenta: `${fila.cuenta}${cuentaInfo ? ' - ' + cuentaInfo.nombre : ''} - ${fila.descripcion}`,
            monto: costoTotal.toFixed(2)
          }],
        };
      });

    onGuardar(nuevosRegistros);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Información General</div>
            <div className="form-group" style={{ marginBottom: '12px' }}>
              <label style={{ color: 'var(--primary-600, #2563eb)' }}>EMPLEADO / ÁREA RESPONSABLE</label>
              <input list="lista-emp-uti" value={valorBuscador} onChange={handleAutocomplete}
                placeholder="Escriba para buscar..." autoComplete="off"
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              <datalist id="lista-emp-uti">
                {maestroEmpleados.map((e, i) => <option key={i} value={`${e.dni || e.id} - ${e.nombre}`} />)}
              </datalist>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>MES DE USO</label>
                <select value={mesUso} onChange={e => setMesUso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  {MESES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
                <select value={proceso} onChange={e => setProceso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>FINES DE USO</label>
                <input type="text" value={finesDeUso} onChange={e => setFinesDeUso(e.target.value)} placeholder="Ej. Oficina Administración"
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">2. Materiales (líneas independientes)</div>
            <datalist id="lista-cuentas-uti">
              {maestroCuentas.map((c, i) => <option key={i} value={c.id}>{c.nombre}</option>)}
            </datalist>

            {filasItems.map((fila, index) => (
              <div key={fila.id} style={{ display: 'flex', gap: '8px', marginBottom: '8px', alignItems: 'flex-end' }}>
                <div className="form-group" style={{ flex: 3, margin: 0 }}>
                  {index === 0 && <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DESCRIPCIÓN MATERIAL</label>}
                  <input type="text" value={fila.descripcion} onChange={e => actualizarFila(fila.id, 'descripcion', e.target.value)}
                    placeholder="Ej. Papel Bond A4" style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
                </div>
                <div className="form-group" style={{ flex: 2, margin: 0 }}>
                  {index === 0 && <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CUENTA</label>}
                  <input type="text" list="lista-cuentas-uti" value={fila.cuenta} onChange={e => actualizarFila(fila.id, 'cuenta', e.target.value)}
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
                </div>
                <div className="form-group" style={{ flex: 1, margin: 0 }}>
                  {index === 0 && <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CANT.</label>}
                  <input type="number" min="1" value={fila.cantidad} onChange={e => actualizarFila(fila.id, 'cantidad', e.target.value)}
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', textAlign: 'center' }} />
                </div>
                <div className="form-group" style={{ flex: 1, margin: 0 }}>
                  {index === 0 && <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRECIO UNIT.</label>}
                  <input type="number" step="0.01" value={fila.precioUnit} onChange={e => actualizarFila(fila.id, 'precioUnit', e.target.value)}
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', textAlign: 'right' }} />
                </div>
                {filasItems.length > 1 && (
                  <button type="button" onClick={() => setFilasItems(filasItems.filter(f => f.id !== fila.id))}
                    style={{ background: 'transparent', border: 'none', color: 'var(--danger, #ef4444)', fontSize: '20px', cursor: 'pointer' }}>&times;</button>
                )}
              </div>
            ))}

            <button type="button"
              onClick={() => setFilasItems([...filasItems, { id: Date.now(), descripcion: '', cuenta: '', cantidad: 1, precioUnit: '', unidMed: 'Unidad' }])}
              className="btn-ghost" style={{ width: '100%', marginTop: '8px', borderStyle: 'dashed', background: 'white' }}>
              + Agregar Material
            </button>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            <div className="form-section-title">3. Impacto Contable</div>
            <div className="calc-total" style={{ marginTop: '8px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <span>Total Proyectado</span>
                <span>S/ {totalGeneral.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
    </div>
  );
}
