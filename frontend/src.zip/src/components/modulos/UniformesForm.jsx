import React, { useState, useEffect } from 'react';
import { maestroEmpleados, maestroCuentas, maestroProductos, PROCESOS_PRODUCTIVOS } from '../../config/data';

export default function UniformesForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';
  
  const [datosAuto, setDatosAuto] = useState({});
  const [fechaInput, setFechaInput] = useState('');
  const [fechasSeleccionadas, setFechasSeleccionadas] = useState([]);
  const [valorBuscador, setValorBuscador] = useState('');
  const [proceso, setProceso] = useState('');
  
  const [filasEpps, setFilasEpps] = useState([{ id: Date.now(), producto: '', cantidad: 1 }]);
  const [filasCuentas, setFilasCuentas] = useState([]);

  // 1. CARGA INICIAL Y LIMPIEZA
  useEffect(() => {
    if (registro) {
      const emp = maestroEmpleados.find(e => (e.dni || e.id) === registro.empleado_dni);
      setDatosAuto({
        'auto-dni': registro.empleado_dni || '',
        'auto-dist': registro.detalle_columnas?.distribucion?.toString() || '100',
      });

      setProceso(registro.detalle_columnas?.proceso || '');
      setValorBuscador(`${registro.empleado_dni} - ${registro.empleado_nombre}`);
      
      // AL EDITAR UNA LÍNEA: Cargamos SOLO este producto y cantidad específica del registro, 
      // ignorando los demás del lote para que se edite de forma unitaria.
      const productoEspecifico = registro.detalle_columnas?.epp_nombre || '';
      const cantidadEspecifica = registro.detalle_columnas?.cantidad || 1;

      setFilasEpps([
        { 
          id: registro.id_registro, 
          producto: productoEspecifico, 
          cantidad: cantidadEspecifica 
        }
      ]);

      setFilasCuentas(registro.desglose_contable || []);
      setFechasSeleccionadas([registro.fecha_proyeccion]);
    } else {
      setFilasEpps([{ id: Date.now(), producto: '', cantidad: 1 }]);
      setFilasCuentas([]);
      setFechasSeleccionadas([]);
      setValorBuscador('');
      setProceso('');
      setDatosAuto({});
    }
  }, [registro]);

  // 2. AUTOCOMPLETADO DE EMPLEADO
  const handleAutocompleteEmp = (e) => {
    const idSeleccionado = e.target.value.split(' - ')[0];
    const emp = maestroEmpleados.find(emp => (emp.dni || emp.id) === idSeleccionado);
    if (emp) {
      setDatosAuto({
        'auto-dni': emp.dni || emp.id,
        'auto-dist': emp.distribucion?.replace('%', '') || '100',
      });
    }
  };

  // 3. MOTOR MATEMÁTICO
  useEffect(() => {
    const cuentaEPP = maestroCuentas.find(c => c.nombre.toLowerCase().includes('uniforme')) || { id: '65610000', nombre: 'Suministros y EPPs' };
    const nuevasCuentas = [];

    filasEpps.forEach((fila, idx) => {
      if (!fila.producto) return;
      const prod = maestroProductos?.find(p => p.nombre === fila.producto || p.codigo === fila.producto);
      const costoUnitario = prod ? parseFloat(prod.costo) || 0 : 0;
      const cantidad = parseFloat(fila.cantidad) || 0;
      const subtotal = costoUnitario * cantidad;

      if (subtotal > 0) {
        nuevasCuentas.push({
          id: `cta-epp-${idx}`,
          cuenta: `${cuentaEPP.id} - ${cuentaEPP.nombre}`,
          monto: subtotal.toFixed(2)
        });
      }
    });

    setFilasCuentas(nuevasCuentas);
  }, [filasEpps]);

  // 4. GUARDADO
  const handleGuardar = () => {
    const fechasFinales = [...fechasSeleccionadas];
    if (fechaInput && !fechasFinales.includes(fechaInput)) {
      fechasFinales.push(fechaInput);
    }

    // Validaciones básicas
    if (fechasFinales.length === 0) return alert('Ingresa al menos una fecha.');
    if (!datosAuto['auto-dni']) return alert('Selecciona un empleado.');
    if (filasEpps.length === 0 || !filasEpps[0].producto) return alert('Agrega al menos un producto EPP.');

    //  Construimos el nombre del empleado a partir del valor del buscador
    const empInfo = maestroEmpleados.find(e => (e.dni || e.id) === datosAuto['auto-dni']);
    const nombreEmpleado = empInfo ? empInfo.nombre : 'Desconocido';

    let nuevosRegistros = [];
    
    fechasFinales.forEach((fecha, fechaIndex) => {
      filasEpps.forEach((fila, prodIndex) => {
        if (!fila.producto) return;

        const prod = maestroProductos?.find(p => p.nombre === fila.producto || p.codigo === fila.producto);
        const costoUnitario = prod ? parseFloat(prod.costo) || 0 : 0;
        const cantidadNum = parseFloat(fila.cantidad) || 1;
        const costoTotalItem = costoUnitario * cantidadNum;
        
        const cuentaEPP = maestroCuentas.find(c => c.nombre.toLowerCase().includes('epp') || c.id.startsWith('65')) || { id: '65610000', nombre: 'Suministros y EPPs' };

        // SI ESTAMOS EDITANDO: Conservamos exactamente el id_registro de la fila que se abrió
        const idFinalRegistro = registro ? registro.id_registro : `REG-EPP-${Date.now()}-${fechaIndex}-${prodIndex}`;
        const idLoteFinal = registro ? registro.id_lote : `LOTE-EPP-${Date.now()}`;

        const nuevoItem = {
          id_registro: idFinalRegistro, 
          id_lote: idLoteFinal,
          fecha_proyeccion: fecha,
          empleado_dni: datosAuto['auto-dni'],
          empleado_nombre: nombreEmpleado,
          detalle_columnas: {
            epp_nombre: fila.producto,
            cantidad: cantidadNum,
            proceso: proceso,
            costo_total: costoTotalItem,
            distribucion: parseFloat(datosAuto['auto-dist']) || 100
          },
          totales: { costo_total: costoTotalItem },
          desglose_contable: [
            {
              id: `cta-${fechaIndex}-${prodIndex}`,
              cuenta: `${cuentaEPP.id} - ${cuentaEPP.nombre} - ${fila.producto}`,
              monto: costoTotalItem.toFixed(2)
            }
          ],
          variables_registro: { filasEpps }
        };

        nuevosRegistros.push(nuevoItem);
      });
    });

    onGuardar(nuevosRegistros);
  };

  const agregarFecha = () => {
    if (fechaInput && !fechasSeleccionadas.includes(fechaInput)) {
      setFechasSeleccionadas([...fechasSeleccionadas, fechaInput]);
      setFechaInput('');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      
      {/* PROTECCIÓN CON FIELDSET PARA MODO VER / EDITAR */}
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>
          
          {/* FECHAS */}
          <div className="form-section">
            <div className="form-section-title">0. Fechas de Aplicación</div>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
              <input type="date" value={fechaInput} onChange={e => setFechaInput(e.target.value)} style={{ flex: 1, padding: '8px', border: '1px solid var(--line)', outline: 'none' }} />
              <button type="button" onClick={agregarFecha} className="btn-ghost" style={{ background: 'white' }}>+ Añadir</button>
            </div>
            {fechasSeleccionadas.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {fechasSeleccionadas.map(f => (
                  <div key={f} style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', padding: '4px 10px', borderRadius: '99px', fontSize: '12px' }}>
                    {f.split('-').reverse().join('/')}
                    <span onClick={() => setFechasSeleccionadas(fechasSeleccionadas.filter(x => x !== f))} style={{ cursor: 'pointer', fontWeight: 'bold', marginLeft: '6px' }}>&times;</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* INFORMACIÓN GENERAL */}
          <div className="form-section">
            <div className="form-section-title">1. Información General</div>
            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label style={{ color: 'var(--primary-600)' }}>Buscar Empleado</label>
              <input 
                list="lista-empleados-epp" 
                value={valorBuscador}
                onChange={(e) => {
                  setValorBuscador(e.target.value);
                  handleAutocompleteEmp(e);
                }} 
                placeholder="Escriba para buscar operario..." 
                autoComplete="off" 
              />
              <datalist id="lista-empleados-epp">
                {maestroEmpleados.map(e => <option key={e.dni||e.id} value={`${e.dni||e.id} - ${e.nombre}`} />)}
              </datalist>
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>DNI</label>
                <input type="text" 
                  value={datosAuto['auto-dni'] || ''}
                  readOnly style={{ background: '#f8fafc' }} />
              </div>
              <div className="form-group">
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Distribución (%)</label>
                <input 
                  type="text" 
                  value={datosAuto['auto-dist'] || '100'} 
                  onChange={e => setDatosAuto({ ...datosAuto, 'auto-dist': e.target.value })} 
                />
              </div>
              
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PROCESO</label>
                <select value={proceso} onChange={e => setProceso(e.target.value)}
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>

            </div>
          </div>

          {/* VARIABLES DE REGISTRO: MÚLTIPLES EPPs */}
          <div className="form-section">
            <div className="form-section-title">2. Asignación de EPPs (Líneas independientes)</div>
            
            {filasEpps.map((fila, index) => (
              <div key={fila.id} style={{ display: 'flex', gap: '8px', marginBottom: '12px', alignItems: 'center' }}>
                <div className="form-group" style={{ flex: 3, margin: 0 }}>
                  <select 
                    value={fila.producto} 
                    onChange={e => {
                      const nuevas = [...filasEpps];
                      nuevas[index].producto = e.target.value;
                      setFilasEpps(nuevas);
                    }}
                    style={{ width: '100%', padding: '8px', border: '1px solid var(--line)', borderRadius: '4px' }}
                  >
                    <option value="">-- Seleccione EPP --</option>
                    {maestroProductos?.map(p => (
                      <option key={p.codigo} value={p.nombre}>
                        {p.nombre} (S/ {p.costo})
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="form-group" style={{ flex: 1, margin: 0 }}>
                  <input 
                    type="number" 
                    min="1" 
                    value={fila.cantidad} 
                    onChange={e => {
                      const nuevas = [...filasEpps];
                      nuevas[index].cantidad = e.target.value;
                      setFilasEpps(nuevas);
                    }}
                    style={{ margin: 0, textAlign: 'center' }} 
                  />
                </div>

                {filasEpps.length > 1 && (
                  <button 
                    type="button"
                    onClick={() => setFilasEpps(filasEpps.filter(f => f.id !== fila.id))}
                    style={{ background: 'transparent', border: 'none', color: 'var(--danger)', fontSize: '22px', cursor: 'pointer', padding: '0 4px' }}
                  >
                    &times;
                  </button>
                )}
              </div>
            ))}

            <button 
              type="button"
              onClick={() => setFilasEpps([...filasEpps, { id: Date.now(), producto: '', cantidad: 1 }])}
              className="btn-ghost"
              style={{ width: '100%', marginTop: '4px', borderStyle: 'dashed', background: 'white' }}
            >
              + Agregar otro EPP
            </button>
          </div>

          {/* sec 3 IMPACTO CONTABLE DESGLOSADO POR LÍNEA */}
          <div className="form-section" style={{ marginTop: 'auto' }}>
            
             {/* titulo de la seccion 3 */}
            <div className="form-section-title">3. Impacto Contable (Desglosado)</div>

            {/* contenedor 1*/}
            <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px' }}>
            
              {filasCuentas.map((f) => (

                <div key={f.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px dashed #e2e8f0', fontSize: '13px', color: '#475569'}}>

                  <span>{f.cuenta}</span>

                  <span style={{ fontWeight: 600 }}>S/ {parseFloat(f.monto).toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>

                </div>

              ))}
            </div>
            
            <div className="calc-total" style={{ marginTop: '16px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
                <span>Total General Proyectado</span>
                <span>S/ {filasCuentas.reduce((acc, curr) => acc + parseFloat(curr.monto || 0), 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>

            
          </div>

        </div>
      </fieldset>

      {/* FOOTER INTELIGENTE */}
      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>

    </div>
  );
}