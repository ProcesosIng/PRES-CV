import React, { useState, useEffect, useMemo } from 'react';
import { UNIDADES_NEGOCIO, TIPOS_CLIENTE, TIPOS_ZONA, MESES, maestroProductos } from '../../config/data';
import { obtenerMaestro } from '../../data/store'; // Importamos la función para leer los maestros

const ANIO_ACTUAL = new Date().getFullYear();
// Rango razonable: un año atrás hasta 3 años adelante. Ajusta si necesitas más.
const ANIOS_DISPONIBLES = Array.from({ length: 5 }, (_, i) => (ANIO_ACTUAL - 1 + i).toString());

export default function ForecastComercialForm({ registro, onGuardar, onCancelar, modo }) {
  const isSoloLectura = modo === 'ver';

  // Estados para guardar las listas de los maestros
  const [listaClientes, setListaClientes] = useState([]);
  const [listaProductos, setListaProductos] = useState([]);
  const [listaEmpleados, setListaEmpleados] = useState([]);

  // Estados del formulario
  const [cliente, setCliente] = useState('');
  const [vendedor, setVendedor] = useState('');
  const [tipoCliente, setTipoCliente] = useState(TIPOS_CLIENTE[0]);
  const [zona, setZona] = useState(TIPOS_ZONA[0]);
  const [pais, setPais] = useState('Perú');
  const [unidadNegocio, setUnidadNegocio] = useState(UNIDADES_NEGOCIO[0]);
  const [producto, setProducto] = useState('');
  const [um, setUm] = useState('Unidad');
  const [pv2025, setPv2025] = useState('0');
  const [cv2025, setCv2025] = useState('0');
  const [anioProyeccion, setAnioProyeccion] = useState(ANIO_ACTUAL.toString());
  const [precioVenta, setPrecioVenta] = useState('0');
  const [costoUnitario, setCostoUnitario] = useState('0');

  const [cantidades, setCantidades] = useState(
    MESES.reduce((acc, m) => ({ ...acc, [m]: '0' }), {})
  );

  // Cargar los maestros al montar el componente
  useEffect(() => {
    setListaClientes(obtenerMaestro('clientes'));
    setListaProductos(obtenerMaestro('productos'));
    setListaEmpleados(obtenerMaestro('empleados'));
  }, []);

  useEffect(() => {
    if (registro) {
      const dc = registro.detalle_columnas || {};
      setCliente(dc.cliente || '');
      setVendedor(dc.vendedor || '');
      setTipoCliente(dc.tipo || TIPOS_CLIENTE[0]);
      setZona(dc.zona || TIPOS_ZONA[0]);
      setPais(dc.pais || 'Perú');
      setUnidadNegocio(dc.unidad_negocio || dc.uninegocio || UNIDADES_NEGOCIO[0]);
      setProducto(dc.producto || '');
      setUm(dc.um || 'Unidad');
      setAnioProyeccion(dc.anio_proyeccion?.toString() || ANIO_ACTUAL.toString());
      setPv2025(dc.pv_2025?.toString() || '0');
      setCv2025(dc.cv_2025?.toString() || '0');
      setPrecioVenta(dc.precio_venta?.toString() || '0');
      setCostoUnitario(dc.costo_unitario?.toString() || '0');
      setCantidades(
        MESES.reduce((acc, m) => ({ ...acc, [m]: (dc.cantidades?.[m] ?? 0).toString() }), {})
      );
    }
  }, [registro]);

  const cantidadTotalAnio = useMemo(
    () => MESES.reduce((s, m) => s + (parseFloat(cantidades[m]) || 0), 0),
    [cantidades]
  );

  const precio = parseFloat(precioVenta) || 0;
  const costo = parseFloat(costoUnitario) || 0; // O parseFloat(cv2025) dependiendo de cuál uses para el costo real

  // 1. Lo que entra a la caja (Ventas)
  const ingresoTotalProyectado = cantidadTotalAnio * precio;

  // 2. Lo que cuesta producir/comprar eso (Costo Real)
  const costoTotalProyectado = cantidadTotalAnio * costo;

  // 3. (Opcional pero recomendado) La ganancia bruta
  const margenBruto = ingresoTotalProyectado - costoTotalProyectado;

  const porcentajeMargen = ingresoTotalProyectado > 0 
    ? ((margenBruto / ingresoTotalProyectado) * 100) 
    : 0;

  const handleGuardar = () => {
    if (!cliente) return alert('Por favor, seleccione un cliente.');
    if (!producto) return alert('Por favor, seleccione un producto.');
    if (!anioProyeccion) return alert('Por favor, seleccione el año de proyección.');

    const idRegistro = registro ? registro.id_registro : `FCO-${Date.now()}`;
    const idLote = registro ? (registro.id_lote || idRegistro) : `LOTE-FCO-${Date.now()}`;
    const cantidadesNum = MESES.reduce((acc, m) => ({ ...acc, [m]: parseFloat(cantidades[m]) || 0 }), {});

    const nuevoRegistro = {
      id_registro: idRegistro,
      id_lote: idLote,
      fecha_proyeccion: `${anioProyeccion}-01-01`,
      empleado_dni: '-',
      empleado_nombre: vendedor || '-',
      detalle_columnas: {
        cliente, vendedor,
        tipo_cliente: tipoCliente,
        zona, pais,
        unidad_negocio: unidadNegocio,
        producto, um,
        anio_proyeccion: anioProyeccion,
        pv_2025: parseFloat(pv2025) || 0,
        cv_2025: parseFloat(cv2025) || 0,
        precio_venta: parseFloat(precioVenta) || 0,
        costo_unitario: parseFloat(costoUnitario) || 0,
        cantidades: cantidadesNum,
        cantidad_total_anio: cantidadTotalAnio,
        ingreso_total: ingresoTotalProyectado, // El dinero de las ventas
        costo_total: costoTotalProyectado,     // El costo real (Costo Unitario * Cantidad)
        margen_bruto: margenBruto,
      },
      totales: { 
        ingreso_total: ingresoTotalProyectado, 
        costo_total: costoTotalProyectado,
        margen_bruto: margenBruto
      },
      desglose_contable: [
        {
          id: 'v1',
          cuenta: `Ventas Proyectadas · ${unidadNegocio} · ${producto}`,
          monto: ingresoTotalProyectado.toFixed(2)
        },
        {
          id: 'c1',
          cuenta: `Costo de Ventas · ${unidadNegocio} · ${producto}`,
          monto: costoTotalProyectado.toFixed(2)
        }
      ],
    };

    onGuardar([nuevoRegistro]);
  };

  // Funciones de Autocompletado
  const handleSeleccionarCliente = (e) => {
    const nombreCliente = e.target.value;
    setCliente(nombreCliente);
    
    // Buscar el cliente en el maestro y autocompletar
    const dataCliente = listaClientes.find(c => c.nombre === nombreCliente);
    if (dataCliente) {
      // 1. Campos de texto libre o listas dinámicas
      setVendedor(dataCliente.vendedor || '');
      setPais(dataCliente.pais || 'Perú');
      
      // 2. Zona (Validación estricta para el <select>)
      const zonaSugerida = dataCliente.zona || '';
      if (TIPOS_ZONA.includes(zonaSugerida)) {
        setZona(zonaSugerida);
      } else {
        // Busca ignorando mayúsculas/minúsculas
        const zonaCoincidente = TIPOS_ZONA.find(z => z.toLowerCase() === zonaSugerida.toLowerCase());
        setZona(zonaCoincidente || TIPOS_ZONA[0]);
      }

      // 3. Tipo de Cliente (Validación estricta para el <select>)
      const tipoSugerido = dataCliente.tipo || '';
      if (TIPOS_CLIENTE.includes(tipoSugerido)) {
        setTipoCliente(tipoSugerido);
      } else {
        // Busca ignorando mayúsculas/minúsculas
        const tipoCoincidente = TIPOS_CLIENTE.find(t => t.toLowerCase() === tipoSugerido.toLowerCase());
        setTipoCliente(tipoCoincidente || TIPOS_CLIENTE[0]);
      }
      
    } else {
      // Si el usuario borra la selección del cliente, reseteamos los campos
      setVendedor('');
      setPais('Perú');
      setZona(TIPOS_ZONA[0]);
      setTipoCliente(TIPOS_CLIENTE[0]);
    }
  };

  const handleSeleccionarProducto = (e) => {
    const nombreProducto = e.target.value;
    setProducto(nombreProducto);
    
    // Buscar el producto en el maestro y autocompletar
    const dataProducto = listaProductos.find(p => p.nombre === nombreProducto);
    if (dataProducto) {

      // 1. Unidad de Medida
      setUm(dataProducto.unidad || 'Unidad');

      // 2. Precios Históricos (ant)
      // Buscamos 'pv' o 'precio' por si acaso hay variaciones en el maestro
      const precioMaestro = dataProducto.pv || '0';
      const costoMaestro = dataProducto.costo || '0';
      // Llenamos los precios históricos (PV ant y CV ant)
      setPv2025(precioMaestro || '0');
      setCv2025(costoMaestro || '0');

      // 4. Unidad de Negocio (Buscamos en uninegocio, si no existe buscamos en categoria)
      const unidadSugerida = dataProducto.uninegocio || dataProducto.categoria || '';

      console.log("Intentando seleccionar unidad:", unidadSugerida);
      console.log("Opciones disponibles en tu array:", UNIDADES_NEGOCIO);

      if (UNIDADES_NEGOCIO.includes(unidadSugerida)) {
          setUnidadNegocio(unidadSugerida);
      } else {
          // Intenta buscar ignorando mayúsculas/minúsculas
          const unidadCoincidente = UNIDADES_NEGOCIO.find(un => un.toLowerCase() === unidadSugerida.toLowerCase());
          
          if (unidadCoincidente) {
            setUnidadNegocio(unidadCoincidente);
          } else {
            console.warn("⚠️ No se encontró la unidad de negocio en la lista. Se usará el valor por defecto.");
            setUnidadNegocio(UNIDADES_NEGOCIO[0]);
          }
      }
      } else {
        // Si el usuario borra el producto, limpiamos todos los campos a 0
        setUm('Unidad');
        setPv2025('0');
        setCv2025('0');
        setPrecioVenta('0');
        setCostoUnitario('0');
        setUnidadNegocio(UNIDADES_NEGOCIO[0]);
      }
  };
  //{codigo, nombre, unidad, pv, costo, categoria, uninegocio, lineanegocio}

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto' }}>

          <div className="form-section">
            <div className="form-section-title">1. Cliente y Vendedor</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>

              <div className="form-group" style={{ margin: 0, gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#2563eb' }}>AÑO DE PROYECCIÓN</label>
                <select value={anioProyeccion} onChange={e => setAnioProyeccion(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', fontWeight: 600 }}>
                  {ANIOS_DISPONIBLES.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
              
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CLIENTE</label>
                <select value={cliente} onChange={handleSeleccionarCliente} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">Seleccione un cliente...</option>
                  {listaClientes.map(c => <option key={c.ruc || c.id} value={c.nombre}>{c.nombre}</option>)}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>VENDEDOR</label>
                <select value={vendedor} onChange={e => setVendedor(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">Seleccione un vendedor...</option>
                  {listaEmpleados.map(emp => <option key={emp.dni || emp.id} value={emp.nombre}>{emp.nombre}</option>)}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>TIPO DE CLIENTE</label>
                <select 
                  value={tipoCliente} 
                  onChange={e => setTipoCliente(e.target.value)} 
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #64748b)', borderRadius: '4px', background: 'white' }}
                >
                  <option value="">Seleccione tipo...</option>
                  {TIPOS_CLIENTE.map((tipo, idx) => (
                    <option key={idx} value={tipo}>{tipo}</option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>ZONA</label>
                <select 
                  value={zona} 
                  onChange={e => setZona(e.target.value)} 
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #64748b)', borderRadius: '4px', background: 'white' }}
                >
                  <option value="">Seleccione zona...</option>
                  {TIPOS_ZONA.map((z, idx) => (
                    <option key={idx} value={z}>{z}</option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0, gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PAÍS</label>
                <input type="text" value={pais} onChange={e => setPais(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          {/* seccion producto*/}
          <div className="form-section">
            <div className="form-section-title">2. Producto</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
              
              <div className="form-group" style={{ margin: 0, gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRODUCTO</label>
                <select value={producto} onChange={handleSeleccionarProducto} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}>
                  <option value="">Seleccione un producto...</option>
                  {listaProductos.map(p => <option key={p.codigo || p.id} value={p.nombre}>{p.nombre}</option>)}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>UNIDAD DE NEGOCIO</label>
                <select 
                  value={unidadNegocio} 
                  onChange={e => setUnidadNegocio(e.target.value)} 
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }}
                >
                  <option value="">Seleccione unidad...</option>
                  {UNIDADES_NEGOCIO.map((un, idx) => (
                    <option key={idx} value={un}>{un}</option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>UNIDAD DE MEDIDA</label>
                <input type="text" value={um} onChange={e => setUm(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
              <div className="form-group" style={{ margin: 0 }}>

                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PV ant</label>
                <input type="number" step="0.01" value={pv2025} onChange={e => setPv2025(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>CV ant</label>
                <input type="number" step="0.01" value={cv2025} onChange={e => setCv2025(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>PRECIO DE VENTA</label>
                <input type="number" step="0.01" value={precioVenta} onChange={e => setPrecioVenta(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>COSTO UNITARIO</label>
                <input type="number" step="0.01" value={costoUnitario} onChange={e => setCostoUnitario(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }} />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">3. Cantidades Proyectadas (mes a mes)</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px' }}>
              {MESES.map(m => (
                <div className="form-group" key={m} style={{ margin: 0 }}>
                  <label style={{ fontSize: '10px', fontWeight: 600, color: '#64748b' }}>{m}</label>
                  <input type="number" value={cantidades[m]} onChange={e => setCantidades({ ...cantidades, [m]: e.target.value })}
                    style={{ width: '100%', padding: '6px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', textAlign: 'center' }} />
                </div>
              ))}
            </div>
          </div>

          <div className="form-section" style={{ marginTop: 'auto' }}>
            
            <div className="form-section-title">4. Resumen</div>
              
              <div className="calc-total" style={{ marginTop: '8px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#166534', paddingBottom: '6px' }}>
                <span>Cantidad Total del Año</span>
                <span style={{ fontWeight: 600 }}>{cantidadTotalAnio.toLocaleString('en-US')}</span>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#166534', paddingBottom: '6px', borderTop: '1px dashed #bbf7d0', paddingTop: '6px' }}>
                <span>Ingresos Proyectados (Ventas)</span>
                <span style={{ fontWeight: 600 }}>{ingresoTotalProyectado.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#991b1b', paddingBottom: '6px' }}>
                <span>Costos Proyectados</span>
                <span style={{ fontWeight: 600 }}>- {costoTotalProyectado.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px', borderTop: '1px solid #bbf7d0', paddingTop: '6px' }}>
                <span>Margen Bruto Proyectado <span style={{ fontSize: '13px', color: '#15803d', marginLeft: '8px' }}>({porcentajeMargen.toFixed(1)}%)</span></span>
                <span>{margenBruto.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

        </div>
      </fieldset>

      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Forecast
          </button>
        )}
      </div>
    </div>
  );
}