import React, { useState, useEffect } from 'react';
import { maestroEmpleados, PROCESOS_PRODUCTIVOS, MESES } from '../../config/data';

export default function RemuneracionesForm({ registro, onGuardar, onCancelar, modo, area }) {

  // console.log("Registro recibido en el formulario:", registro);

  const isSoloLectura = modo === 'ver';
  // ==========================================
  // 1. ESTADOS
  // ==========================================
  const ANIO_ACTUAL = new Date().getFullYear();
  const ANIOS_DISPONIBLES = [ANIO_ACTUAL - 1, ANIO_ACTUAL, ANIO_ACTUAL + 1, ANIO_ACTUAL + 2].map(String);
  const [anioActivo, setAnioActivo] = useState(ANIO_ACTUAL.toString()); 
  const [fechasSeleccionadas, setFechasSeleccionadas] = useState([]);

  const [valorBuscador, setValorBuscador] = useState('');
  const [proceso, setProceso] = useState('');
  const [seguro, setSeguro] = useState('');

  const [datosAuto, setDatosAuto] = useState({ 
    dni: '', sueldo: '0', dist: '100', sueldo_calc: '0', cargo: '' 
  });

  const [valoresRegistro, setValoresRegistro] = useState({
    asig_fam: '0', movilidad: '0', he_25: '0', he_35: '0', feriados: '0', comision: '0', tarjeta_alim: 'No', h_noc: '0', otrasRemun: '0'
  });

  const prefijosPorArea = {
        'Administración': '94',
        'Comercial': '95',
        'Logística': '98',
        'Almacén': '99',
        'Producción Crisoles': '91',
        'Producción Fundente': '92'
      };

  const prefijo = prefijosPorArea[area] || '';

  const [filasCuentas, setFilasCuentas] = useState([]);

  // ==========================================
  // 2. CARGA INICIAL (MODO EDICIÓN)
  // ==========================================
  useEffect(() => {
    if (registro) {
      // 1. Cargamos la fecha de proyección
      setFechasSeleccionadas([registro.fecha_proyeccion]);
      
      // SOLUCIÓN AL BUG VISUAL: Fijar la pestaña al año del registro
      if (registro.fecha_proyeccion) {
        const anioReg = registro.fecha_proyeccion.split('-')[0];
        setAnioActivo(anioReg); 
      }

      // 2. Reconstruimos el buscador (DNI - Nombre)
      setValorBuscador(`${registro.empleado_dni || ''} - ${registro.empleado_nombre || ''}`);
      setProceso(registro.detalle_columnas?.proceso || '');
      setSeguro(registro.detalle_columnas?.seguro || '');
      // 3. Buscamos al empleado en el maestro para recuperar su cargo u otros datos
      const emp = maestroEmpleados.find(e => (e.dni || e.id) === registro.empleado_dni);
      
      // 4. Mapeamos exactamente los nombres que usa este formulario
      setDatosAuto({
        dni: registro.empleado_dni || '',
        sueldo: registro.detalle_columnas?.sueldo_base?.toString() || '0',
        dist: registro.detalle_columnas?.distribucion?.toString() || '100',
        sueldo_calc: registro.detalle_columnas?.sueldo_calculo?.toString() || '0',
        cargo: emp ? (emp.cargo || 'Sin asignar') : 'Cargo Registrado'
      });
      
      // 5. Cargamos las variables y el desglose contable guardado
      setValoresRegistro(registro.variables_registro || {});
      setFilasCuentas(registro.desglose_contable || []);
    }
  // SOLUCIÓN AL BLOQUEO DE CAMPOS: Cambiamos [registro] por [registro?.id_registro]
  // Esto evita que React resetee el formulario cada vez que tecleas algo.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registro?.id_registro]); 

  // ==========================================
  // 3. FUNCIONES DE INTERFAZ
  // ==========================================
  const construirFecha = (anio, mesIndex) => `${anio}-${(mesIndex + 1).toString().padStart(2, '0')}-01`;

  const estaSeleccionado = (anio, mesIndex) => fechasSeleccionadas.includes(construirFecha(anio, mesIndex));

  const toggleMes = (anio, mesIndex) => {
    const fecha = construirFecha(anio, mesIndex);
    setFechasSeleccionadas(prev =>
      prev.includes(fecha) ? prev.filter(f => f !== fecha) : [...prev, fecha].sort()
    );
  };

  const seleccionarAnioCompleto = (anio) => {
    const fechasDelAnio = MESES.map((_, i) => construirFecha(anio, i));
    setFechasSeleccionadas(prev => Array.from(new Set([...prev, ...fechasDelAnio])).sort());
  };

  const limpiarAnio = (anio) => {
    setFechasSeleccionadas(prev => prev.filter(f => !f.startsWith(`${anio}-`)));
  };

  const formatearEtiqueta = (fechaStr) => {
    const [anio, mes] = fechaStr.split('-');
    const nombreMes = MESES[parseInt(mes, 10) - 1] || mes;
    return `${nombreMes} ${anio}`;
  };

  const handleAutocomplete = (e) => {
    const text = e.target.value;
    setValorBuscador(text);
    
    const idSeleccionado = text.split(' - ')[0];
    const emp = maestroEmpleados.find(emp => (emp.dni || emp.id) === idSeleccionado);
    
    if (emp) {
      setDatosAuto({
        dni: emp.dni || emp.id,
        sueldo: emp.sueldo || '0',
        dist: emp.distribucion?.toString().replace('%', '') || '100',
        cargo: emp.cargo || 'Sin asignar',
        sueldo_calc: '0',
        proceso: emp.proceso || ''
      });
      setValoresRegistro(prev => ({ ...prev, asig_fam: emp.asigFam || '0' }));
      setProceso(emp.proceso || '');
      setSeguro(emp.seguro || '');

    } else {
      setDatosAuto({ dni: '', sueldo: '0', dist: '100', sueldo_calc: '0', cargo: '' });
      setProceso('');
      setSeguro('');
      // Agrupamos la limpieza de todas las variables aquí adentro, que es su estado real
      setValoresRegistro({ 
        asig_fam: '0', 
        movilidad: '0', 
        he_25: '0', 
        he_35: '0', 
        feriados: '0', 
        comision: '0',
        tarjeta_alim: 'No' ,
        h_noc: '0',         
        otrasRemun: '0', 
        
      });
      
    }
  };

  // ==========================================
  // 4. MOTOR MATEMÁTICO INTELIGENTE (EXCLUSIVO REMUNERACIONES)
  // ==========================================
  useEffect(() => {
    // 1. Si el usuario borra todo dejando el input vacío, limpiamos la tabla en vez de quedarnos pegados
    if (!datosAuto.sueldo || parseFloat(datosAuto.sueldo) === 0) {
      setDatosAuto(prev => ({ ...prev, sueldo_calc: '0' }));
      setFilasCuentas([]);
      return;
    }

    // CANDADO INTELIGENTE: Si es edición, verifica si el usuario cambió algo
    if (registro) {
      const sueldoOrig = registro.detalle_columnas?.sueldo_base?.toString() || '0';
      const distOrig = registro.detalle_columnas?.distribucion?.toString() || '100';
      
      const vAct = valoresRegistro || {};
      const vOrig = registro.variables_registro || {};
      
      const varsIguales = 
        (vAct.asig_fam || '0').toString() === (vOrig.asig_fam || '0').toString() &&
        (vAct.movilidad || '0').toString() === (vOrig.movilidad || '0').toString() &&
        (vAct.he_25 || '0').toString() === (vOrig.he_25 || '0').toString() &&
        (vAct.he_35 || '0').toString() === (vOrig.he_35 || '0').toString() &&
        (vAct.h_noc || '0').toString() === (vOrig.h_noc || '0').toString() &&
        (vAct.feriados || '0').toString() === (vOrig.feriados || '0').toString() &&
        (vAct.comision || '0').toString() === (vOrig.comision || '0').toString() &&
        (vAct.otrasRemun || '0').toString() === (vOrig.otrasRemun || '0').toString() &&
        (vAct.tarjeta_alim || 'No') === (vOrig.tarjeta_alim || 'No');

      // Si nada ha cambiado, aborta el cálculo para respetar el historial guardado
      
      if (datosAuto.sueldo === sueldoOrig && datosAuto.dist === distOrig && varsIguales) {
        setDatosAuto(prev => ({ ...prev, sueldo_calc: registro.detalle_columnas?.sueldo_calculo?.toString() || '0' }));
        setFilasCuentas(registro.desglose_contable || []);
        return;
      }
    }

    // CÁLCULO DE PROPORCIONALIDAD
    const sueldoTotal = parseFloat(datosAuto.sueldo) || 0;
    const porcentaje = parseFloat(datosAuto.dist) || 0;
    const sueldoProporcional = (sueldoTotal * porcentaje / 100).toFixed(2);
    
    if (datosAuto.sueldo_calc !== sueldoProporcional) {
      setDatosAuto(prev => ({ ...prev, sueldo_calc: sueldoProporcional }));
    }

    // CÁLCULO DE LEYES SOCIALES Y HORAS EXTRAS
    if (sueldoProporcional > 0) {
      const baseCalc = parseFloat(sueldoProporcional) || 0;
      const asig = parseFloat(valoresRegistro.asig_fam) || 0;
      const movilidad = parseFloat(valoresRegistro.movilidad) || 0;
      const he25 = parseFloat(valoresRegistro.he_25) || 0;
      const he35 = parseFloat(valoresRegistro.he_35) || 0;
      const hnoc = parseFloat(valoresRegistro.h_noc) || 0;
      const feriados = parseFloat(valoresRegistro.feriados) || 0;
      const comision = parseFloat(valoresRegistro.comision) || 0;
      const otrasremun = parseFloat(valoresRegistro.otrasRemun) || 0;

      const MONTO_FIJO_TARJETA = 200.00;
      const tarjetaAlim = valoresRegistro.tarjeta_alim === 'Sí' ? MONTO_FIJO_TARJETA : 0;
      const vHora = (baseCalc / 30) / 8; //costo por hora
      const mHE25 = he25 * vHora * 1.25; //ok
      const mHE35 = he35 * vHora * 1.35; //ok
      const mHnoc = hnoc * vHora * 0.35; //ok
      const mFeriado = feriados * (baseCalc / 30) * 2; 
      const mComision = comision
      const mOtrasremun = otrasremun
      const mGratif = (baseCalc + mComision + mHE25 + mHE35 + asig + mFeriado)/6
      const mVacaciones = (baseCalc + mComision + mHE25 + mHE35 + asig + mFeriado)/12      
      const mBonifi = seguro === 'EsSalud' ? (mGratif * 0.09) : (seguro === 'EPS' ? (mGratif * 0.0675) : 0)
      const mprestsalud = seguro === 'EsSalud' ? ((baseCalc + mComision + mHE25 + mHE35 + asig + mFeriado) * 0.09) : (seguro === 'EPS' ? ((baseCalc + mComision + mHE25 + mHE35 + asig + mFeriado) * 0.0675) : 0)
      const mSCTR = baseCalc*0.0166
      const mSVida = baseCalc*0.0037
      const mEPS = seguro === 'EPS' ? ((baseCalc + mComision + mHE25 + mHE35 + asig + mFeriado) * 0.0225) : 0
      const mCTS = (baseCalc + mComision + asig + mHE25 + mHE35 + mOtrasremun + (mGratif / 6)) / 6

      const cuentas = [
        { id: 'c1', cuenta: `${prefijo}6211000 - Sueldos y Salarios Base`, monto: baseCalc.toFixed(2) },        
        { id: 'c2', cuenta: `${prefijo}6214000 - Gratificacion`, monto: mGratif.toFixed(2) },
        { id: 'c3', cuenta: `${prefijo}6215000 - Vacaciones`, monto: mVacaciones.toFixed(2) },
        { id: 'c4', cuenta: `${prefijo}6218000 - Bonificación Extraordinaria`, monto: mBonifi.toFixed(2) },  
        { id: 'c5', cuenta: `${prefijo}6211000 - SCTR, Accid Trabajo y Enf`, monto: mSCTR.toFixed(2) },   
        { id: 'c6', cuenta: `${prefijo}6211000 - Seguro de Vida`, monto: mSVida.toFixed(2) },
        { id: 'c7', cuenta: `${prefijo}6211000 - CTS`, monto: mCTS.toFixed(2) },
      ];
      if (tarjetaAlim > 0) cuentas.push({ id: 'c8', cuenta: `${prefijo}6220000 - Tarjetas Alimentarias`, monto: tarjetaAlim.toFixed(2) });
      if (movilidad > 0) cuentas.push({ id: 'c9', cuenta: `${prefijo}6211000 - Movilidad`, monto: movilidad.toFixed(2) });
      if (asig > 0) cuentas.push({ id: 'c10', cuenta: `${prefijo}6216000 - Asignación Familiar`, monto: asig.toFixed(2)});
      if (mHE25 > 0) cuentas.push({ id: 'c11', cuenta: `${prefijo}6217000 - Horas Extras`, monto: (mHE25+mHE35+mHnoc).toFixed(2) });
      if (mFeriado > 0) cuentas.push({ id: 'c12', cuenta: `${prefijo}6219000 - Domingos y Feriados Laborados`, monto: mFeriado.toFixed(2) });
      if (comision > 0) cuentas.push({ id: 'c13', cuenta: `${prefijo}6212000 - Comision`, monto: mComision.toFixed(2) });
      if (mEPS > 0) cuentas.push({ id: 'c14', cuenta: `${prefijo}6271000 - EPS (2.25%)`, monto: mEPS.toFixed(2) });
      if (mOtrasremun > 0) cuentas.push({ id: 'c15', cuenta: `${prefijo}6271000 - Otras Remuneraciones`, monto: mOtrasremun.toFixed(2) });
      cuentas.push({ id: 'c16', cuenta: `${prefijo}6211000 - Regimen Prestaciones de Salud`, monto: mprestsalud.toFixed(2) });

      setFilasCuentas(prevFilas => {
        return cuentas.map(nuevaFila => {
          const filaExistente = prevFilas.find(f => f.id === nuevaFila.id);
          // Si el usuario editó esta fila a mano, respetamos su número
          if (filaExistente && filaExistente.editadoManualmente) {
            return filaExistente; 
          }
          // Si no, le pasamos el nuevo cálculo de la computadora
          return nuevaFila;
        });
      });
    }
  }, [datosAuto.sueldo, datosAuto.dist, valoresRegistro, registro, prefijo, seguro]);

  // ==========================================
  // 5. GUARDADO MÚLTIPLE
  // ==========================================
  const handleGuardar = () => {
    // 1. Rescatamos la fecha si el usuario escribió pero no dio a "Añadir"
    const fechasFinales = [...fechasSeleccionadas];

    // 2. Validaciones
    if (fechasFinales.length === 0) return alert('Por favor, ingrese al menos una fecha.');
    if (!valorBuscador) return alert('Por favor, seleccione un empleado.');
    
    // 3. Cálculos de totales
    let ingresos = 0; 
    let aportes = 0;

    filasCuentas.forEach(f => {
      const m = parseFloat(f.monto) || 0;
      const nombreCuenta = f.cuenta.toUpperCase();

      // Agrupamos todo lo que es carga patronal, seguro o provisión
      const esAporte = 
        nombreCuenta.includes('SALUD') || 
        nombreCuenta.includes('EPS') || 
        nombreCuenta.includes('SCTR') || 
        nombreCuenta.includes('SEGURO DE VIDA') || 
        nombreCuenta.includes('CTS');

      if (esAporte) {
        aportes += m;
      } else {
        ingresos += m;
      }
    });

    const nombre = valorBuscador.split(' - ')[1] || valorBuscador;
    const idLoteActual = `LOTE-${Date.now()}`;

    // 4. Mapeo de registros (uno por cada fecha)
    const nuevosRegistros = fechasFinales.map((fecha, idx) => ({
      id_registro: (registro && idx === 0) ? registro.id_registro : null,
      id_lote: registro ? (registro.id_lote || idLoteActual) : idLoteActual,
      fecha_proyeccion: fecha,
      empleado_dni: datosAuto.dni || '-',
      empleado_nombre: nombre,
      detalle_columnas: {
        sueldo_base: parseFloat(datosAuto.sueldo) || 0,
        asig_familiar: parseFloat(valoresRegistro.asig_fam) || 0,
        proceso: proceso,
        seguro: seguro,
        distribucion: parseFloat(datosAuto.dist) || 0,
        sueldo_calculo: parseFloat(datosAuto.sueldo_calc) || 0,
        costo_total: ingresos + aportes
      },
      totales: { ingresos, aportes, costo_total: ingresos + aportes },
      desglose_contable: filasCuentas,
      variables_registro: valoresRegistro 
    }));

    // 5. Envío al padre
    // console.log("Registros múltiples generados:", nuevosRegistros); // Para depurar en consola
    onGuardar(nuevosRegistros);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      <fieldset disabled={isSoloLectura} style={{ border: 'none', padding: 0, margin: 0, flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div className="offcanvas-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '20px' }}>
                
        {/* 0. FECHAS */}
        <div className="form-section">
          <div className="form-section-title">0. Fechas de Aplicación</div>

          {/* Tabs de año */}
          <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
            {ANIOS_DISPONIBLES.map(anio => (
              <button
                key={anio}
                type="button"
                onClick={() => setAnioActivo(anio)}
                style={{
                  padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600,
                  border: anio === anioActivo ? '1px solid var(--primary-600, #2563eb)' : '1px solid var(--line, #cbd5e1)',
                  background: anio === anioActivo ? 'var(--primary-600, #2563eb)' : 'white',
                  color: anio === anioActivo ? 'white' : '#475569',
                }}
              >
                {anio}
              </button>
            ))}
          </div>

          {/* Grid de meses del año activo */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '6px', marginBottom: '10px' }}>
            {MESES.map((mes, i) => {
              const activo = estaSeleccionado(anioActivo, i);
              return (
                <button
                  key={mes}
                  type="button"
                  onClick={() => toggleMes(anioActivo, i)}
                  style={{
                    padding: '8px 4px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px', fontWeight: 600,
                    border: activo ? '1px solid #166534' : '1px solid var(--line, #cbd5e1)',
                    background: activo ? '#f0fdf4' : 'white',
                    color: activo ? '#166534' : '#475569',
                  }}
                >
                  {mes}
                </button>
              );
            })}
          </div>

          {/* Atajos para no tener que tocar los 12 botones uno por uno */}
          <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <button type="button" onClick={() => seleccionarAnioCompleto(anioActivo)} className="btn-ghost" style={{ background: 'white', fontSize: '12px', padding: '6px 10px' }}>
              + Seleccionar {anioActivo} completo
            </button>
            <button type="button" onClick={() => limpiarAnio(anioActivo)} className="btn-ghost" style={{ background: 'white', fontSize: '12px', padding: '6px 10px', color: '#ef4444' }}>
              Limpiar {anioActivo}
            </button>
          </div>

          {/* Resumen de todo lo seleccionado, sin importar el año que se esté viendo ahora */}
          {fechasSeleccionadas.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {fechasSeleccionadas.map(f => (
                <div key={f} style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', padding: '4px 10px', borderRadius: '99px', fontSize: '12px' }}>
                  {formatearEtiqueta(f)}
                  <span onClick={() => setFechasSeleccionadas(fechasSeleccionadas.filter(x => x !== f))} style={{ cursor: 'pointer', fontWeight: 'bold', marginLeft: '6px' }}>&times;</span>
                </div>
              ))}
            </div>
          )}
        </div>
        {/* 1. DATOS GENERALES */}
        <div className="form-section">
          <div className="form-section-title">1. Información General</div>
          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label style={{ color: 'var(--primary-600, #2563eb)' }}>BUSCAR EMPLEADO (DNI O NOMBRE)</label>
            <input 
              list="lista-emp-rem" 
              value={valorBuscador}
              onChange={handleAutocomplete} 
              placeholder="Escriba para buscar..." 
              autoComplete="off" 
              style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px' }}
            />
            <datalist id="lista-emp-rem">
              {maestroEmpleados.map((e, i) => <option key={i} value={`${e.dni || e.id} - ${e.nombre}`} />)}
            </datalist>
          </div>
          
          <div className="form-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div className="form-group">
              <label>SUELDO BASE TOTAL (S/)</label>
              <input 
                type="number" 
                value={datosAuto.sueldo} 
                onChange={e => setDatosAuto(prev => ({ ...prev, sueldo: e.target.value }))} 
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line)', borderRadius: '4px', background: 'white' }} 
              />
            </div>
            <div className="form-group">
              <label>SUELDO PARA CÁLCULO (S/)</label>
              <input type="number" value={datosAuto.sueldo_calc} readOnly style={{ width: '100%', padding: '8px', border: '1px solid var(--line)', borderRadius: '4px', background: '#f8fafc' }} />
            </div>
            <div className="form-group">
              <label>DISTRIBUCIÓN (%)</label>
              <input 
                type="number" 
                value={datosAuto.dist} 
                onChange={e => setDatosAuto(prev => ({ ...prev, dist: e.target.value }))} 
                style={{ width: '100%', padding: '8px', border: '1px solid var(--line)', borderRadius: '4px' }} 
              />
            </div>
            <div className="form-group">
              <label>CARGO ASIGNADO</label>
              <input type="text" value={datosAuto.cargo} readOnly style={{ width: '100%', padding: '8px', border: '1px solid var(--line)', borderRadius: '4px', background: '#f8fafc' }} />              
            </div>
              <div className="form-group">
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Proceso</label>
                <select 
                  value={proceso} 
                  onChange={e => setProceso(e.target.value)} 
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }}
                >
                  <option value="">-- Seleccione --</option>
                  {PROCESOS_PRODUCTIVOS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label style={{ fontSize: '11px', fontWeight: 600, color: '#64748b' }}>Tipo de Seguro</label>
                <select 
                  value={seguro} 
                  onChange={e => setSeguro(e.target.value)} 
                  style={{ width: '100%', padding: '8px', border: '1px solid var(--line, #cbd5e1)', borderRadius: '4px', background: 'white' }}
                >
                  <option value="">Seleccione seguro...</option>
                  <option value="EsSalud">EsSalud</option>
                  <option value="EPS">EPS</option>
                </select>
              </div>
              
          </div>
        </div>

        {/* 2. VARIABLES DE REGISTRO */}
        <div className="form-section">
          <div className="form-section-title">2. Variables de Registro</div>
          <div className="form-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div className="form-group"><label>ASIGNACIÓN FAMILIAR (S/)</label><input type="number" value={valoresRegistro.asig_fam} onChange={e => setValoresRegistro({...valoresRegistro, asig_fam: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} /></div>
            <div className="form-group"><label>MOVILIDAD (S/)</label><input type="number" value={valoresRegistro.movilidad} onChange={e => setValoresRegistro({...valoresRegistro, movilidad: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} /></div>

            <div style={{ gridColumn: '1 / -1', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
  
              <div className="form-group" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                <label>HE 25% (CANT.)</label>
                <input type="number" value={valoresRegistro.he_25} onChange={e => setValoresRegistro({...valoresRegistro, he_25: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} />
              </div>
              
              <div className="form-group" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                <label>HE 35% (CANT.)</label>
                <input type="number" value={valoresRegistro.he_35} onChange={e => setValoresRegistro({...valoresRegistro, he_35: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} />
              </div>

              <div className="form-group" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                <label>HORAS NOCTURNAS</label>
                <input type="number" value={valoresRegistro.h_noc} onChange={e => setValoresRegistro({...valoresRegistro, h_noc: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} />
              </div>

            </div>

            <div className="form-group"><label>DOM/FERIADOS LABORADOS</label><input type="number" value={valoresRegistro.feriados} onChange={e => setValoresRegistro({...valoresRegistro, feriados: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} /></div>

            <div className="form-group"><label>COMISION</label><input type="number" value={valoresRegistro.comision} onChange={e => setValoresRegistro({...valoresRegistro, comision: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} /></div>
            <div className="form-group">
              <label>TARJETA ALIMENTARIA</label>
              <select 
                value={valoresRegistro.tarjeta_alim} 
                onChange={e => setValoresRegistro({...valoresRegistro, tarjeta_alim: e.target.value})} 
                style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)', background: 'white' }} 
              >
                <option value="No">No</option>
                <option value="Sí">Sí</option>
              </select>
            </div>
            <div className="form-group"><label>OTRAS REMUNERACIONES</label><input type="number" value={valoresRegistro.otrasRemun} onChange={e => setValoresRegistro({...valoresRegistro, otrasRemun: e.target.value})} style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid var(--line)' }} /></div>
          </div>
        </div>

        {/* 3. IMPACTO CONTABLE */}
        <div className="form-section" style={{ marginTop: 'auto' }}>

          {/* titulo de la seccion 3 */}
          <div className="form-section-title">3. Impacto Contable (Calculado Automáticamente)</div>
          
          {/* contenedor 1*/}
          <div style={{ background: 'white', borderRadius: '6px', border: '1px solid #e2e8f0', padding: '12px' }}>

            {filasCuentas.map((f) => (
              <div key={f.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '4px 0', borderBottom: '1px dashed #e2e8f0', fontSize: '13px', color: '#475569' }}>
                
                <span>{f.cuenta}</span>

                <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
                  <span style={{ fontWeight: 600 }}>S/</span>
                  <input 
                    type="number" 
                    step="0.01"
                    value={f.monto} 
                    onChange={(e) => {
                      const nuevoMonto = e.target.value;
                      // Actualizamos solo el monto de esta fila específica
                      setFilasCuentas(filasCuentas.map(cuenta => 
                        cuenta.id === f.id ? { ...cuenta, monto: nuevoMonto, editadoManualmente: true } : cuenta
                      ));
                    }}
                    style={{ 
                      width: '80px', 
                      textAlign: 'right', 
                      fontWeight: 600, 
                      fontSize: '13px',
                      color: '#475569',
                      border: '1px solid transparent', 
                      borderRadius: '4px',
                      padding: '2px 4px',
                      outline: 'none',
                      background: 'transparent',
                      transition: 'all 0.2s'
                    }}
                    // Pequeño truco visual: se ve como texto normal hasta que le haces clic
                    onFocus={(e) => { e.target.style.border = '1px solid var(--primary-600, #2563eb)'; e.target.style.background = 'white'; }}
                    onBlur={(e) => { e.target.style.border = '1px solid transparent'; e.target.style.background = 'transparent'; }}
                  />
                </div>

              </div>
            ))}

          </div>

          <div className="calc-total" style={{ marginTop: '16px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>

            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', color: '#166534', fontSize: '16px' }}>
              <span>Total Proyectado (Por Fecha)</span>
              <span>S/ {filasCuentas.reduce((s, f) => s + (parseFloat(f.monto)||0), 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>

          </div>
        </div>

      </div>
    </fieldset>

      {/* FOOTER */}
      <div className="offcanvas-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '16px 24px', display: 'flex', gap: '12px', justifyContent: 'flex-end', background: 'white' }}>
        <button type="button" onClick={onCancelar} className="btn-back m-0" style={{ background: 'white', border: '1px solid var(--line, #cbd5e1)', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          {isSoloLectura ? 'Cerrar' : 'Cancelar'}
        </button>
        
        {!isSoloLectura && (
          <button type="button" onClick={handleGuardar} className="btn-add m-0" style={{ background: 'var(--primary-600, #2563eb)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer' }}>
            Guardar Registro
          </button>
        )}
      </div>
      
    </div>
  );
}