import React from 'react';

export default function ForecastComercialFila({ reg, onVer, onEditar, onBorrar, filtroMes }) {
  const dc = reg.detalle_columnas || {};

  const cantidadAMostrar = filtroMes 
    ? (parseFloat(dc.cantidades?.[filtroMes]) || 0) 
    : (dc.cantidad_total_anio || 0);

  return (
    <tr key={reg.id_registro}>
      <td style={{ fontWeight: 500 }}>{dc.cliente || '-'}</td>
      <td>{dc.vendedor || '-'}</td>
      <td>
        <span style={{ fontSize: '12px', background: '#f1f5f9', padding: '2px 6px', borderRadius: '4px', color: '#334155' }}>
          {dc.unidad_negocio || '-'}
        </span>
      </td>
      <td>{dc.producto || '-'}</td>
      <td style={{ textAlign: 'center' }}>{dc.um || '-'}</td>
      <td style={{ textAlign: 'right' }} className="font-mono">
        S/ {(dc.precio_venta || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'right' }} className="font-mono">
        S/ {(dc.costo_unitario || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
      </td>
      <td style={{ textAlign: 'right', fontWeight: 600, color: '#166534' }}>
        {cantidadAMostrar.toLocaleString('en-US')}
        {/* Opcional: te muestra un pequeño texto indicando qué mes es */}
        {filtroMes && <span style={{ fontSize: '10px', color: '#64748b', display: 'block' }}>({filtroMes})</span>}
      </td>
      <td style={{ textAlign: 'center' }}>
        <button onClick={() => onVer(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Ver">👁️</button>
        <button onClick={() => onEditar(reg)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', marginRight: '8px' }} title="Editar">✏️</button>
        <button onClick={() => onBorrar(reg.id_registro)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }} title="Eliminar">🗑️</button>
      </td>
    </tr>
  );
}
